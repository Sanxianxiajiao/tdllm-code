import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, Subset
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import argparse
import os
import json
import random

# --- 模型定义 ---

# 1. Logistic Regression Model
class LogisticRegression(nn.Module):
    def __init__(self, num_features):
        super(LogisticRegression, self).__init__()
        self.linear = nn.Linear(num_features, 1) # 输出1个logit

    def forward(self, x):
        return self.linear(x)

# 2. Multi-Layer Perceptron (MLP) Model
class MLP(nn.Module):
    def __init__(self, num_features, hidden_dim1=128, hidden_dim2=64):
        super(MLP, self).__init__()
        self.layer_1 = nn.Linear(num_features, hidden_dim1)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(0.3) # 添加Dropout防止过拟合
        self.layer_2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(0.3)
        self.layer_out = nn.Linear(hidden_dim2, 1) # 输出1个logit

    def forward(self, x):
        x = self.relu1(self.layer_1(x))
        x = self.dropout1(x)
        x = self.relu2(self.layer_2(x))
        x = self.dropout2(x)
        x = self.layer_out(x)
        return x

# --- 辅助函数 ---

def set_seed(seed):
    """设置随机种子以确保可复现性"""
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

def load_and_preprocess_spambase(data_path, test_size=0.2, seed=42):
    """加载并预处理Spambase数据集 (假设CSV有header)"""
    try:
        # 读取CSV，告诉pandas第一行是header
        data = pd.read_csv(data_path, header=0)
        print(f"成功加载数据，形状: {data.shape}")
        # 验证最后一列是否为标签列（通常名为 'spam' 或 'is_spam'）
        # 根据你提供的数据格式，最后一列是 'spam'
        if data.columns[-1].lower() != 'spam':
             print(f"警告：期望最后一列名为 'spam'，但找到的是 '{data.columns[-1]}'")
             print("假设最后一列仍为标签列。")

    except FileNotFoundError:
        print(f"错误：未找到数据集文件 '{data_path}'。请确保文件存在。")
        exit(1)
    except Exception as e:
        print(f"加载或初步处理数据集时出错: {e}")
        # 打印列名帮助调试
        try:
            # 尝试读取前几行看看格式
            print("\n文件前几行预览:")
            print(pd.read_csv(data_path, nrows=5))
        except Exception as e2:
            print(f"读取文件预览也失败: {e2}")
        exit(1)

    # 检查数据是否为空
    if data.empty:
        print("错误：加载的数据为空。")
        exit(1)
    # 检查是否有NaN值
    if data.isnull().values.any():
        print("警告：数据中存在NaN值，可能导致问题。考虑进行填充或删除。")
        # 简单处理：用0填充（可能不是最佳策略，但能避免一些错误）
        # data = data.fillna(0)
        # 或者删除包含NaN的行
        # data = data.dropna()
        # print("已尝试处理NaN值。")


    try:
        # 假设最后一列是标签y，其余是特征X
        X = data.iloc[:, :-1].values
        y = data.iloc[:, -1].values

        # 确保y是数值类型 (0或1)
        if not np.issubdtype(y.dtype, np.number):
             print(f"错误：标签列 '{data.columns[-1]}' 包含非数值数据。标签必须是数字 (0 或 1)。")
             # 尝试转换，如果失败则退出
             try:
                 y = y.astype(int) # 或 float
             except ValueError:
                 print("无法将标签列转换为数值类型。请检查数据。")
                 exit(1)


        # --- 调试代码：检查 y 的分布 ---
        unique_labels, counts = np.unique(y, return_counts=True)
        print(f"数据加载后，标签 (y) 的唯一值: {unique_labels}")
        print(f"数据加载后，每个标签的数量: {counts}")
        if len(counts) < 2 or np.any(counts < 2):
             print("错误：在分割数据前，发现某个类别的样本数少于2个。无法进行分层抽样。请检查数据文件或加载逻辑。")
             exit(1)
        # --- 调试代码结束 ---


    except IndexError:
        print("错误：无法从数据中分离特征 (X) 和标签 (y)。检查CSV格式是否正确，是否至少有两列。")
        exit(1)
    except Exception as e:
        print(f"分离X和y或检查y时出错: {e}")
        exit(1)


    # 划分训练集和测试集
    try:
        X_train_full, X_test, y_train_full, y_test = train_test_split(
            X, y, test_size=test_size, random_state=seed, stratify=y # stratify保持类别比例
        )
    except ValueError as e:
         print(f"train_test_split 执行时出错: {e}")
         print("这通常意味着即使在整个数据集中，某个类的样本数也少于进行分割所需的最小数量（通常是2）。")
         print("请再次检查数据文件和之前的标签统计。")
         exit(1)


    # 数据标准化 (只在训练集上fit，然后transform训练集和测试集)
    scaler = StandardScaler()
    # 确保X是数值类型，StandardScaler需要数值输入
    try:
        X_train_full_scaled = scaler.fit_transform(X_train_full.astype(np.float32))
        X_test_scaled = scaler.transform(X_test.astype(np.float32)) # 使用训练集的scaler
    except ValueError as e:
        print(f"StandardScaler 执行时出错: {e}")
        print("这可能意味着特征 (X) 中包含非数值数据。请检查数据文件。")
        exit(1)


    # 转换为PyTorch Tensors
    X_train_full_tensor = torch.tensor(X_train_full_scaled, dtype=torch.float32)
    # 确保y是float类型以匹配BCEWithLogitsLoss
    y_train_full_tensor = torch.tensor(y_train_full, dtype=torch.float32).unsqueeze(1) # BCEWithLogitsLoss需要shape [N, 1]
    X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.float32).unsqueeze(1)

    num_features = X_train_full_tensor.shape[1]

    return X_train_full_tensor, y_train_full_tensor, X_test_tensor, y_test_tensor, num_features

def get_model(model_name, num_features):
    """根据名称获取模型实例"""
    if model_name.lower() == 'logistic':
        return LogisticRegression(num_features)
    elif model_name.lower() == 'mlp':
        return MLP(num_features)
    else:
        raise ValueError(f"未知的模型名称: {model_name}. 可选项: 'logistic', 'mlp'")

def evaluate(model, dataloader, criterion, device):
    """评估模型在给定数据集上的性能"""
    model.eval()  # 设置模型为评估模式
    total_loss = 0.0
    correct_predictions = 0
    total_samples = 0

    with torch.no_grad(): # 在评估时不计算梯度
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            total_loss += loss.item() * inputs.size(0)

            # 将logits转换为概率，然后转换为类别 (0或1)
            predicted_probs = torch.sigmoid(outputs)
            predicted_labels = (predicted_probs > 0.5).float()

            correct_predictions += (predicted_labels == labels).sum().item()
            total_samples += labels.size(0)

    avg_loss = total_loss / total_samples
    accuracy = correct_predictions / total_samples
    return avg_loss, accuracy


# --- 主训练逻辑 ---
def main(args):
    # 1. 设置随机种子
    set_seed(args.seed)

    # 2. 设置设备
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("警告：请求使用CUDA，但CUDA不可用。将使用CPU。")
        args.device = 'cpu'
    device = torch.device(args.device)
    print(f"使用设备: {device}")

    # 3. 加载和预处理数据
    dataset_name = "Spambase"
    data_path = args.data_path # 从命令行获取数据路径
    X_train_full, y_train_full, X_test, y_test, num_features = load_and_preprocess_spambase(
        data_path, seed=args.seed
    )
    print(f"数据集加载完成。特征数量: {num_features}")
    print(f"完整训练集大小: {len(X_train_full)}, 测试集大小: {len(X_test)}")

    # 4. 根据 num_train_samples 调整训练样本数量
    num_train_samples_full = len(X_train_full)
    if args.num_train_samples > 0 and args.num_train_samples <= 1:
        num_train_samples_actual = int(num_train_samples_full * args.num_train_samples)
    elif args.num_train_samples > 1:
        num_train_samples_actual = int(args.num_train_samples)
        if num_train_samples_actual > num_train_samples_full:
             print(f"警告：请求的训练样本数 ({num_train_samples_actual}) 大于可用数量 ({num_train_samples_full})。将使用全部可用训练样本。")
             num_train_samples_actual = num_train_samples_full
    else: # 默认为使用全部数据 (num_train_samples=0 或负数也视为全部)
        print("警告：num_train_samples 值无效或为0，将使用所有训练样本。")
        num_train_samples_actual = num_train_samples_full

    print(f"实际使用的训练样本数量: {num_train_samples_actual}")

    # 创建完整训练数据集
    full_train_dataset = TensorDataset(X_train_full, y_train_full)

    # 如果需要采样，则创建子集
    if num_train_samples_actual < num_train_samples_full:
        # 需要确保采样的索引是固定的（如果种子固定）并且是随机的
        indices = list(range(num_train_samples_full))
        random.shuffle(indices) # 使用 random.shuffle 以利用之前设置的种子
        train_indices = indices[:num_train_samples_actual]
        train_dataset = Subset(full_train_dataset, train_indices)
    else:
        train_dataset = full_train_dataset # 使用完整数据集

    test_dataset = TensorDataset(X_test, y_test)

    # 创建DataLoader
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)

    # 5. 初始化模型、损失函数和优化器
    model = get_model(args.model, num_features).to(device)
    # 使用 BCEWithLogitsLoss，它结合了 Sigmoid 和 BCELoss，更数值稳定
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    print(f"\n开始训练模型: {args.model}")
    print(f"学习率: {args.lr}, Batch Size: {args.batch_size}, Epochs: {args.epochs}")

    # 6. 训练和评估循环
    best_test_accuracy = 0.0
    best_epoch = -1
    all_epoch_results = []

    for epoch in range(args.epochs):
        model.train()  # 设置模型为训练模式
        running_loss = 0.0
        train_samples_count = 0

        for i, (inputs, labels) in enumerate(train_loader):
            inputs, labels = inputs.to(device), labels.to(device)

            # 梯度清零
            optimizer.zero_grad()

            # 前向传播
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # 反向传播和优化
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * inputs.size(0)
            train_samples_count += inputs.size(0)

        epoch_train_loss = running_loss / train_samples_count

        # 在每个epoch结束时进行测试
        epoch_test_loss, epoch_test_accuracy = evaluate(model, test_loader, criterion, device)

        print(f"Epoch [{epoch+1}/{args.epochs}], "
              f"Train Loss: {epoch_train_loss:.4f}, "
              f"Test Loss: {epoch_test_loss:.4f}, "
              f"Test Accuracy: {epoch_test_accuracy:.4f}")

        # 保存当前epoch结果
        epoch_result = {
            'epoch': epoch + 1,
            'train_loss': epoch_train_loss,
            'test_loss': epoch_test_loss,
            'test_accuracy': epoch_test_accuracy
        }
        all_epoch_results.append(epoch_result)

        # 更新最佳结果
        if epoch_test_accuracy > best_test_accuracy:
            best_test_accuracy = epoch_test_accuracy
            best_epoch = epoch + 1
            # 可选：在这里保存最佳模型状态
            # best_model_state = model.state_dict()

    print("\n训练完成！")
    print(f"最佳测试准确率: {best_test_accuracy:.4f} (在 Epoch {best_epoch})")

    # 7. 保存结果
    # 使用实际的整数训练样本数量作为目录名
    result_dir = os.path.join(args.result_base_dir, dataset_name, args.model, str(num_train_samples_actual))
    os.makedirs(result_dir, exist_ok=True)
    result_path = os.path.join(result_dir, 'result.json')

    final_results = {
        'args': vars(args), # 保存运行参数
        'num_actual_train_samples': num_train_samples_actual,
        'best_epoch': best_epoch,
        'best_test_accuracy': best_test_accuracy,
        'all_epoch_results': all_epoch_results
    }

    try:
        with open(result_path, 'w') as f:
            json.dump(final_results, f, indent=4)
        print(f"结果已保存到: {result_path}")
    except Exception as e:
        print(f"保存结果时出错: {e}")

# --- 命令行参数解析 ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='在Spambase数据集上训练PyTorch模型')

    # 更新默认数据路径
    parser.add_argument('--data_path', type=str, default='./data/spambase/spambase.csv',
                        help='Spambase数据集文件 (例如 spambase.csv 或 spambase.data) 的路径')
    parser.add_argument('--model', type=str, required=True, choices=['logistic', 'mlp'],
                        help='要使用的模型名称 (logistic 或 mlp)')
    parser.add_argument('--num_train_samples', type=float, default=1.0,
                        help='用于训练的样本数量或比例 (例如: 0.1 表示10%%, 100 表示100个样本, <=0或>=1.0的整数视为全部)')
    parser.add_argument('--epochs', type=int, default=50,
                        help='训练的总轮数 (epochs)')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='优化器的学习率')
    parser.add_argument('--batch_size', type=int, default=64,
                        help='训练和测试的批次大小')
    parser.add_argument('--seed', type=int, default=42,
                        help='用于复现性的随机种子')
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu', choices=['cuda', 'cpu'],
                        help='运行设备 (cuda 或 cpu)')
    parser.add_argument('--result_base_dir', type=str, default='./results',
                        help='保存结果的基础目录')

    args = parser.parse_args()

    # --- 稍微调整 num_train_samples 的逻辑，使其更清晰 ---
    # 在 main 函数内部处理 num_train_samples 逻辑更合适，但这里先保留原始结构
    # 注意：原始逻辑中 'num_train_samples > 0 and num_train_samples <= 1' 包含了 1.0
    # 如果输入 1.0 应该表示使用 100% 的样本，这部分逻辑没问题。
    # 如果输入 > 1 的整数，表示使用具体样本数。
    # 如果输入 <= 0，表示使用全部样本。

    main(args)