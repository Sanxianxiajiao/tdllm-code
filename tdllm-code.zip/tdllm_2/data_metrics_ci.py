# -*- coding: utf-8 -*-
# --- 0. Import Libraries ---
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns # Added for regplot
import io
import os
import math
from scipy.stats import spearmanr, pearsonr, kendalltau # Added pearsonr, kendalltau
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error, r2_score # Added metrics
import json
import re
from adjustText import adjust_text
# import numpy as np # Already imported
# import math # Already imported
import statsmodels.api as sm
# --- Style Configuration for Plots (Nature Research Paper Style) ---
# Use a clean style suitable for papers
plt.style.use('seaborn-v0_8-paper')

# --- NEW Color Palette (Inspired by the provided image) ---
COLOR_GROUP1_SCATTER = '#f8070b'    # Light Green (for Group 1 points)
COLOR_GROUP2_SCATTER = '#3c1afd'    # Light Orange (for Group 2 points)
COLOR_POWER_LAW_FIT = '#3203c7'     # Muted Blue/Grey (for regression line and CI)
COLOR_ABLATION_BARS = '#ADD3F4'     # Light Blue (for ablation plot bars)
COLOR_FACTOR_LINES = '#FFFFFF'      # Neutral Light Grey (for factor lines like y=x/2)
# Ideal fit line (y=x) will remain 'red' for standard emphasis.

# Define consistent font sizes
TITLE_FONTSIZE = 26
LABEL_FONTSIZE = 24
TICK_FONTSIZE = 22
LEGEND_FONTSIZE = 22
ANNOTATION_FONTSIZE = 24 # For text labels on points/bars

# --- 1. Load the Data from JSON Files ---

# --- 1a. Define Paths ---
data_analysis_dir = '/home/mqc/tdllm_2/data_analys copy/'
min_sample_size_file = '/home/mqc/tdllm_2/min_sample_sizes.json'
features = ['num_classes', 'label_entropy', 'effective_dim', 'intra_class_var', 'local_consistency', 'separability_score']
target = 'min_sample_size'
output_dir = './pic/' # Define output dir earlier for use in saving metrics

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# --- 1b. Load Target Variable (min_sample_size) ---
print(f"Loading target values from {min_sample_size_file}...")
try:
    with open(min_sample_size_file, 'r') as f:
        target_sizes_raw = json.load(f)
    # Create a mapping from lowercase task name to target value for easier matching
    target_sizes_lower = {k.lower(): v for k, v in target_sizes_raw.items()}
    print(f"Successfully loaded target values for {len(target_sizes_lower)} tasks.")
except FileNotFoundError:
    print(f"Error: Target file not found {min_sample_size_file}")
    exit()
except json.JSONDecodeError:
    print(f"Error: Could not parse target file {min_sample_size_file}")
    exit()

# --- 1c. Load Complexity Metrics from Individual Files ---
print(f"\nLoading complexity metrics from directory {data_analysis_dir}...")
all_task_data = []
files_processed = 0
files_skipped_json_error = 0
files_skipped_missing_metrics = 0
files_skipped_no_match = 0

if not os.path.isdir(data_analysis_dir):
    print(f"Error: Metrics directory not found {data_analysis_dir}")
    exit()

for filename in os.listdir(data_analysis_dir):
    if filename.endswith('.json'):
        files_processed += 1
        filepath = os.path.join(data_analysis_dir, filename)

        # Extract task name (try removing common suffixes and convert to lowercase)
        task_name_match = re.match(r'([a-zA-Z0-9_\-]+?)(_complexity_metrics|_metrics)?\.json', filename)
        if not task_name_match:
            # Fallback: try matching based on known target task names before giving up
            base_name = filename.replace('.json', '').lower()
            matched_target = None
            for target_task_name in target_sizes_lower.keys():
                if base_name == target_task_name or base_name.startswith(target_task_name + '_'):
                     matched_target = target_task_name
                     break
            if matched_target:
                 task_name = matched_target
            else:
                # print(f"  - Warning: Could not extract standard task name from filename '{filename}' using primary or fallback logic, skipping.") # Muted warning
                files_skipped_no_match += 1
                continue
        else:
             task_name = task_name_match.group(1).lower() # Convert to lowercase for matching


        try:
            with open(filepath, 'r') as f:
                data = json.load(f)

            metrics_data = {}
            extracted = False
            # Try different JSON structures to extract metrics
            # Structure 1: Metrics directly at the root
            if all(feature in data for feature in features):
                metrics_data = {feature: data.get(feature) for feature in features}
                extracted = True
            # Structure 2: Metrics inside 'complexity_metrics' key
            elif 'complexity_metrics' in data and isinstance(data['complexity_metrics'], dict):
                 raw_metrics = data['complexity_metrics']
                 has_all_features = True
                 temp_metrics = {}
                 for f_val in features: # Renamed f to f_val to avoid conflict with file handle f
                     if f_val in raw_metrics:
                         temp_metrics[f_val] = raw_metrics.get(f_val)
                     elif f_val == 'intra_class_var' and 'intra_class_var_avg' in raw_metrics: # Handle alternative key name
                         temp_metrics[f_val] = raw_metrics.get('intra_class_var_avg')
                     else:
                         has_all_features = False
                         break
                 if has_all_features:
                     metrics_data = temp_metrics
                     extracted = True
            # Structure 3: Metrics inside 'metrics' key
            elif 'metrics' in data and isinstance(data['metrics'], dict):
                 raw_metrics = data['metrics']
                 has_all_features = True
                 temp_metrics = {}
                 for f_val in features: # Renamed f to f_val
                     if f_val in raw_metrics:
                         temp_metrics[f_val] = raw_metrics.get(f_val)
                     elif f_val == 'intra_class_var' and 'intra_class_var_avg' in raw_metrics: # Handle alternative key name
                         temp_metrics[f_val] = raw_metrics.get('intra_class_var_avg')
                     else:
                         has_all_features = False
                         break
                 if has_all_features:
                     metrics_data = temp_metrics
                     extracted = True

            # Check if all 6 metrics were successfully extracted and their values are not None or invalid numbers
            if extracted and all(metrics_data.get(f_val) is not None and np.isfinite(pd.to_numeric(metrics_data.get(f_val), errors='coerce')) for f_val in features): # Renamed f to f_val
                # Convert to float after validation
                for f_val in features: # Renamed f to f_val
                     metrics_data[f_val] = float(metrics_data[f_val])
                metrics_data['task_name_in_json'] = task_name
                all_task_data.append(metrics_data)
            elif extracted:
                 # print(f"  - Warning: File '{filename}' (task '{task_name}') extracted metric structure, but some values are None or non-finite, skipping.") # Muted warning
                 files_skipped_missing_metrics += 1
            else:
                # print(f"  - Warning: File '{filename}' (task '{task_name}') did not find all required metrics or structure was unrecognized, skipping.") # Muted warning
                files_skipped_missing_metrics += 1 # Count skipped files

        except json.JSONDecodeError:
            # print(f"  - Warning: Could not parse JSON file '{filename}', skipping.") # Muted warning
            files_skipped_json_error += 1
        except Exception as e:
            print(f"  - Warning: An unknown error occurred while processing file '{filename}': {e}, skipping.")
            files_skipped_json_error += 1

print(f"\nProcessed {files_processed} JSON files.")
if files_skipped_json_error > 0:
    print(f"Skipped {files_skipped_json_error} files due to JSON parsing or other reading errors.")
if files_skipped_missing_metrics > 0:
    print(f"Skipped {files_skipped_missing_metrics} files due to missing, None, or non-finite required metric data.")
if files_skipped_no_match > 0:
     print(f"Skipped {files_skipped_no_match} files because a valid task name could not be extracted from the filename.")


# --- 1d. Create DataFrame and Merge with Target ---
if not all_task_data:
     print("\nError: Failed to load any valid metric data from JSON files. Please check file contents and paths.")
     exit()

df_metrics = pd.DataFrame(all_task_data)
if df_metrics['task_name_in_json'].duplicated().any():
    print("\nWarning: Duplicate task names detected after processing filenames. Keeping the first occurrence.")
    print("Duplicate task names:", df_metrics[df_metrics['task_name_in_json'].duplicated()]['task_name_in_json'].tolist())
    df_metrics = df_metrics.drop_duplicates(subset='task_name_in_json', keep='first')

df_metrics.set_index('task_name_in_json', inplace=True)

# Ensure target values are numeric, coercing errors
target_sizes_numeric = {k: pd.to_numeric(v, errors='coerce') for k, v in target_sizes_lower.items()}
# Filter out any tasks where target became NaN
target_sizes_valid = {k: v for k, v in target_sizes_numeric.items() if pd.notna(v)}
tasks_with_invalid_target = len(target_sizes_lower) - len(target_sizes_valid)
if tasks_with_invalid_target > 0:
    print(f"  - Warning: Removed {tasks_with_invalid_target} tasks from target list due to non-numeric values.")

df_target = pd.Series(target_sizes_valid, name=target)
df_target.index.name = 'task_name_in_json' # Keep index names consistent

# Perform the merge
df = pd.merge(df_metrics, df_target, left_index=True, right_index=True, how='inner')

# --- 1e. Report Loaded Data ---
print("\n--- Loaded and Merged Data Preview (Lowercase Task Name Index) ---")
print(f"\nSuccessfully loaded and merged data for {len(df)} tasks (containing all valid metrics and target values).")

# Final check for NaNs in the merged DataFrame (shouldn't happen after pre-filtering)
if df.isnull().values.any():
    print("\nWarning: NaN values found unexpectedly in the final merged DataFrame!")
    print(df[df.isnull().any(axis=1)])
    df.dropna(inplace=True) # Drop rows with any NaNs if they exist unexpectedly


# --- 2. Assign Groups ---
original_group1_tasks = ['adult', 'fashionmnist', 'cifar10', 'svhn', 'mnist', 'speech_commands']
new_group1_tasks = [
    'stl10', 'olivetti_faces', 'food101', 'clutrr', 'oxfordiiitpet',
    'digits', 'flowers102', 'fgvc_aircraft', 'dtd', 'semeion',
    'kmnist', 'usps', 'spambase', 'cifar100',
    'clutrr_k2', 'clutrr_k3', 'clutrr_k4',
]
group2_tasks = ['sem_eval_2010_task_8', 'sciq', 'piqa', 'aqua_rat', 'ag_news', 'conll2003']
group1_tasks_lower = [t.lower() for t in original_group1_tasks + new_group1_tasks]
group2_tasks_lower = [t.lower() for t in group2_tasks]
group1_name = 'Group 1 (Mixed Tasks)'
group2_name = 'Group 2 (NLP or Reasoning)'

assigned_tasks_count = {'Group 1': 0, 'Group 2': 0}
def assign_group(task_name):
    task_name_lower = task_name.lower()
    if task_name_lower in group2_tasks_lower:
        assigned_tasks_count['Group 2'] += 1
        return group2_name
    else:
        assigned_tasks_count['Group 1'] += 1
        return group1_name

df['group'] = df.index.map(assign_group)

print(f"\nAll {len(df)} loaded tasks have been assigned: {assigned_tasks_count['Group 1']} to '{group1_name}', {assigned_tasks_count['Group 2']} to '{group2_name}'.")

if df.empty:
    print("\nError: No tasks available for prediction and analysis after loading and merging.")
    exit()

# --- 3. Define Prediction Functions (Same as before, with robustness) ---

# import numpy as np # Already imported
# import pandas as pd # Assuming 'row' is a pandas Series # Already imported
# import math # Already imported

# --- Helper function to safely get values from row ---
def safe_get(row, key, default=0.0):
    val = row.get(key, default)
    if val is None or not np.isfinite(val):
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default

# --- Prediction Function for Group 1 (Using the derived "neat" constants) ---
def predict_min_sample_size_manual_group1(row):
    # --- Group 1 "Neat" Constants ---
    # K-Difficulty Components:
    W_K_LD_G1 = 1e-1
    W_K_SD_G1 = 4e0
    K_DIFFICULTY_BASE_G1 = 1e0

    # D-Difficulty Components:
    W_D_ED_G1 = 1e0
    W_D_VD_G1 = 1e0
    W_D_ND_G1 = 1e0
    W_D_HY_G1 = 1e0
    D_DIFFICULTY_BASE_G1 = 1e0

    # L-Clarity Components:
    W_L_LD_G1 = 1e0   # 1.0
    W_L_SD_G1 = 1e0   # 1.0
    W_L_VD_G1 = 1e0   # 1.0
    W_L_HY_G1 = 1e0   # 1.0
    # L_CLARITY_OFFSET_G1 = 1e0 # This might not be needed if L is in denominator directly, or it acts as a regularizer. Let's see.

    # Overall Scaling and Base Constant:
    C_SCALE_G1 = 8e0 # Renamed from C_OVERALL_G1 for clarity with the formula
    C_BASE_G1 = 0e0 # Base offset, can be adjusted. For now, let's assume it's part of the floor or zero.
                     # The original MIN_PREDICTION_FLOOR_G1 acts like a base offset applied at the end.

    # Log Term Control (for K log K, K should be > 1 or handled)
    MIN_K_FOR_LOG_G1 = 1e0 # Ensures K in K log K is > 1 to avoid log(negative/zero) or small log values

    # Prediction Floor:
    MIN_PREDICTION_FLOOR_G1 = 1e2 # 100.0
    # --- End of Constants ---

    # --- Extract Proxies ---
    l_d = safe_get(row, 'local_consistency', 0.5)
    s_d = safe_get(row, 'separability_score', 0.0)
    e_d = safe_get(row, 'effective_dim', 10.0)
    v_d = safe_get(row, 'intra_class_var', 1.0)
    n_d = safe_get(row, 'num_classes', 2.0)
    H_Y = safe_get(row, 'label_entropy', 0.7)

    # --- Calculate K_difficulty_approx (This will be our 'K' proxy for K log K) ---
    k_comp_ld = W_K_LD_G1 * max(0.001, (1.001 - l_d))
    k_comp_sd = W_K_SD_G1 * max(0.001, (0.251 - s_d)) # Assuming 0.25 is a neutral/good s_d
    K_difficulty_approx = K_DIFFICULTY_BASE_G1 + k_comp_ld + k_comp_sd
    K_difficulty_approx_for_log = max(MIN_K_FOR_LOG_G1, K_difficulty_approx) # Ensure K > 1 for log

    # --- Calculate D_difficulty_approx (This will be our 'D' proxy) ---
    D_difficulty_approx = (D_DIFFICULTY_BASE_G1 +
                           W_D_ED_G1 * e_d +
                           W_D_VD_G1 * v_d +
                           W_D_ND_G1 * n_d +
                           W_D_HY_G1 * H_Y)
    D_difficulty_approx = max(0.001, D_difficulty_approx)

    # --- Calculate L_clarity_approx (This will be our 'L' proxy, higher means better clarity) ---
    l_comp_ld = W_L_LD_G1 * l_d
    l_comp_sd = W_L_SD_G1 * (s_d + 1.001)
    l_comp_vd = W_L_VD_G1 * (1.0 / (1.001 + max(0, v_d)))
    l_comp_hy = W_L_HY_G1 * (1.0 / (1.001 + max(0, H_Y)))
    L_clarity_approx = l_comp_ld + l_comp_sd + l_comp_vd + l_comp_hy
    L_clarity_approx = max(0.001, L_clarity_approx) # Ensure L_clarity is positive for denominator

    # --- MODIFIED SECTION: Apply the K logK * D / L structure ---

    k_log_k_term = K_difficulty_approx_for_log * np.log(K_difficulty_approx_for_log)
    numerator_core = k_log_k_term * D_difficulty_approx
    effective_L_denominator = max(0.001, L_clarity_approx)
    unfloored_prediction = (C_SCALE_G1 * numerator_core) / effective_L_denominator
    predicted_N_min = C_BASE_G1 + unfloored_prediction
    predicted_N_min = max(MIN_PREDICTION_FLOOR_G1, predicted_N_min)

    if not np.isfinite(predicted_N_min):
        return MIN_PREDICTION_FLOOR_G1 * 10
    return predicted_N_min

# --- Prediction Function for Group 2 (Using the derived "neat" constants) ---
def predict_min_sample_size_manual_group2(row):
    # --- Group 2 "Neat" Constants (Adjusted for NLP/Reasoning potentially) ---
    # K-Difficulty Components: (Example: NLP might be less sensitive to s_d, more to l_d)
    W_K_LD_G2 = 1e-1 # Kept same as G1 for now, could differ
    W_K_SD_G2 = 1e-1 # Potentially lower weight for s_d if less relevant
    K_DIFFICULTY_BASE_G2 = 1e0

    # D-Difficulty Components: (Example: H_Y, n_d might be more influential)
    W_D_ED_G2 = 1e-1 # Kept same
    W_D_VD_G2 = 1e-1 # Kept same
    W_D_ND_G2 = 1e-1 # Kept same
    W_D_HY_G2 = 1e-1 # Kept same
    D_DIFFICULTY_BASE_G2 = 1e0

    # L-Clarity Components:
    W_L_LD_G2 = 1e0
    W_L_SD_G2 = 1e0
    W_L_VD_G2 = 1e0
    W_L_HY_G2 = 1e0
    L_CLARITY_OFFSET_G2 = 1e0 # Kept same

    # Overall Scaling and Log Term Control:
    C_OVERALL_G2 = 8e0 # May need different overall scaling for G2
    MIN_EFFECTIVE_DIFFICULTY_FOR_LOG_G2 = 1.1e0

    # Prediction Floor:
    MIN_PREDICTION_FLOOR_G2 = 1e2 # Kept same, could differ
    # --- End of Constants ---

    # --- Extract Proxies ---
    l_d = safe_get(row, 'local_consistency', 0.5)
    s_d = safe_get(row, 'separability_score', 0.0)
    e_d = safe_get(row, 'effective_dim', 10.0)
    v_d = safe_get(row, 'intra_class_var', 1.0)
    n_d = safe_get(row, 'num_classes', 2.0)
    H_Y = safe_get(row, 'label_entropy', 0.7)

    # --- Calculate K_difficulty_approx ---
    k_comp_ld = W_K_LD_G2 * max(0.001, (1.001 - l_d))
    k_comp_sd = W_K_SD_G2 * max(0.001, (0.251 - s_d))
    K_difficulty_approx = K_DIFFICULTY_BASE_G2 + k_comp_ld + k_comp_sd
    K_difficulty_approx = max(0.001, K_difficulty_approx)

    # --- Calculate D_difficulty_approx ---
    D_difficulty_approx = (D_DIFFICULTY_BASE_G2 +
                           W_D_ED_G2 * e_d +
                           W_D_VD_G2 * v_d +
                           W_D_ND_G2 * n_d +
                           W_D_HY_G2 * H_Y)
    D_difficulty_approx = max(0.001, D_difficulty_approx)

    # --- Calculate L_clarity_approx (higher means better clarity) ---
    l_comp_ld = W_L_LD_G2 * l_d
    l_comp_sd = W_L_SD_G2 * (s_d + 1.001)
    l_comp_vd = W_L_VD_G2 * (1.0 / (1.001 + max(0, v_d)))
    l_comp_hy = W_L_HY_G2 * (1.0 / (1.001 + max(0, H_Y)))
    L_clarity_approx = l_comp_ld + l_comp_sd + l_comp_vd + l_comp_hy
    L_clarity_approx = max(0.001, L_clarity_approx)

    # --- Combine K and D for the log term ---
    Effective_Difficulty_K_D = K_difficulty_approx * D_difficulty_approx
    Effective_Difficulty_K_D = max(MIN_EFFECTIVE_DIFFICULTY_FOR_LOG_G2, Effective_Difficulty_K_D)

    k_log_k_term = Effective_Difficulty_K_D * np.log(Effective_Difficulty_K_D)

    numerator = C_OVERALL_G2 * k_log_k_term
    denominator = L_CLARITY_OFFSET_G2 + L_clarity_approx

    if abs(denominator) < 1e-9:
        predicted_N_min = MIN_PREDICTION_FLOOR_G2 * 1000
    else:
        predicted_N_min = numerator / denominator

    predicted_N_min = max(MIN_PREDICTION_FLOOR_G2, predicted_N_min)
    if not np.isfinite(predicted_N_min):
        return MIN_PREDICTION_FLOOR_G2 * 10
    return predicted_N_min

# --- 4. Calculate Original Predictions ---
print("\n--- Calculating Original Predictions ---")
df['predicted_min_sample_size_grouped'] = df.apply(
    lambda row: predict_min_sample_size_manual_group1(row) if row['group'] == group1_name
    else predict_min_sample_size_manual_group2(row) if row['group'] == group2_name
    else np.nan,
    axis=1
)
print("Original predictions calculated.")

# --- 5. Calculate Original Evaluation Metrics ---
df[target] = pd.to_numeric(df[target], errors='coerce')
initial_rows = len(df)
valid_df = df.dropna(subset=[target, 'predicted_min_sample_size_grouped']).copy()
dropped_rows = initial_rows - len(valid_df)
if dropped_rows > 0:
    print(f"Dropped {dropped_rows} rows from original data due to missing/invalid target values or prediction errors.")

evaluation_metrics = {}

if len(valid_df) < 2:
    print(f"\nError: Insufficient valid data points ({len(valid_df)}) after dropping NaNs from original predictions, cannot calculate evaluation metrics or perform ablation.")
    exit()
else:
    true_values = valid_df[target].astype(float)
    predicted_values = valid_df['predicted_min_sample_size_grouped'].astype(float)
    evaluation_metrics['num_initial_samples'] = initial_rows
    evaluation_metrics['num_valid_samples'] = len(valid_df)

    print("\n--- Evaluation Metrics (Original - Combined Groups) ---")
    print(f"Based on {len(valid_df)} valid data points:")

    print("\n-- Correlation Metrics --")
    spearman_corr, spearman_p = spearmanr(true_values, predicted_values)
    evaluation_metrics['spearman_rho'] = spearman_corr
    evaluation_metrics['spearman_p'] = spearman_p
    print(f"Spearman Rank Correlation (rho): {spearman_corr:.4f}, p-value: {spearman_p:.4f}")

    pearson_corr, pearson_p = pearsonr(true_values, predicted_values)
    evaluation_metrics['pearson_r'] = pearson_corr
    evaluation_metrics['pearson_p'] = pearson_p
    print(f"Pearson Correlation (r):        {pearson_corr:.4f}, p-value: {pearson_p:.4f}")

    kendall_tau, kendall_p = kendalltau(true_values, predicted_values)
    evaluation_metrics['kendall_tau'] = kendall_tau
    evaluation_metrics['kendall_p'] = kendall_p
    print(f"Kendall's Tau (tau):          {kendall_tau:.4f}, p-value: {kendall_p:.4f}")

    print("\n-- Prediction Error Metrics --")
    mae = mean_absolute_error(true_values, predicted_values)
    mse = mean_squared_error(true_values, predicted_values)
    rmse = np.sqrt(mse)
    non_zero_mask = true_values != 0
    mape = np.nan # Initialize mape
    if np.any(non_zero_mask):
        pred_for_mape = predicted_values[non_zero_mask].copy()
        pred_for_mape[pred_for_mape <= 0] = 1e-9
        if len(true_values[non_zero_mask]) > 0 : # Ensure there are values to calculate MAPE on
             mape = mean_absolute_percentage_error(true_values[non_zero_mask], pred_for_mape) * 100
    r2 = r2_score(true_values, predicted_values)

    evaluation_metrics['mae'] = mae
    evaluation_metrics['rmse'] = rmse
    evaluation_metrics['mape'] = mape if not np.isnan(mape) else None
    evaluation_metrics['r2'] = r2

    print(f"Mean Absolute Error (MAE):    {mae:.2f}")
    print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
    if evaluation_metrics['mape'] is not None: # Check if mape was successfully calculated
        print(f"Mean Absolute Percentage Error (MAPE): {evaluation_metrics['mape']:.2f}%")
    else:
         print("Mean Absolute Percentage Error (MAPE): N/A")
    print(f"R-squared (R²):               {r2:.4f}")

    print("\n-- Within-Group Spearman Correlations (Baseline) --")
    valid_df_g1 = valid_df[valid_df['group'] == group1_name].copy()
    valid_df_g2 = valid_df[valid_df['group'] == group2_name].copy()
    evaluation_metrics['num_valid_samples_g1'] = len(valid_df_g1)
    evaluation_metrics['num_valid_samples_g2'] = len(valid_df_g2)

    original_spearman_rho_g1, original_spearman_p_g1 = np.nan, np.nan
    if len(valid_df_g1) >= 2:
        original_spearman_rho_g1, original_spearman_p_g1 = spearmanr(valid_df_g1[target].astype(float), valid_df_g1['predicted_min_sample_size_grouped'].astype(float))
        evaluation_metrics['spearman_rho_g1'] = original_spearman_rho_g1
        evaluation_metrics['spearman_p_g1'] = original_spearman_p_g1
        print(f"{group1_name} ({len(valid_df_g1)} points): Baseline rho={original_spearman_rho_g1:.4f}, p-value={original_spearman_p_g1:.4f}")
    else:
        evaluation_metrics['spearman_rho_g1'] = np.nan; evaluation_metrics['spearman_p_g1'] = np.nan
        print(f"{group1_name} has insufficient data ({len(valid_df_g1)} points) for baseline correlation.")

    original_spearman_rho_g2, original_spearman_p_g2 = np.nan, np.nan
    if len(valid_df_g2) >= 2:
        original_spearman_rho_g2, original_spearman_p_g2 = spearmanr(valid_df_g2[target].astype(float), valid_df_g2['predicted_min_sample_size_grouped'].astype(float))
        evaluation_metrics['spearman_rho_g2'] = original_spearman_rho_g2
        evaluation_metrics['spearman_p_g2'] = original_spearman_p_g2
        print(f"{group2_name} ({len(valid_df_g2)} points): Baseline rho={original_spearman_rho_g2:.4f}, p-value={original_spearman_p_g2:.4f}")
    else:
        evaluation_metrics['spearman_rho_g2'] = np.nan; evaluation_metrics['spearman_p_g2'] = np.nan
        print(f"{group2_name} has insufficient data ({len(valid_df_g2)} points) for baseline correlation.")

# --- 6. Ablation Study Functions ---
def run_ablation_study(group_df, group_name, prediction_func, original_rho, features_list, target_col):
    """Performs ablation study for a specific group and prediction function."""
    print(f"\n--- Starting Ablation Study for {group_name} ---")
    ablation_results = {}

    if group_df.empty or len(group_df) < 2:
        print(f"Skipping ablation for {group_name}: Insufficient data ({len(group_df)} points).")
        return None
    if np.isnan(original_rho):
        print(f"Skipping ablation for {group_name}: Original Spearman correlation is NaN.")
        return None

    print(f"Original Spearman Rho for {group_name} (using {len(group_df)} tasks): {original_rho:.4f}")
    true_values_group = group_df[target_col].astype(float)

    for feature_to_ablate in features_list:
        print(f"  Ablating feature: {feature_to_ablate}")
        df_ablated = group_df.copy()
        if feature_to_ablate in df_ablated.columns:
            df_ablated[feature_to_ablate] = 0.0
        else:
            print(f"    Warning: Feature '{feature_to_ablate}' not found in {group_name} DataFrame columns. Skipping.")
            ablation_results[feature_to_ablate] = {'ablated_rho': np.nan, 'abs_change': np.nan}
            continue

        df_ablated['predicted_ablated'] = df_ablated.apply(prediction_func, axis=1)
        df_ablated.dropna(subset=['predicted_ablated'], inplace=True)
        aligned_true_values = true_values_group.loc[df_ablated.index]
        ablated_rho, abs_change = np.nan, np.nan
        num_compared = len(df_ablated)

        if num_compared < 2:
            print(f"    Warning: Insufficient valid data points ({num_compared}) remaining after ablating '{feature_to_ablate}' and calculating predictions in {group_name}. Cannot calculate correlation.")
        else:
            try:
                ablated_rho, ablated_p = spearmanr(aligned_true_values, df_ablated['predicted_ablated'])
                if not np.isfinite(ablated_rho):
                    print(f"    Warning: Spearman calculation returned non-finite result for ablated '{feature_to_ablate}' in {group_name}.")
                    ablated_rho = np.nan
                else:
                    abs_change = abs(original_rho - ablated_rho)
                    print(f"    Ablated Spearman Rho: {ablated_rho:.4f}, Absolute Change: {abs_change:.4f} (using {num_compared} tasks)")
            except ValueError as ve:
                print(f"    Error calculating Spearman for ablated '{feature_to_ablate}' in {group_name}: {ve}.")
                ablated_rho = np.nan
        ablation_results[feature_to_ablate] = {'ablated_rho': ablated_rho, 'abs_change': abs_change}
    return ablation_results

def plot_ablation_results(ablation_data, group_name, output_dir_path):
    """Plots the ablation study results as a bar chart using new color style."""
    if ablation_data is None:
        print(f"\nNo ablation data to plot for {group_name}.")
        return None
    ablation_df = pd.DataFrame(ablation_data).T
    ablation_df.dropna(subset=['abs_change'], inplace=True)
    if ablation_df.empty:
        print(f"\nWarning: No valid ablation results to plot for {group_name} after handling NaNs.")
        return None
    ablation_df.sort_values('abs_change', ascending=False, inplace=True)
    plt.figure(figsize=(10, 6))
    bars = plt.bar(ablation_df.index, ablation_df['abs_change'], color=COLOR_ABLATION_BARS, edgecolor='black', linewidth=0.8) # Use new color
    plt.xlabel("Ablated Feature (Set to 0)", fontsize=LABEL_FONTSIZE)
    plt.ylabel("Absolute Change in Spearman Rho", fontsize=LABEL_FONTSIZE)
    plt.title(f"Impact of Ablating Features ({group_name})", fontsize=TITLE_FONTSIZE)
    plt.xticks(rotation=45, ha='right', fontsize=TICK_FONTSIZE)
    plt.yticks(fontsize=TICK_FONTSIZE)
    plt.grid(axis='y', linestyle='--', alpha=0.6, linewidth=0.5)
    plt.tight_layout(pad=1.5)
    for bar in bars:
        yval = bar.get_height()
        if not np.isnan(yval):
            plt.text(bar.get_x() + bar.get_width()/2.0, yval, f'{yval:.3f}',
                     va='bottom', ha='center', fontsize=ANNOTATION_FONTSIZE - 4, # Slightly smaller label font
                     color='black',
                     fontweight='normal')
    plot_filename = f'ablation_study_spearman_change_{group_name.replace(" ", "_").replace("(", "").replace(")", "").lower()[:15]}_new_style.png' # Adjusted filename length
    ablation_plot_path = os.path.join(output_dir_path, plot_filename)
    print(ablation_plot_path)

    plt.savefig(ablation_plot_path, dpi=300, bbox_inches='tight')
    print(f"\nAblation study result plot for {group_name} saved to {ablation_plot_path}")
    plt.close()
    print(f"\n--- Ablation Study Summary ({group_name} - Sorted by Impact) ---")
    print(ablation_df[['abs_change', 'ablated_rho']].to_string(float_format="%.4f"))
    return ablation_df

# --- 7. Run Separate Ablation Studies ---
ablation_results_g1 = run_ablation_study(
    group_df=valid_df_g1, group_name=group1_name,
    prediction_func=predict_min_sample_size_manual_group1,
    original_rho=original_spearman_rho_g1, features_list=features, target_col=target)
ablation_results_g2 = run_ablation_study(
    group_df=valid_df_g2, group_name=group2_name,
    prediction_func=predict_min_sample_size_manual_group2,
    original_rho=original_spearman_rho_g2, features_list=features, target_col=target)

# --- 8. Visualize Ablation Results ---
ablation_df_g1 = plot_ablation_results(ablation_results_g1, group1_name, output_dir)
ablation_df_g2 = plot_ablation_results(ablation_results_g2, group2_name, output_dir)

# --- 9. Visualize Original Results (Main Scatter Plot - New Style) ---
output_path = os.path.join(output_dir, 'manual_prediction_grouped_vs_actual_NEW_STYLE_CI_no_ideal_bold_border_ticks.png') # Update filename
plt.figure(figsize=(14, 12))
# Use new colors for groups
colors_scatter = {group1_name: COLOR_GROUP1_SCATTER, group2_name: COLOR_GROUP2_SCATTER}
markers = {group1_name: 'o', group2_name: 's'} # Markers can remain the same

if not valid_df.empty:
    plot_df = valid_df.copy()
    plot_df[target] = pd.to_numeric(plot_df[target], errors='coerce')
    plot_df['predicted_min_sample_size_grouped'] = pd.to_numeric(plot_df['predicted_min_sample_size_grouped'], errors='coerce')

    plot_df_filtered = plot_df[(plot_df[target] > 1e-9) & (plot_df['predicted_min_sample_size_grouped'] > 1e-9)].copy()
    plot_df_filtered = plot_df_filtered.dropna(subset=[target, 'predicted_min_sample_size_grouped'])

    if not plot_df_filtered.empty and len(plot_df_filtered) >= 2:
        true_values_orig = plot_df_filtered[target]
        predicted_values_orig = plot_df_filtered['predicted_min_sample_size_grouped']

        min_val_plot = max(1, min(true_values_orig.min(), predicted_values_orig.min()))
        max_val_plot = max(true_values_orig.max(), predicted_values_orig.max())

        padding_factor_lower = 0.5
        padding_factor_upper = 2.0
        _temp_min_x_candidate1 = min_val_plot * padding_factor_lower
        _temp_min_x_candidate2 = 40 if min_val_plot > 100 else min_val_plot*0.8
        x_min_plot = max(1e-9, _temp_min_x_candidate1, _temp_min_x_candidate2)

        y_min_plot_candidate1 = min_val_plot * padding_factor_lower
        y_min_plot_candidate2 = 40 if min_val_plot > 100 else min_val_plot*0.8
        y_min_plot = max(1e-9, y_min_plot_candidate1, y_min_plot_candidate2)

        x_max_plot = max_val_plot * padding_factor_upper
        y_max_plot = max_val_plot * padding_factor_upper

        plt.xlim(x_min_plot, x_max_plot)
        plt.ylim(y_min_plot, y_max_plot)

        line_min_ideal = min(x_min_plot, y_min_plot)
        line_max_ideal = max(x_max_plot, y_max_plot)
        line_x_ideal = np.array([max(1e-9, line_min_ideal), line_max_ideal])

        # plt.plot(line_x_ideal, line_x_ideal, color='red', linestyle='--', linewidth=1.5, label='Ideal Fit (y=x)', zorder=2) # Ideal fit line removed

        plt.plot(line_x_ideal, line_x_ideal * 2, color=COLOR_FACTOR_LINES, linestyle=':', linewidth=1.0, alpha=0.8, label='Factor of 2', zorder=1)
        plt.plot(line_x_ideal, line_x_ideal / 2, color=COLOR_FACTOR_LINES, linestyle=':', linewidth=1.0, alpha=0.8, zorder=1)
        plt.plot(line_x_ideal, line_x_ideal * 5, color=COLOR_FACTOR_LINES, linestyle=':', linewidth=0.8, alpha=0.6, label='Factor of 5', zorder=1)
        plt.plot(line_x_ideal, line_x_ideal / 5, color=COLOR_FACTOR_LINES, linestyle=':', linewidth=0.8, alpha=0.6, zorder=1)

        log_true_values = np.log(true_values_orig)
        log_predicted_values = np.log(predicted_values_orig)

        X_log = sm.add_constant(log_true_values)
        model = sm.OLS(log_predicted_values, X_log)
        results = model.fit()

        log_x_fit_points_extended = np.linspace(np.log(x_min_plot), np.log(x_max_plot), 200)
        X_fit_log_sm = sm.add_constant(log_x_fit_points_extended)

        predictions_log = results.get_prediction(X_fit_log_sm)
        summary_frame_log = predictions_log.summary_frame(alpha=0.01)

        x_fit_orig = np.exp(log_x_fit_points_extended)
        y_fit_orig = np.exp(summary_frame_log['mean'])
        ci_lower_orig = np.exp(summary_frame_log['mean_ci_lower'])
        ci_upper_orig = np.exp(summary_frame_log['mean_ci_upper'])

        sort_indices = np.argsort(x_fit_orig)
        x_fit_orig_sorted = x_fit_orig[sort_indices]
        y_fit_orig_sorted = y_fit_orig.iloc[sort_indices] if isinstance(y_fit_orig, pd.Series) else y_fit_orig[sort_indices]
        ci_lower_orig_sorted = ci_lower_orig.iloc[sort_indices] if isinstance(ci_lower_orig, pd.Series) else ci_lower_orig[sort_indices]
        ci_upper_orig_sorted = ci_upper_orig.iloc[sort_indices] if isinstance(ci_upper_orig, pd.Series) else ci_upper_orig[sort_indices]

        ax = plt.gca()
        ax.plot(x_fit_orig_sorted, y_fit_orig_sorted, color=COLOR_POWER_LAW_FIT, linestyle='-', linewidth=2.0, label='Power Law Fit (99% CI)', zorder=3)
        ax.fill_between(x_fit_orig_sorted, ci_lower_orig_sorted, ci_upper_orig_sorted, color=COLOR_POWER_LAW_FIT, alpha=0.2, zorder=3)

        for group_name_key, group_df_plot in plot_df_filtered.groupby('group'):
            if group_name_key in colors_scatter:
                plt.scatter(group_df_plot[target], group_df_plot['predicted_min_sample_size_grouped'],
                            alpha=0.85,
                            edgecolors='k', linewidths=0.7,
                            s=200,
                            c=colors_scatter[group_name_key],
                            marker=markers[group_name_key],
                            label=f"{group_name_key} (N={len(group_df_plot)})",
                            zorder=4)

        plt.xscale('log')
        plt.yscale('log')

        # --- MODIFICATION: Adjust major tick parameters ---
        major_tick_length = 12   # 刻度线长度 (e.g., 8, 10)
        major_tick_width = 2.5  # 刻度线宽度/粗细 (e.g., 1.5, 2)
        plt.tick_params(axis='both', which='major',
                        labelsize=TICK_FONTSIZE,
                        pad=7,
                        length=major_tick_length, # 新增：设置主刻度线长度
                        width=major_tick_width)   # 新增：设置主刻度线宽度
        # --- END MODIFICATION ---

        plt.tick_params(axis='both', which='minor', length=4, color='grey', width=0.5) # Minor ticks remain unchanged or adjust as needed

        texts = []
        for i, task_name in enumerate(plot_df_filtered.index):
            x_pos = plot_df_filtered[target].iloc[i]
            y_pos = plot_df_filtered['predicted_min_sample_size_grouped'].iloc[i]
            x_offset_factor = 1.15; y_offset_factor = 1.05
            tn_lower = task_name.lower()
            if tn_lower == 'aqua_rat': y_offset_factor = 1.3; x_offset_factor = 0.9
            if tn_lower == 'sciq': y_offset_factor = 0.8; x_offset_factor = 0.9
            if tn_lower == 'adult': x_offset_factor = 0.85; y_offset_factor = 0.9
            if tn_lower == 'ag_news': y_offset_factor = 0.85; x_offset_factor = 1.1
            if tn_lower == 'mnist': y_offset_factor = 1.15; x_offset_factor = 0.85
            if tn_lower == 'sem_eval_2010_task_8': y_offset_factor = 1.1; x_offset_factor = 0.8
            if tn_lower == 'fashionmnist': y_offset_factor = 0.85; x_offset_factor=1.05
            if tn_lower == 'spambase': x_offset_factor = 1.2
            if tn_lower == 'speech_commands': y_offset_factor = 1.2; x_offset_factor = 0.85
            if tn_lower == 'cifar10': x_offset_factor = 0.8
            if tn_lower == 'food101': y_offset_factor = 0.85; x_offset_factor = 0.85
            if tn_lower == 'flowers102': y_offset_factor = 0.85; x_offset_factor = 1.1
            if tn_lower == 'svhn': x_offset_factor = 1.1

            text_obj = plt.text(x_pos * x_offset_factor, y_pos * y_offset_factor, f" {task_name}",
                                fontsize=ANNOTATION_FONTSIZE - 6,
                                va='center', ha='left', zorder=5)
            texts.append(text_obj)
        if texts:
            adjust_text(texts)

        plt.xlabel("Actual Minimum Sample Size (Log Scale)", fontsize=LABEL_FONTSIZE)
        plt.ylabel("Predicted Minimum Sample Size (Log Scale)", fontsize=LABEL_FONTSIZE)
        corr_str = f"ρ = {evaluation_metrics.get('spearman_rho', np.nan):.3f}"
        p_val = evaluation_metrics.get('spearman_p', np.nan)
        if np.isnan(p_val): p_str = "p=N/A"
        elif p_val < 0.001: p_str = "p < 0.001"
        else: p_str = f"p={p_val:.3f}"
        plt.title(f"Prediction vs. Actual Value (N={len(plot_df_filtered)})\nOverall Spearman {corr_str}, {p_str}", fontsize=TITLE_FONTSIZE, pad=15)
        plt.legend(fontsize=LEGEND_FONTSIZE, loc='best', frameon=True, framealpha=0.9, facecolor='white', edgecolor='grey')
        plt.grid(True, which="major", ls="--", linewidth=0.5, alpha=0.5, color='#BBBBBB', zorder=0)
        plt.grid(True, which="minor", ls=":", linewidth=0.3, alpha=0.4, color='#DDDDDD', zorder=0)

        spine_thickness = 2.5
        ax.spines['top'].set_linewidth(spine_thickness)
        ax.spines['bottom'].set_linewidth(spine_thickness)
        ax.spines['left'].set_linewidth(spine_thickness)
        ax.spines['right'].set_linewidth(spine_thickness)

        plt.tight_layout(pad=1.0)
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"\nGrouped visualization chart (NEW STYLE with CI, no ideal line, bold border & ticks) saved to {output_path}")
        plt.close()
    else:
        print(f"\nWarning: No valid positive pairs ({len(plot_df_filtered)}) for log scale plotting or fitting (Main scatter).")
        if plt.gcf().get_axes(): plt.close()
else:
    print("\nNot enough valid data points available for plotting the main scatter plot.")
    if plt.gcf().get_axes(): plt.close()

# --- 10. Save Original Predictions to CSV ---
print("\n--- Saving Original Prediction Results to CSV ---")
output_csv_path = os.path.join(output_dir, 'manual_prediction_grouped_mixedG1_results.csv')
df_to_save = df.copy()
if not df_to_save.empty:
    save_cols = ['group', target, 'predicted_min_sample_size_grouped'] + features
    existing_save_cols = [col for col in save_cols if col in df_to_save.columns]
    missing_cols = list(set(save_cols) - set(existing_save_cols))
    if missing_cols: print(f"Warning: The following columns intended for saving are missing and will be skipped: {missing_cols}")
    if existing_save_cols:
        try:
            df_to_save_subset = df_to_save[existing_save_cols]
            df_to_save_subset.sort_index(inplace=True)
            df_to_save_subset.to_csv(output_csv_path, index=True, index_label='task_name', float_format='%.4f')
            print(f"Prediction results saved to {output_csv_path}")
        except Exception as e: print(f"Error: An exception occurred while saving the CSV file: {e}")
    else: print("Warning: No valid columns available to save to the CSV file.")
else: print("DataFrame is empty, no prediction results to save.")

# --- 10b. Display the DataFrame with original predictions ---
print("\n--- True Value vs. Original Predicted Value Comparison (Used for Evaluation) ---")
pd.set_option('display.float_format', lambda x: '%.2f' % x)
if not valid_df.empty:
    display_cols = [target, 'predicted_min_sample_size_grouped', 'group']
    display_cols_exist = [col for col in display_cols if col in valid_df.columns]
    if len(display_cols_exist) == len(display_cols):
        with pd.option_context('display.max_rows', None, 'display.max_columns', None, 'display.width', 1000): # Wider display
            print(valid_df.sort_index()[display_cols_exist])
    else: print(f"Warning: Cannot display comparison because required columns are missing from valid_df: {set(display_cols) - set(display_cols_exist)}")
else: print("Valid DataFrame (valid_df) for original predictions is empty, cannot display comparison results.")
pd.reset_option('display.float_format')

# --- 11. Interpretation (Updated with separate ablation info) ---
print("\n--- Results Interpretation ---")
print(f"The analysis predicted minimum sample size using manual formulas based on complexity metrics, dividing {evaluation_metrics.get('num_initial_samples', 0)} initial tasks into '{group1_name}' ({evaluation_metrics.get('num_valid_samples_g1', 0)} valid) and '{group2_name}' ({evaluation_metrics.get('num_valid_samples_g2', 0)} valid).")
print(f"Overall evaluation was performed on {evaluation_metrics.get('num_valid_samples', 0)} tasks with valid data.")
print("\nKey Original Evaluation Findings (Combined):")
rho = evaluation_metrics.get('spearman_rho', np.nan)
rho_p = evaluation_metrics.get('spearman_p', np.nan)
rho_sig = "significant (p < 0.05)" if not np.isnan(rho_p) and rho_p < 0.05 else "not significant (p >= 0.05)" if not np.isnan(rho_p) else "p=N/A"
print(f"- Combined Spearman Rho (ρ={rho:.3f}, {rho_sig}): Indicates overall strong positive monotonic relationship.")
print(f"- Combined MAE: {evaluation_metrics.get('mae', np.nan):.2f}")
print(f"- Combined RMSE: {evaluation_metrics.get('rmse', np.nan):.2f}")
if evaluation_metrics.get('mape') is not None: print(f"- Combined MAPE: {evaluation_metrics.get('mape'):.2f}%")
else: print("- Combined MAPE: N/A")
print("\nGroup-Specific Baseline Performance:")
rho_g1, p_g1 = evaluation_metrics.get('spearman_rho_g1', np.nan), evaluation_metrics.get('spearman_p_g1', np.nan)
sig_g1 = "significant (p < 0.05)" if not np.isnan(p_g1) and p_g1 < 0.05 else "not significant (p >= 0.05)" if not np.isnan(p_g1) else "p=N/A"
rho_g2, p_g2 = evaluation_metrics.get('spearman_rho_g2', np.nan), evaluation_metrics.get('spearman_p_g2', np.nan)
sig_g2 = "significant (p < 0.05)" if not np.isnan(p_g2) and p_g2 < 0.05 else "not significant (p >= 0.05)" if not np.isnan(p_g2) else "p=N/A"
print(f"- {group1_name} Baseline Spearman: ρ={rho_g1:.3f} ({sig_g1}, using {evaluation_metrics.get('num_valid_samples_g1', 0)} tasks)")
print(f"- {group2_name} Baseline Spearman: ρ={rho_g2:.3f} ({sig_g2}, using {evaluation_metrics.get('num_valid_samples_g2', 0)} tasks)")
print("\nAblation Study Insights (Group-Specific Feature Importance):")
if ablation_df_g1 is not None and not ablation_df_g1.empty:
    most_impactful_g1, impact_value_g1 = ablation_df_g1.index[0], ablation_df_g1['abs_change'].iloc[0]
    print(f"- For {group1_name}, '{most_impactful_g1}' had the largest impact when ablated (absolute change in rho: {impact_value_g1:.3f}).")
    print(f"  Refer to 'ablation_study_..._{group1_name.replace(' ', '_').replace('(', '').replace(')', '').lower()[:15]}_new_style.png'")
elif ablation_results_g1 is None or np.isnan(original_spearman_rho_g1): print(f"- Ablation study skipped or invalid for {group1_name} due to insufficient data or NaN baseline rho.")
else: print(f"- Ablation study for {group1_name} yielded no valid results to determine feature importance.")
if ablation_df_g2 is not None and not ablation_df_g2.empty:
    most_impactful_g2, impact_value_g2 = ablation_df_g2.index[0], ablation_df_g2['abs_change'].iloc[0]
    print(f"- For {group2_name}, '{most_impactful_g2}' had the largest impact when ablated (absolute change in rho: {impact_value_g2:.3f}).")
    print(f"  Refer to 'ablation_study_..._{group2_name.replace(' ', '_').replace('(', '').replace(')', '').lower()[:15]}_new_style.png'")
elif ablation_results_g2 is None or np.isnan(original_spearman_rho_g2): print(f"- Ablation study skipped or invalid for {group2_name} due to insufficient data or NaN baseline rho.")
else: print(f"- Ablation study for {group2_name} yielded no valid results to determine feature importance.")
print("\nOverall Conclusion:")
print("The analysis demonstrates a strong overall rank correlation between predicted and actual minimum sample sizes using the grouped manual functions. Group-specific baseline correlations confirm the model's effectiveness within each defined task category. Separate ablation studies identify the most influential complexity metrics for each group's prediction function, suggesting differing sensitivities based on the task characteristics and the specific formula applied.")

# --- 12. Save Evaluation Metrics to JSON ---
print("\n--- Saving Evaluation Metrics to JSON ---")
metrics_output_path = os.path.join(output_dir, 'evaluation_metrics_with_ablation.json')

def make_serializable(data):
    if isinstance(data, (np.int_, np.intc, np.intp, np.int8, np.int16, np.int32, np.int64, np.uint8, np.uint16, np.uint32, np.uint64)): return int(data)
    elif isinstance(data, (np.float16, np.float32, np.float64, float)):
        if np.isnan(data) or np.isinf(data): return None
        return float(data)
    elif isinstance(data, (np.ndarray,)): return [make_serializable(item) for item in data.tolist()]
    elif isinstance(data, (dict,)): return {k: make_serializable(v) for k, v in data.items()}
    elif isinstance(data, (list, tuple)): return [make_serializable(item) for item in data]
    elif pd.isna(data): return None
    elif data is None: return None
    elif isinstance(data, np.bool_): return bool(data)
    else:
         try: json.dumps(data); return data
         except TypeError: return str(data)
try:
    serializable_metrics = make_serializable(evaluation_metrics)
    if ablation_results_g1 is not None: serializable_metrics['ablation_study_group1'] = make_serializable(ablation_results_g1)
    else: serializable_metrics['ablation_study_group1'] = None
    if ablation_results_g2 is not None: serializable_metrics['ablation_study_group2'] = make_serializable(ablation_results_g2)
    else: serializable_metrics['ablation_study_group2'] = None
    final_serializable_metrics = make_serializable(serializable_metrics)
    with open(metrics_output_path, 'w') as f_json: # Renamed f to f_json
        json.dump(final_serializable_metrics, f_json, indent=4, allow_nan=False)
    print(f"Evaluation metrics saved successfully to {metrics_output_path}")
except TypeError as e:
    print(f"Error: Could not serialize evaluation metrics to JSON. Error: {e}")
    print("Problematic structure might be around:", final_serializable_metrics if 'final_serializable_metrics' in locals() else "final_serializable_metrics not defined")
except Exception as e: print(f"Error: An exception occurred while saving the evaluation metrics JSON file: {e}")
print("\n--- Analysis Complete ---")