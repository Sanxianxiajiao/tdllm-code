from collections import Counter
import torch
import torch.nn as nn
import torch.optim as optim
# No longer need torchvision or transforms here
from torch.utils.data import DataLoader, Subset, Dataset # Keep Subset/Dataset if needed, DataLoader essential
from datasets import load_dataset, DatasetDict # Use Hugging Face datasets
from transformers import ( # Import necessary classes from transformers
    AutoModelForSeq2SeqLM,
    AutoTokenizer,
    DataCollatorForSeq2Seq,
    get_scheduler
)

import os
import argparse
import json
import random
import numpy as np
import time
from tqdm.auto import tqdm # Use tqdm.auto for better notebook compatibility
from typing import Union, List, Tuple, Optional, Dict, Any
import ast
import json

# --- CLUTRR Helper Functions (Copied from your previous script) ---
import json
import ast # <--- 导入 ast 模块

def get_k_value(example: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extracts the K value (number of reasoning steps) from the 'edge_types' field.
    Assumes 'edge_types' is a string representation of a Python list literal
    (e.g., "['item1', 'item2']").
    Adds a 'k' field to the example.
    """
    edge_types_str = example.get('edge_types')

    if isinstance(edge_types_str, str) and edge_types_str.strip(): # 确保是 非空 字符串
        try:
            # 使用 ast.literal_eval 解析字符串
            edge_list = ast.literal_eval(edge_types_str)

            # 检查解析结果是否真的是一个列表
            if isinstance(edge_list, list):
                example['k'] = len(edge_list)
            else:
                # 解析成功，但结果不是列表
                example['k'] = -1
                # print(f"Warning: Parsed 'edge_types' for id {example.get('id', 'N/A')} is not a list after eval: {edge_list}")

        except (ValueError, SyntaxError, TypeError) as e:
            # 解析字符串失败 (格式不对，或不是字符串等)
            example['k'] = -1
            # print(f"Warning: Could not parse 'edge_types' string for id {example.get('id', 'N/A')}. Error: {e}. Content: '{edge_types_str}'")
    else:
        # 如果 edge_types 本身不是字符串或者是空字符串
        example['k'] = -1
        # if edge_types_str is not None: # 如果不是字符串但也不是None，可能也需要警告
        #     print(f"Warning: 'edge_types' for id {example.get('id', 'N/A')} is not a string or is empty. Type: {type(edge_types_str)}")

    return example
def format_for_llm(example: Dict[str, Any]) -> Dict[str, str]:
    """Formats a CLUTRR example into input/output text."""
    story = example['story']
    query_text = example['query']
    target = example['target_text']
    input_prompt = f"Context: {story}\nQuestion: {query_text}\nAnswer:"
    # You might adjust the prompt format based on the model later
    # input_prompt = f"clutrr reasoning: Context: {story} Question: {query_text}"
    return {
        'input_text': input_prompt,
        'output_text': target
    }
# --- CLUTRR Preprocessing Function (Modified for Integration) ---
def preprocess_clutrr(
    config_name: str,
    filter_k_values_str: Optional[str] = None, # K filter now passed as string
    splits: List[str] = ['train', 'validation', 'test'],
    num_proc: Optional[int] = None,
    dataset_script_path: str = "./clutrr_loader.py"
) -> DatasetDict:
    """Loads, preprocesses, and filters the CLUTRR dataset using a local script."""
    print(f"Loading CLUTRR dataset using script: '{dataset_script_path}' with configuration: '{config_name}'...")
    if not os.path.exists(dataset_script_path):
        raise FileNotFoundError(f"Dataset loading script not found at: {dataset_script_path}. Please ensure clutrr_loader.py exists.")

    try:
        dataset = load_dataset(dataset_script_path, name=config_name, trust_remote_code=True)
    except Exception as e:
        print(f"Error loading dataset using script '{dataset_script_path}' and config '{config_name}'.")
        print(f"Check script path and config name validity within clutrr_loader.py.")
        raise e

    print("Dataset loaded successfully.")
    print(dataset)

    # --- Parse K Filter String ---
    filter_k_values = None
    if filter_k_values_str:
        try:
            if '-' in filter_k_values_str: # Range format "min-max"
                min_k, max_k = map(int, filter_k_values_str.split('-'))
                filter_k_values = (min_k, max_k)
                print(f"Parsed K filter range: {filter_k_values}")
            elif ',' in filter_k_values_str: # List format "k1,k2,k3"
                filter_k_values = [int(k.strip()) for k in filter_k_values_str.split(',')]
                print(f"Parsed K filter list: {filter_k_values}")
            else: # Single value format "k"
                filter_k_values = int(filter_k_values_str)
                print(f"Parsed K filter value: {filter_k_values}")
        except ValueError:
            raise ValueError(f"Invalid format for --k_filter '{filter_k_values_str}'. Use integer ('3'), list ('2,4'), or range ('2-5').")

    processed_splits = {}
    for split in splits:
        if split not in dataset:
            print(f"Warning: Split '{split}' not found. Skipping.")
            continue

        print(f"\nProcessing split: '{split}'...")
        current_split_data = dataset[split]
        original_count = len(current_split_data)
        print(f"Original examples: {original_count}")

        # 1. Add 'k' value
        print(f"Calculating K values for '{split}'...")
        current_split_data = current_split_data.map(get_k_value, num_proc=num_proc)

        print(f"--- K Value Distribution for split '{split}' (before filtering) ---")
        if 'k' in current_split_data.column_names and len(current_split_data) > 0:
            k_values = current_split_data['k']
            k_counts = Counter(k_values) # 使用 Counter 统计频率
            if not k_counts:
                 print("  No K values found (split might be empty or K calculation failed entirely).")
            else:
                # 按 K 值排序打印，更清晰
                for k_val, count in sorted(k_counts.items()):
                    print(f"  K = {k_val}: {count} samples")
        else:
            print(f"  Could not calculate K value distribution ('k' column missing or split empty).")
        print("-" * 30) # 分隔符
        invalid_k_count = sum(1 for k in current_split_data['k'] if k == -1)
        if invalid_k_count > 0:
             print(f"Warning: Found {invalid_k_count} examples where K could not be determined (set to -1).")
        
        # 2. Filter by K
        if filter_k_values is not None:
            print(f"Filtering '{split}' based on K criteria: {filter_k_values}...")
            if isinstance(filter_k_values, int):
                k_filter_func = lambda ex: ex['k'] == filter_k_values
            elif isinstance(filter_k_values, tuple):
                 min_k, max_k = filter_k_values
                 k_filter_func = lambda ex: ex['k'] != -1 and min_k <= ex['k'] <= max_k
            elif isinstance(filter_k_values, list):
                 k_values_set = set(filter_k_values)
                 k_filter_func = lambda ex: ex['k'] in k_values_set
            else:
                # This case should not be reached due to parsing logic above
                raise TypeError("Internal error: Unexpected filter_k_values type.")

            filtered_data = current_split_data.filter(k_filter_func, num_proc=num_proc)
            print(f"Filtered '{split}': {len(filtered_data)} examples remaining.")
            current_split_data = filtered_data
        else:
            print(f"No K value filtering applied.")
            # Still remove invalid K samples if no specific filter is applied
            initial_len = len(current_split_data)
            current_split_data = current_split_data.filter(lambda ex: ex['k'] != -1, num_proc=num_proc)
            removed_count = initial_len - len(current_split_data)
            if removed_count > 0:
                 print(f"Removed {removed_count} examples with invalid K value. {len(current_split_data)} remaining.")

        if len(current_split_data) == 0:
             print(f"Warning: No examples left in '{split}' after filtering.")
             processed_splits[split] = current_split_data # Keep empty dataset
             continue

        # 3. Format for LLM input/output text
        print(f"Formatting '{split}' for input/output text...")
        # Select only needed columns + id/k for potential later inspection before formatting
        # columns_to_keep = ['id', 'story', 'query', 'target_text', 'k']
        # temp_data = current_split_data.select_columns(columns_to_keep)
        formatted_data = current_split_data.map(
            format_for_llm,
            remove_columns=[col for col in current_split_data.column_names if col not in ['input_text', 'output_text']], # Keep only formatted text
            num_proc=num_proc
        )

        processed_splits[split] = formatted_data
        print(f"Finished processing '{split}'. Final example count: {len(formatted_data)}")

    return DatasetDict(processed_splits)

# --- Helper Functions ---

def set_seed(seed):
    """Sets random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        # Keep deterministic options if needed, might slow down training
        # torch.backends.cudnn.deterministic = True
        # torch.backends.cudnn.benchmark = False

# Renamed get_model to load transformer models
def get_transformer_model(model_name):
    """Loads a pre-trained Seq2Seq model from Hugging Face."""
    print(f"Loading pre-trained model: {model_name}")
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
    return model

# Function to get the tokenizer
def get_tokenizer(model_name):
    """Loads the tokenizer corresponding to the pre-trained model."""
    print(f"Loading tokenizer for: {model_name}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    return tokenizer

# --- Training and Evaluation Functions (Adapted for Transformers/Seq2Seq) ---

def train(model, device, train_loader, optimizer, lr_scheduler, epoch, progress_bar):
    """Training loop for one epoch with tqdm progress bar for Seq2Seq."""
    model.train()
    total_loss = 0
    start_time = time.time()
    for step, batch in enumerate(train_loader):
        # Move batch to device (DataCollator handles dict structure)
        batch = {k: v.to(device) for k, v in batch.items()}
        outputs = model(**batch) # Pass batch directly to model
        loss = outputs.loss # Model calculates loss internally when labels are provided

        loss.backward()
        optimizer.step()
        lr_scheduler.step()
        optimizer.zero_grad()

        total_loss += loss.item()
        progress_bar.update(1)
        progress_bar.set_postfix(loss=f'{loss.item():.4f}', epoch=epoch)

    avg_loss = total_loss / len(train_loader)
    end_time = time.time()
    print(f'\n--- Epoch {epoch} Training Summary ---')
    print(f'Average Loss: {avg_loss:.4f}, Time: {end_time - start_time:.2f}s')
    return avg_loss

def test(model, device, test_loader, tokenizer, criterion=None): # Criterion might not be needed if using generation
    """Evaluation loop using model.generate() for Seq2Seq."""
    model.eval()
    total_loss = 0 # Optional: can still calculate loss on test set if labels provided
    correct_predictions = 0
    total_samples = 0
    all_preds = []
    all_labels = []
    start_time = time.time()
    pbar = tqdm(test_loader, desc="Testing", leave=False)

    with torch.no_grad():
        for batch in pbar:
            # Move batch to device
            batch_gpu = {k: v.to(device) for k, v in batch.items() if k != 'labels'} # Don't move labels if only generating
            labels = batch['labels'].to(device) # Move labels separately for loss calculation (optional) or comparison

            # Generate predictions
            generated_ids = model.generate(
                input_ids=batch_gpu['input_ids'],
                attention_mask=batch_gpu['attention_mask'],
                max_length=64, # Adjust max generation length as needed
                num_beams=4, # Example beam search
                early_stopping=True
            )

            # Optional: Calculate loss if needed (useful for monitoring)
            # outputs = model(**{'input_ids': batch_gpu['input_ids'], 'attention_mask': batch_gpu['attention_mask'], 'labels': labels})
            # loss = outputs.loss
            # total_loss += loss.item() * batch['input_ids'].size(0)

            # Decode predictions and labels
            preds = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)
            # Replace padding token id (-100) before decoding labels
            label_ids_for_decode = np.where(batch['labels'] != -100, batch['labels'], tokenizer.pad_token_id)
            labels_text = tokenizer.batch_decode(label_ids_for_decode, skip_special_tokens=True)

            all_preds.extend(preds)
            all_labels.extend(labels_text)

            # Calculate Exact Match Accuracy for the batch
            for pred, label in zip(preds, labels_text):
                # Simple exact match, might need normalization (lower case, strip whitespace)
                if pred.strip().lower() == label.strip().lower():
                    correct_predictions += 1
            total_samples += len(labels_text)

            current_acc = 100. * correct_predictions / total_samples if total_samples > 0 else 0
            # pbar_loss = total_loss / total_samples if total_samples > 0 else 0
            pbar.set_postfix(acc=f'{current_acc:.2f}%') #, loss=f'{pbar_loss:.4f}')


    # avg_loss = total_loss / total_samples if total_samples > 0 else 0
    accuracy = 100. * correct_predictions / total_samples if total_samples > 0 else 0
    end_time = time.time()
    print(f'\n--- Test Set Performance Summary ---')
    # print(f'Average Loss: {avg_loss:.4f}') # If loss was calculated
    print(f'Exact Match Accuracy: {correct_predictions}/{total_samples} ({accuracy:.2f}%)')
    print(f'Time: {end_time - start_time:.2f}s')

    # Optionally return predictions/labels for more detailed analysis
    # return avg_loss, accuracy, all_preds, all_labels
    return 0.0, accuracy # Return 0 for loss if not calculated


# --- Main Execution ---

def main():
    # --- Argument Parsing ---
    parser = argparse.ArgumentParser(description='PyTorch CLUTRR Training using Transformers')
    # CLUTRR Specific Args
    parser.add_argument('--clutrr_config', type=str, required=True,
                        help='CLUTRR configuration name (e.g., gen_train234_test2to10)')
    parser.add_argument('--clutrr_script_path', type=str, default="./clutrr_loader.py",
                        help='Path to the clutrr_loader.py script')
    parser.add_argument('--k_filter', type=str, default=None,
                        help="Filter examples by K value. Format: '3', '2,4', '2-5'")

    # Model Args
    parser.add_argument('--model', type=str, required=True,
                        help='Pre-trained transformer model name (e.g., t5-small, google/flan-t5-base)')
    parser.add_argument('--max_seq_length', type=int, default=128, # Reduced default for CLUTRR stories
                        help='Maximum sequence length for tokenizer')

    # Training Args
    parser.add_argument('--num_train_samples', type=float, default=1.0,
                        help='Number or fraction of training samples (e.g., 0.1 for 10%, 5000 for 5000 samples)')
    parser.add_argument('--epochs', type=int, default=5, metavar='N', # Reduced default epochs for fine-tuning
                        help='number of epochs to train (default: 5)')
    parser.add_argument('--batch_size', type=int, default=16, metavar='N', # Reduced default batch size for transformers
                        help='input batch size for training (default: 16)')
    parser.add_argument('--lr', type=float, default=5e-5, metavar='LR', # Adjusted default LR for transformers
                        help='learning rate (default: 5e-5)')
    parser.add_argument('--seed', type=int, default=42, metavar='S',
                        help='random seed (default: 42)')
    parser.add_argument('--no_cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--num_proc', type=int, default=None, help="Number of processes for dataset mapping")
    parser.add_argument('--results_dir', type=str, default='./clutrr_results',
                        help='Base directory to save results')
    args = parser.parse_args()

    # --- Setup ---
    set_seed(args.seed)
    use_cuda = not args.no_cuda and torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    print(f"Using device: {device}")
    print(f"CLUTRR Config: {args.clutrr_config}")
    print(f"Transformer Model: {args.model}")
    if args.k_filter:
        print(f"K Filter: {args.k_filter}")


    # --- Data Loading and Preprocessing (using preprocess_clutrr) ---
    processed_dataset = preprocess_clutrr(
        config_name=args.clutrr_config,
        filter_k_values_str=args.k_filter,
        splits=['train', 'validation', 'test'], # Adjust splits as needed/available
        num_proc=args.num_proc,
        dataset_script_path=args.clutrr_script_path
    )

    # --- Tokenization ---
    tokenizer = get_tokenizer(args.model)

    def tokenize_function(examples):
        model_inputs = tokenizer(examples['input_text'], max_length=args.max_seq_length, padding=False, truncation=True) # Pad dynamically later
        # Setup the tokenizer for targets
        with tokenizer.as_target_tokenizer():
             labels = tokenizer(examples['output_text'], max_length=32, padding=False, truncation=True) # Shorter max length for answers

        model_inputs["labels"] = labels["input_ids"]
        return model_inputs

    print("Tokenizing datasets...")
    tokenized_datasets = processed_dataset.map(
        tokenize_function,
        batched=True,
        num_proc=args.num_proc,
        remove_columns=processed_dataset["train"].column_names if "train" in processed_dataset else None # Remove original text columns
    )
    print("Tokenization complete.")
    print(tokenized_datasets)


    # --- Handle Subset of Training Data ---
    train_split_name = 'train' # Assuming 'train' is the key
    if train_split_name not in tokenized_datasets or len(tokenized_datasets[train_split_name]) == 0:
         print("Error: No training data found after processing/tokenization. Check config and filters.")
         return # Exit if no training data

    train_dataset_full = tokenized_datasets[train_split_name]
    num_train_samples_full = len(train_dataset_full)
    num_samples_input = args.num_train_samples
    num_actual_train_samples = num_train_samples_full # Default to full dataset

    if num_samples_input > 0 and num_samples_input <= 1:
        num_actual_train_samples = int(num_train_samples_full * num_samples_input)
    elif num_samples_input > 1:
        num_actual_train_samples = int(num_samples_input)
        if num_actual_train_samples > num_train_samples_full:
            print(f"Warning: Requested {num_actual_train_samples} samples, but dataset only has {num_train_samples_full}. Using all {num_train_samples_full} samples.")
            num_actual_train_samples = num_train_samples_full
    else:
        raise ValueError("num_train_samples must be > 0")

    num_samples_str = str(num_actual_train_samples) if num_actual_train_samples < num_train_samples_full else num_train_samples_full
    print(f"Using {num_actual_train_samples} training samples ({num_samples_str} subset).")


    # Create subset if necessary
    if num_actual_train_samples < num_train_samples_full:
        # Sample indices randomly
        indices = random.sample(range(num_train_samples_full), num_actual_train_samples)
        train_dataset = train_dataset_full.select(indices)
    else:
        train_dataset = train_dataset_full


    # --- Data Loaders ---
    # Dynamic padding using DataCollator
    data_collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=args.model) # Pass model name or loaded model

    effective_batch_size = min(args.batch_size, len(train_dataset)) if len(train_dataset) > 0 else 1
    if effective_batch_size < args.batch_size:
         print(f"Warning: Reducing train batch size from {args.batch_size} to {effective_batch_size} due to small dataset size.")

    train_loader = DataLoader(train_dataset, batch_size=effective_batch_size, shuffle=True, collate_fn=data_collator, num_workers=2) # Use collator

    # Use 'validation' split for testing during training if available, otherwise 'test'
    # eval_split_name = 'validation' if 'validation' in tokenized_datasets and len(tokenized_datasets['validation']) > 0 else 'test'

    eval_split_name = 'test'
    if eval_split_name not in tokenized_datasets or len(tokenized_datasets[eval_split_name]) == 0:
         print(f"Warning: No '{eval_split_name}' data found for evaluation.")
         test_loader = None
    else:
        print(f"Using '{eval_split_name}' split for evaluation.")
        test_dataset = tokenized_datasets[eval_split_name]
        test_loader = DataLoader(test_dataset, batch_size=args.batch_size * 2, shuffle=False, collate_fn=data_collator, num_workers=2)


    # --- Model, Optimizer, Scheduler ---
    model = get_transformer_model(args.model).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=args.lr) # AdamW is common for transformers

    # Learning rate scheduler
    num_training_steps = args.epochs * len(train_loader)
    lr_scheduler = get_scheduler(
        name="linear", # Example: linear decay
        optimizer=optimizer,
        num_warmup_steps=0, # Example: no warmup
        num_training_steps=num_training_steps
    )
    print(f"Optimizer: AdamW, LR: {args.lr}, Scheduler: Linear, Total steps: {num_training_steps}")

    # --- Result Saving Setup ---
    # Path now includes args.clutrr_config, k_filter, and num_samples
    k_filter_str = f"k_{args.k_filter.replace(',','_').replace('-','to')}" if args.k_filter else "k_all"
    result_dir_specific = f"{k_filter_str}/{num_samples_str}"
    # print(result_dir_specific)
    # quit()
    result_dir = os.path.join(args.results_dir, result_dir_specific)
    os.makedirs(result_dir, exist_ok=True)
    result_file = os.path.join(result_dir, 'result.json')
    print(f"Results will be saved to: {result_file}")

    results_data = {
        'args': vars(args),
        'dataset_info': {
             'clutrr_config': args.clutrr_config,
             'k_filter': args.k_filter,
             'full_train_size_unfiltered': len(processed_dataset['train']) if 'train' in processed_dataset else 0,
             'full_train_size_filtered': num_train_samples_full,
             'actual_train_samples': num_actual_train_samples,
             'eval_split_used': eval_split_name,
             'eval_split_size': len(test_dataset) if test_loader else 0
        },
        'model_config': model.config.to_dict(), # Save model config
        'best_test_accuracy': 0.0,
        'epoch_results': []
    }

    # --- Training and Evaluation Loop ---
    start_train_time = time.time()
    total_steps = len(train_loader) * args.epochs
    progress_bar = tqdm(range(total_steps), desc="Training Steps")

    for epoch in range(1, args.epochs + 1):
        epoch_start_time = time.time()

        # Training
        train_loss = train(model, device, train_loader, optimizer, lr_scheduler, epoch, progress_bar)

        # Evaluation
        if test_loader:
            test_loss, test_acc = test(model, device, test_loader, tokenizer) # Loss is dummy here
        else:
            print("Skipping evaluation as test loader is not available.")
            test_loss, test_acc = 0.0, 0.0 # Assign default values

        epoch_end_time = time.time()
        epoch_duration = epoch_end_time - epoch_start_time

        print(f"\n=== Epoch {epoch}/{args.epochs} Summary ===")
        print(f"Train Loss: {train_loss:.4f}")
        if test_loader:
             print(f"Test Exact Match Accuracy: {test_acc:.2f}%")
        print(f"Epoch Duration: {epoch_duration:.2f}s")


        # Store results for this epoch
        epoch_result = {
            'epoch': epoch,
            'train_loss': train_loss,
            'test_accuracy': test_acc,
            'duration_seconds': epoch_duration
        }
        results_data['epoch_results'].append(epoch_result)

        # Update best accuracy
        if test_acc > results_data['best_test_accuracy']:
            print(f"*** New best test accuracy: {test_acc:.2f}% (Epoch {epoch}) ***")
            results_data['best_test_accuracy'] = test_acc
            # Save best model checkpoint
            save_path = os.path.join(result_dir, 'best_model')
            # model.save_pretrained(save_path)
            # tokenizer.save_pretrained(save_path)
            # print(f"Best model saved to {save_path}")


        # Save results after each epoch
        try:
            with open(result_file, 'w') as f:
                json.dump(results_data, f, indent=4, default=str) # Use default=str for any non-serializable types
        except IOError as e:
            print(f"Error saving results to {result_file}: {e}")
        except TypeError as e:
             print(f"Serialization Error: {e}. Check data types in results_data.")

    # Close the main progress bar if it hasn't finished (e.g.KeyboardInterrupt)
    progress_bar.close()

    end_train_time = time.time()
    total_training_time = end_train_time - start_train_time
    print(f"\n===== Training Complete =====")
    print(f"Total Training Time: {total_training_time:.2f}s ({total_training_time/60:.2f} minutes)")
    print(f"Best Test Accuracy Achieved: {results_data['best_test_accuracy']:.2f}%")
    print(f"Final results saved to: {result_file}")


if __name__ == '__main__':
    # Ensure the clutrr_loader.py exists or update path if needed
    if not os.path.exists("./clutrr_loader.py"):
        print("Warning: clutrr_loader.py not found in the current directory.")
        print("Please ensure the CLUTRR dataset loading script is present or update '--clutrr_script_path'.")
    main()