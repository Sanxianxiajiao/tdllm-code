# -*- coding: utf-8 -*-
# 在文件开头添加这行来支持中文注释（如果需要）
import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.models as models
import torchaudio
import torchaudio.transforms as T
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.datasets import load_digits, fetch_olivetti_faces, fetch_covtype # New sklearn imports
from scipy.stats import entropy
from scipy.spatial.distance import euclidean
import pandas as pd
import os
import json
import argparse
from tqdm import tqdm
import warnings
import time # For simple timing

# Ignore specific warnings from libraries like sklearn or torchaudio if needed
warnings.filterwarnings("ignore", category=UserWarning, module='torchvision')
warnings.filterwarnings("ignore", category=UserWarning, module='torchaudio')
warnings.filterwarnings("ignore", category=FutureWarning) # Often from sklearn/numpy interactions
# Ignore specific sklearn warnings if they become noisy
# warnings.filterwarnings("ignore", category=ConvergenceWarning)

# --- Configuration ---
DATA_ROOT = './data'
# OUTPUT_DIR will be set dynamically based on the embedding model
# EMBEDDING_MODEL_NAME_CV is now an argument
PCA_VARIANCE_THRESHOLD = 0.95
K_NEIGHBORS = 15 # For local_consistency
SILHOUETTE_SAMPLE_SIZE = 10000 # Max samples for Silhouette score for performance
SPEECH_TARGET_LENGTH_SAMPLES = 16000 # Pad/truncate audio to 1 second (16kHz)

# --- Device Setup ---
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# === Dataset Loading and Preprocessing Functions ===

def get_cv_dataset(dataset_name, data_root):
    """Loads CV datasets for embedding."""
    supported_cv_datasets = [
        'cifar10', 'mnist', 'fashionmnist', 'svhn',
        'cifar100', 'stl10', 'food101', 'flowers102',
        'oxfordiiitpet', 'emnist', 'kmnist',
        # New torchvision datasets
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft',
        'gtsrb', 'pcam', 'semeion', 'stanford_cars', 'usps'
    ]
    if dataset_name not in supported_cv_datasets:
        raise ValueError(f"Unsupported or unknown CV dataset in get_cv_dataset: {dataset_name}")

    # Datasets that are originally grayscale (1 channel)
    grayscale_datasets = ['mnist', 'fashionmnist', 'emnist', 'kmnist',
                          'fer2013', 'semeion', 'usps']

    # Standard transform for common ImageNet pre-trained models (Resize, 3 channels, ImageNet norm)
    embedding_transform = transforms.Compose([
        transforms.Resize((224, 224), antialias=True),
        transforms.Grayscale(num_output_channels=3) if dataset_name in grayscale_datasets else transforms.Lambda(lambda x: x),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    train_dataset_full = None
    labels = None

    print(f"Attempting to load torchvision dataset: {dataset_name}")
    # --- Existing Datasets ---
    if dataset_name == 'cifar10':
        train_dataset_full = torchvision.datasets.CIFAR10(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.targets)
    elif dataset_name == 'mnist':
        train_dataset_full = torchvision.datasets.MNIST(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    elif dataset_name == 'fashionmnist':
        train_dataset_full = torchvision.datasets.FashionMNIST(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    elif dataset_name == 'svhn':
        train_dataset_full = torchvision.datasets.SVHN(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.labels)
    elif dataset_name == 'cifar100':
        train_dataset_full = torchvision.datasets.CIFAR100(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.targets)
    elif dataset_name == 'stl10':
        train_dataset_full = torchvision.datasets.STL10(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.labels)
    elif dataset_name == 'food101':
        train_dataset_full = torchvision.datasets.Food101(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'flowers102':
        train_dataset_full = torchvision.datasets.Flowers102(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'oxfordiiitpet':
        train_dataset_full = torchvision.datasets.OxfordIIITPet(root=data_root, split='trainval', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'emnist':
        train_dataset_full = torchvision.datasets.EMNIST(root=data_root, split='byclass', train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    elif dataset_name == 'kmnist':
        train_dataset_full = torchvision.datasets.KMNIST(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    # --- New torchvision Datasets ---
    elif dataset_name == 'caltech101':
        train_dataset_full = torchvision.datasets.Caltech101(root=data_root, download=True, transform=embedding_transform)
        labels = np.array([label for _, label in train_dataset_full])
    elif dataset_name == 'dtd':
        train_dataset_full = torchvision.datasets.DTD(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'eurosat':
        train_dataset_full = torchvision.datasets.EuroSAT(root=data_root, download=True, transform=embedding_transform)
        labels = np.array([label for _, label in train_dataset_full])
    elif dataset_name == 'fer2013':
        # FER2013 requires manual download or use of a wrapper if not directly supported for auto-download by torchvision version
        # Assuming it's available or torchvision handles it
        try:
            train_dataset_full = torchvision.datasets.FER2013(root=data_root, split='train', transform=embedding_transform, download=True) # Added download=True
            labels = np.array(train_dataset_full._labels) # _labels might not be public, check docs
        except RuntimeError as e: # Catch download errors specifically for FER2013
            print(f"Error loading FER2013: {e}. This dataset might require manual download. Check torchvision documentation.")
            exit(1)
        except AttributeError: # Fallback if _labels is not available
            print("Warning: _labels attribute not found for FER2013. Extracting labels by iterating.")
            labels = np.array([item[1] for item in train_dataset_full])

    elif dataset_name == 'fgvc_aircraft':
        train_dataset_full = torchvision.datasets.FGVCAircraft(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'gtsrb':
        train_dataset_full = torchvision.datasets.GTSRB(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'pcam':
        dataset_temp = torchvision.datasets.PCAM(root=data_root, split='train', download=True, transform=embedding_transform)
        raw_labels = [item[1] for item in dataset_temp._labels] # PCAM specific label extraction
        if all(isinstance(lbl, (list, tuple)) for lbl in raw_labels) and len(raw_labels) > 0:
            labels = np.array([lbl[0] for lbl in raw_labels])
        else:
            labels = np.array(raw_labels)
        train_dataset_full = dataset_temp
    elif dataset_name == 'semeion':
        train_dataset_full = torchvision.datasets.SEMEION(root=data_root, download=True, transform=embedding_transform)
        labels = train_dataset_full.labels 
    elif dataset_name == 'stanford_cars':
        train_dataset_full = torchvision.datasets.StanfordCars(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array([label for _, label in train_dataset_full]) 
    elif dataset_name == 'usps':
        train_dataset_full = torchvision.datasets.USPS(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.targets)
    else:
         raise ValueError(f"Dataset {dataset_name} logic error in get_cv_dataset.")

    if train_dataset_full is None or labels is None:
         print(f"Failed to load dataset {dataset_name}.")
         exit(1)

    try:
        labels = np.array(labels, dtype=int)
    except ValueError:
        print(f"Warning: Could not convert labels for {dataset_name} to integers directly. Check label format.")
        if isinstance(labels[0], (tuple, list)):
             print("Labels appear to be tuples/lists, taking the first element.")
             labels = np.array([l[0] for l in labels], dtype=int)

    print(f"Loaded {dataset_name} training set with {len(train_dataset_full)} samples.")
    return train_dataset_full, labels

def load_sklearn_dataset(dataset_name, data_root):
    """Loads specified sklearn datasets and preprocesses them."""
    print(f"Attempting to load sklearn dataset: {dataset_name}")
    X = None
    y = None
    sklearn_data_home = os.path.join(data_root, 'sklearn_data')
    os.makedirs(sklearn_data_home, exist_ok=True)

    if dataset_name == 'digits':
        digits = load_digits()
        X = digits.data
        y = digits.target
        dataset_type = 'image_raw'
    elif dataset_name == 'olivetti_faces':
        try:
            faces = fetch_olivetti_faces(data_home=sklearn_data_home, shuffle=True, random_state=42)
            X = faces.data
            y = faces.target
            dataset_type = 'image_raw'
        except Exception as e:
            print(f"Error fetching Olivetti Faces (might require internet): {e}")
            return None, None, None
    elif dataset_name == 'covertype': # Corrected spelling from 'covertype' to 'covtype' for fetch_covtype
        try:
            covtype_data = fetch_covtype(data_home=sklearn_data_home, download_if_missing=True)
            X = covtype_data.data
            y = covtype_data.target
            y = y - 1 # Original labels are 1-7, adjust to 0-6
            dataset_type = 'tabular'
        except Exception as e:
            print(f"Error fetching Covertype (might require internet): {e}")
            return None, None, None
    else:
        raise ValueError(f"Unsupported sklearn dataset: {dataset_name}")

    if X is None or y is None:
        print(f"Failed to load data for sklearn dataset {dataset_name}")
        return None, None, None

    print(f"Loaded {dataset_name}: X shape {X.shape}, y shape {y.shape}")
    print(f"{dataset_name} label distribution: {np.bincount(y)}")

    print(f"Scaling features for {dataset_name}...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X.astype(np.float32))

    print(f"Using {X_scaled.shape[0]} samples for {dataset_name} metrics.")
    return X_scaled, y, dataset_type


def load_and_preprocess_spambase(data_path, seed=42):
    try:
        if not os.path.exists(data_path):
             alt_path = os.path.join(DATA_ROOT, 'spambase', 'spambase.data')
             if os.path.exists(alt_path):
                 data_path = alt_path
             else:
                 print(f"Spambase file not found at {data_path} or {alt_path}. Attempting to download...")
                 spambase_dir = os.path.join(DATA_ROOT, 'spambase')
                 os.makedirs(spambase_dir, exist_ok=True)
                 url = "https://archive.ics.uci.edu/ml/machine-learning-databases/spambase/spambase.data"
                 try:
                     import requests
                     print(f"Downloading from {url}...")
                     r = requests.get(url)
                     r.raise_for_status()
                     with open(alt_path, 'wb') as f:
                         f.write(r.content)
                     print(f"Successfully downloaded to {alt_path}")
                     data_path = alt_path
                 except ImportError:
                     print("Error: 'requests' library needed to download Spambase. Please install it (`pip install requests`) or download 'spambase.data' manually.")
                     exit(1)
                 except requests.exceptions.RequestException as e:
                     print(f"Error downloading Spambase: {e}")
                     print(f"Please download 'spambase.data' manually from UCI ML Repository and place it in '{spambase_dir}'.")
                     exit(1)

        col_names = [f'feat_{i}' for i in range(57)] + ['spam']
        try:
            data = pd.read_csv(data_path, header=None, names=col_names, na_values='?')
            print(f"Loaded Spambase data, shape: {data.shape}")
        except Exception as e:
             print(f"Error reading Spambase CSV at {data_path}: {e}")
             exit(1)

    except FileNotFoundError:
        print(f"Error: Spambase dataset file not found and download failed/skipped. Please place 'spambase.data' in '{os.path.join(DATA_ROOT, 'spambase')}' directory.")
        exit(1)
    except Exception as e:
        print(f"Error loading or initially processing Spambase dataset: {e}")
        exit(1)

    if data.empty:
        print("Error: Loaded Spambase data is empty.")
        exit(1)
    if data.isnull().values.any():
        print("Warning: NaN values detected in Spambase data. Filling with column mean.")
        data.fillna(data.mean(), inplace=True)

    X = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values.astype(int)

    print(f"Spambase raw features shape: {X.shape}, labels shape: {y.shape}")
    print(f"Spambase label distribution: {np.bincount(y)}")

    X_train = X
    y_train = y
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train.astype(np.float32))

    print(f"Using {X_train_scaled.shape[0]} training samples for Spambase metrics.")
    return X_train_scaled, y_train


def load_and_preprocess_adult(data_root, random_state=42):
    try:
        from fairlearn import datasets
    except ImportError:
        print("Error: fairlearn library is required for the Adult dataset. Please install it (`pip install fairlearn`).")
        exit(1)

    print("Loading Adult dataset using fairlearn...")
    try:
        fairlearn_data_home = os.path.join(data_root, 'fairlearn_data')
        adult_data = datasets.fetch_adult(as_frame=True, data_home=fairlearn_data_home)
        df_combined = adult_data.frame
        TARGET_FEATURE = 'income' 
        if TARGET_FEATURE not in df_combined.columns:
             if 'Y' in df_combined.columns and len(df_combined['Y'].unique()) == 2: # Fairlearn sometimes uses 'Y'
                 print(f"Warning: Target column '{TARGET_FEATURE}' not found, using 'Y' as target.")
                 df_combined.rename(columns={'Y': TARGET_FEATURE}, inplace=True)
             elif '>50K' in df_combined.iloc[:, -1].unique() or '<=50K' in df_combined.iloc[:, -1].unique():
                 print(f"Warning: Target column '{TARGET_FEATURE}' not found, using last column as target.")
                 df_combined.rename(columns={df_combined.columns[-1]: TARGET_FEATURE}, inplace=True)
             elif 'class' in df_combined.columns: 
                 print("Warning: Target column 'income' not found, using 'class' instead.")
                 df_combined.rename(columns={'class': TARGET_FEATURE}, inplace=True)
             else:
                 raise ValueError(f"Target column '{TARGET_FEATURE}', 'class', 'Y', or recognizable income labels not found.")
        print("Adult dataset loaded successfully.")
    except Exception as e:
        print(f"Error loading Adult data using fairlearn: {e}. Ensure the dataset is downloaded. Check '{fairlearn_data_home}'.")
        exit(1)

    NUMERICAL_FEATURES = ['age', 'fnlwgt', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week']
    CATEGORICAL_FEATURES = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country']

    present_numerical = []
    present_categorical = []
    df_cols_lower_map = {col.lower().replace('-', '_').replace(' ', ''): col for col in df_combined.columns}


    for feat_template in NUMERICAL_FEATURES:
        feat_key = feat_template.lower().replace('-', '_').replace(' ', '')
        if feat_key in df_cols_lower_map:
            present_numerical.append(df_cols_lower_map[feat_key])
    for feat_template in CATEGORICAL_FEATURES:
        feat_key = feat_template.lower().replace('-', '_').replace(' ', '')
        if feat_key in df_cols_lower_map:
            present_categorical.append(df_cols_lower_map[feat_key])
    
    NUMERICAL_FEATURES = present_numerical
    CATEGORICAL_FEATURES = present_categorical

    missing_cols = [col for col in (NUMERICAL_FEATURES + CATEGORICAL_FEATURES) if col not in df_combined.columns] # Re-check with original names
    if missing_cols:
        print(f"Warning: Missing expected columns in Adult dataset after mapping: {missing_cols}")


    known_features = NUMERICAL_FEATURES + CATEGORICAL_FEATURES
    if not known_features:
        print(f"Error: No known features found in Adult dataset. Columns available: {df_combined.columns.tolist()}")
        exit(1)

    df_filtered = df_combined[known_features + [TARGET_FEATURE]].copy()

    df_filtered.replace([' ?', '?', ' ? ', ' ?'], np.nan, inplace=True)


    for col in CATEGORICAL_FEATURES:
        if col in df_filtered:
            df_filtered[col] = df_filtered[col].astype(str).fillna('Missing')
    for col in NUMERICAL_FEATURES:
        if col in df_filtered and df_filtered[col].isnull().any():
            df_filtered[col].fillna(df_filtered[col].median(), inplace=True)


    positive_class_label = '>50K' 
    unique_targets = df_filtered[TARGET_FEATURE].unique()
    
    if 1 in unique_targets and 0 in unique_targets and len(unique_targets) == 2:
        y = df_filtered[TARGET_FEATURE].astype(int).values
        print(f"Using pre-encoded 0/1 target for Adult dataset.")
    else:
        possible_pos_labels = ['>50K', '>50K.', ' >50K', ' >50K.'] 
        found_pos_label = False
        for label_variation in possible_pos_labels:
            if label_variation in unique_targets:
                positive_class_label = label_variation
                print(f"Using '{positive_class_label}' as the positive class label for Adult.")
                found_pos_label = True
                break
        if not found_pos_label:
            print(f"Warning: Could not find standard positive class label among {unique_targets}. Assuming first unique value is positive if binary, else error.")
            if len(unique_targets) == 2:
                # Make a consistent choice, e.g. sort and pick one
                sorted_unique = sorted([str(u) for u in unique_targets])
                positive_class_label = sorted_unique[1] 
                print(f"  Defaulting to '{positive_class_label}' as positive class (ensure this is correct).")
            else:
                print(f"  Cannot determine positive class from {len(unique_targets)} unique values. Exiting.")
                exit(1)
        y = (df_filtered[TARGET_FEATURE].astype(str) == str(positive_class_label)).astype(int).values


    X = df_filtered[known_features]

    print(f"Adult raw features shape: {X.shape}, labels shape: {y.shape}")
    if y.ndim > 0 and len(y)>0:
        print(f"Adult label distribution: {np.bincount(y)}")
    else:
        print("Adult labels are empty or invalid for bincount.")


    X_train = X
    y_train = y

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), NUMERICAL_FEATURES),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False, dtype=np.float32), CATEGORICAL_FEATURES)
        ],
        remainder='drop' 
    )
    try:
        X_train_processed = preprocessor.fit_transform(X_train)
    except ValueError as e:
        print(f"Error during Adult data preprocessing (ColumnTransformer): {e}")
        print(f"Numerical features: {NUMERICAL_FEATURES}")
        print(f"Categorical features: {CATEGORICAL_FEATURES}")
        print(f"X_train columns: {X_train.columns.tolist()}")
        # Example: Check if all NUMERICAL_FEATURES are actually numeric in X_train
        for nf in NUMERICAL_FEATURES:
            if nf in X_train.columns and not pd.api.types.is_numeric_dtype(X_train[nf]):
                print(f"  Warning: Feature '{nf}' is supposed to be numeric but isn't. Type: {X_train[nf].dtype}, Example values: {X_train[nf].unique()[:5]}")
        exit(1)

    print(f"Using {X_train_processed.shape[0]} training samples for Adult metrics.")
    return X_train_processed, y_train


def get_speech_commands_dataset(data_root, target_length_samples):
    try:
        import torchaudio.backend
        print(f"Torchaudio backend: {torchaudio.get_audio_backend()}")
    except Exception as e:
        print(f"Error initializing torchaudio: {e}")
        exit(1)

    try:
        train_set_full = torchaudio.datasets.SPEECHCOMMANDS(root=data_root, subset="training", download=True)
    except Exception as e:
        print(f"Error loading Speech Commands dataset: {e}")
        exit(1)

    all_labels_list = sorted(list(set(item[2] for item in train_set_full)))
    label_to_int = {label: i for i, label in enumerate(all_labels_list)}
    print(f"Speech Commands - Found {len(all_labels_list)} unique labels: {all_labels_list}")

    sample_rate = 16000
    n_fft = 400
    hop_length = 160
    n_mels = 64
    mel_spectrogram = T.MelSpectrogram(
        sample_rate=sample_rate, n_fft=n_fft, hop_length=hop_length, n_mels=n_mels, power=2.0
    )
    log_mel_spectrogram = transforms.Compose([
        mel_spectrogram,
        T.AmplitudeToDB(stype='power', top_db=80)
    ])

    processed_spectrograms = []
    processed_labels = []

    print(f"Processing Speech Commands training set ({len(train_set_full)} samples)...")
    for i, item in enumerate(tqdm(train_set_full)):
        waveform, sr, label, _, _ = item # Unpack all 5 elements, even if some are not used directly
        if sr != sample_rate:
            try:
                 waveform = torchaudio.functional.resample(waveform, sr, sample_rate)
            except Exception as resample_e:
                 print(f"Warning: Resampling failed for sample {i} (Label: {label}, SR: {sr}): {resample_e}. Skipping sample.")
                 continue

        # Pad or truncate waveform
        current_len = waveform.shape[-1]
        if current_len > target_length_samples:
            waveform_processed = waveform[..., :target_length_samples]
        elif current_len < target_length_samples:
            padding_needed = target_length_samples - current_len
            waveform_processed = torch.nn.functional.pad(waveform, (0, padding_needed))
        else:
            waveform_processed = waveform


        try:
             spec = log_mel_spectrogram(waveform_processed)
        except Exception as e:
             print(f"\nError processing sample {i} (Label: {label}, Shape: {waveform.shape}): {e}")
             continue

        if spec.dim() == 3 and spec.shape[0] == 1: # (1, Mel, Time)
             processed_spectrograms.append(spec.squeeze(0).flatten().numpy())
        elif spec.dim() == 2: # (Mel, Time)
             processed_spectrograms.append(spec.flatten().numpy())
        else:
             print(f"\nWarning: Unexpected spectrogram shape {spec.shape} for sample {i}. Skipping.")
             continue
        processed_labels.append(label_to_int[label])

    if not processed_spectrograms:
        print("\nError: No speech samples were successfully processed.")
        return None, None

    X_embed = np.array(processed_spectrograms, dtype=np.float32)
    Y_labels = np.array(processed_labels, dtype=int)

    print(f"Processed {X_embed.shape[0]} speech samples into embeddings of dimension {X_embed.shape[1]}.")
    print(f"Speech label distribution: {np.bincount(Y_labels)}")
    return X_embed, Y_labels


# === Embedding Generation (CV specific) ===

def get_cv_embeddings(model, dataset, device):
    """Generates embeddings for CV datasets using the provided model."""
    batch_size = 32 if device.type == 'cuda' else 16
    batch_size = int(os.environ.get("CV_EMBED_BATCH_SIZE", batch_size))

    dataloader = None
    try:
        num_dataloader_workers = min(os.cpu_count() // 2, 4) if device.type == 'cuda' else 0
        # For very small datasets, persistent_workers might not be ideal or even cause issues
        # Heuristic: disable if dataset is very small (e.g. < batch_size * num_workers * some_factor)
        use_persistent_workers = (device.type == 'cuda' and num_dataloader_workers > 0 and len(dataset) > batch_size * num_dataloader_workers * 2)

        dataloader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, shuffle=False,
            num_workers=num_dataloader_workers,
            pin_memory=True if device.type == 'cuda' else False,
            persistent_workers=use_persistent_workers 
            )
    except Exception as dl_e:
         print(f"Error creating DataLoader with multiple workers: {dl_e}. Fallback to num_workers=0.")
         dataloader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, shuffle=False,
            num_workers=0, pin_memory=False)

    all_embeddings = []
    print(f"Generating CV embeddings using {device} with batch size {batch_size}...")
    model.eval()
    with torch.no_grad():
        for inputs, _ in tqdm(dataloader, desc="Embedding"):
            if inputs is None:
                print("Warning: Encountered None input in DataLoader batch.")
                continue
            try:
                inputs = inputs.to(device)
                outputs = model(inputs)
                all_embeddings.append(outputs.cpu().numpy())
            except RuntimeError as e:
                 if "out of memory" in str(e).lower():
                     print(f"\nCUDA out of memory during embedding generation (batch size {batch_size}). "
                           "Try reducing batch size via CV_EMBED_BATCH_SIZE env var or reducing image resolution.")
                     torch.cuda.empty_cache()
                     print("Exiting due to OOM error.")
                     return None 
                 else:
                     print(f"\nRuntimeError during batch processing: {e}")
                     return None 
            except Exception as e:
                print(f"\nError during batch processing in embedding generation: {e}")
                return None 

    if not all_embeddings:
        print("Error: No embeddings were generated.")
        return None

    try:
        concatenated_embeddings = np.concatenate(all_embeddings, axis=0).astype(np.float32)
        print(f"Generated embeddings shape: {concatenated_embeddings.shape}")
        return concatenated_embeddings
    except Exception as concat_e:
        print(f"Error concatenating embeddings: {concat_e}")
        return None


# === Complexity Metrics Calculation ===

def calculate_metrics(X_embed, Y_labels, pca_threshold, k_neighbors, silhouette_sample_size):
    """Calculates all complexity metrics."""
    print("\nCalculating complexity metrics...")
    calculation_start_time = time.time()
    results = {}
    if X_embed is None or Y_labels is None:
        print("Error: Input embeddings or labels are None. Cannot calculate metrics.")
        return None

    n_samples = X_embed.shape[0]
    n_features = X_embed.shape[1]
    results['n_samples'] = n_samples
    results['n_features_raw'] = n_features

    if n_samples == 0 or n_features == 0:
        print("Error: Embedding data is empty. Cannot calculate metrics.")
        return None
    if len(X_embed) != len(Y_labels):
         print(f"Error: Embeddings ({len(X_embed)}) vs labels ({len(Y_labels)}) mismatch.")
         return None
    if np.isnan(X_embed).any() or np.isinf(X_embed).any():
        num_nan = np.isnan(X_embed).sum()
        num_inf = np.isinf(X_embed).sum()
        print(f"Error: Input embeddings contain {num_nan} NaN or {num_inf} Inf values.")
        return None

    metric_times = {}

    # 1. Number of classes and label distribution stats
    start = time.time()
    print("Calculating num_classes & label stats...")
    try:
        unique_labels, counts_per_class = np.unique(Y_labels, return_counts=True)
        results['num_classes'] = len(unique_labels)
        results['min_samples_per_class'] = int(np.min(counts_per_class)) if len(counts_per_class) > 0 else 0
        results['max_samples_per_class'] = int(np.max(counts_per_class)) if len(counts_per_class) > 0 else 0
        results['avg_samples_per_class'] = float(np.mean(counts_per_class)) if len(counts_per_class) > 0 else 0.0
        results['median_samples_per_class'] = float(np.median(counts_per_class)) if len(counts_per_class) > 0 else 0.0
        print(f"  num_classes: {results['num_classes']}")
        if results['num_classes'] < 1: 
             print("Error: No classes found in Y_labels.")
             return None
        metric_times['class_stats'] = time.time() - start
    except Exception as e:
        print(f"  Error calculating class stats: {e}")
        return None 

    # 2. Label Entropy
    start = time.time()
    print("Calculating label_entropy...")
    if results['num_classes'] > 0 and len(counts_per_class) > 0:
        results['label_entropy'] = entropy(counts_per_class, base=2)
        print(f"  label_entropy: {results['label_entropy']:.4f}")
    else:
        results['label_entropy'] = 0.0 if results['num_classes'] == 1 else None
    metric_times['label_entropy'] = time.time() - start

    X_scaled_shared = None
    try:
        print("Scaling data for subsequent metrics (PCA, etc.)...")
        scaler_shared = StandardScaler() 
        X_scaled_shared = scaler_shared.fit_transform(X_embed) 
        if np.isnan(X_scaled_shared).any() or np.isinf(X_scaled_shared).any():
             print("Error: NaN/Inf values after shared scaling. Metrics using this will be affected.")
             X_scaled_shared = None 
    except Exception as e:
        print(f"  Error during shared scaling: {e}")
        X_scaled_shared = None

    # 3. Effective Dimensionality (PCA-based)
    start = time.time()
    print("Calculating effective_dim...")
    results['effective_dim'] = None
    X_pca_input = X_scaled_shared 
    if X_pca_input is None: 
        print("  Shared scaling failed or unavailable, attempting local scaling for PCA (float32)...")
        try:
             scaler_pca = StandardScaler()
             X_pca_input = scaler_pca.fit_transform(X_embed.astype(np.float32)) 
             if np.isnan(X_pca_input).any() or np.isinf(X_pca_input).any(): X_pca_input = None
        except Exception as e: X_pca_input = None

    if X_pca_input is not None:
        try:
            print("  Fitting PCA...")
            n_components_limit = min(X_pca_input.shape)
            max_pca_comps = min(n_components_limit, 5000) 
            if max_pca_comps < 1: 
                print("  Not enough samples/features for PCA.")
            else:
                pca = PCA(n_components=max_pca_comps, copy=True) # copy=True is safer default
                pca.fit(X_pca_input.astype(np.float32)) 
                cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
                eff_dim_val = np.argmax(cumulative_variance >= pca_threshold) + 1
                
                if len(cumulative_variance) > 0 and cumulative_variance[-1] < pca_threshold:
                    print(f"  Warning: PCA threshold {pca_threshold} not reached. Max variance: {cumulative_variance[-1]:.4f}. Reporting n_components used ({pca.n_components_}).")
                    eff_dim_val = pca.n_components_ 
                elif len(cumulative_variance) == 0: eff_dim_val = None 
                if eff_dim_val is not None: results['effective_dim'] = int(eff_dim_val)
                print(f"  effective_dim (at {pca_threshold*100}% variance): {results.get('effective_dim', 'N/A')}")
        except Exception as e: print(f"  Error calculating effective_dim: {e}")
        finally: 
            del X_pca_input 
            if 'pca' in locals():
                del pca 
    metric_times['effective_dim'] = time.time() - start


    # 4. Intra-class Variance & Inter-class Distance (using original embeddings for true scale)
    start = time.time()
    print("Calculating intra-class variance and inter-class distance...")
    results['intra_class_var_avg'] = None
    results['inter_class_dist_avg'] = None
    X_dist_input = X_embed.astype(np.float64) 

    if results['num_classes'] < 2:
         print("  Skipping intra/inter class metrics (requires >= 2 classes).")
    else:
        intra_class_avg_dists = []
        class_centroids = {}
        try:
            print("  Calculating centroids and intra-class distances...")
            if results.get('min_samples_per_class', 0) < 2: 
                 print(f"  Warning: At least one class has < 2 samples. Intra-class variance for these will be 0 or undefined.")

            for label_val in tqdm(unique_labels, desc="Intra/Inter Class"): 
                class_indices = np.where(Y_labels == label_val)[0]
                class_embeddings = X_dist_input[class_indices]
                if len(class_embeddings) > 1:
                    centroid = np.mean(class_embeddings, axis=0)
                    class_centroids[label_val] = centroid
                    distances = [euclidean(emb, centroid) for emb in class_embeddings]
                    intra_class_avg_dists.append(np.mean(distances))
                elif len(class_embeddings) == 1: 
                    class_centroids[label_val] = class_embeddings[0] 
                    intra_class_avg_dists.append(0.0) 
                
            valid_intra_dists = [d for d in intra_class_avg_dists if d is not None and not np.isnan(d)] 
            if valid_intra_dists: results['intra_class_var_avg'] = float(np.mean(valid_intra_dists))
            print(f"  intra_class_var_avg: {results.get('intra_class_var_avg', 'N/A') if results.get('intra_class_var_avg') is None else results['intra_class_var_avg']:.4f}")


            print("  Calculating inter-class distances...")
            inter_class_distances = []
            centroid_items = list(class_centroids.items()) 
            if len(centroid_items) > 1: 
                for i in range(len(centroid_items)):
                    for j in range(i + 1, len(centroid_items)): 
                        dist = euclidean(centroid_items[i][1], centroid_items[j][1])
                        inter_class_distances.append(dist)
                valid_inter_dists = [d for d in inter_class_distances if d is not None and not np.isnan(d)]
                if valid_inter_dists: results['inter_class_dist_avg'] = float(np.mean(valid_inter_dists))
            print(f"  inter_class_dist_avg: {results.get('inter_class_dist_avg', 'N/A') if results.get('inter_class_dist_avg') is None else results['inter_class_dist_avg']:.4f}")

        except Exception as e: print(f"  Error calculating intra/inter class metrics: {e}")
        finally: 
            if 'X_dist_input' in locals(): del X_dist_input
            if 'class_centroids' in locals(): del class_centroids
            if 'intra_class_avg_dists' in locals(): del intra_class_avg_dists
            if 'inter_class_distances' in locals(): del inter_class_distances
    metric_times['intra_inter_dist'] = time.time() - start

    # 5. Local Consistency (k-NN based)
    start = time.time()
    print(f"Calculating local_consistency (k={k_neighbors})...")
    results['local_consistency'] = None
    X_nn_input = X_embed.astype(np.float32) 
    try:
        actual_k = min(k_neighbors, n_samples - 1) 
        if actual_k < 1 or results.get('num_classes', 0) < 1: # Allow for num_classes = 1, consistency would be 1.0
             print(f"  Skipping local_consistency (not enough samples or k < 1).")
        else:
            print(f"  Fitting NearestNeighbors (k={actual_k})...")
            nn = NearestNeighbors(n_neighbors=actual_k + 1, metric='euclidean', n_jobs=-1, algorithm='auto') 
            nn.fit(X_nn_input)
            print("  Querying neighbors and calculating consistency...")
            batch_size_nn = 10000 
            consistent_neighbor_ratios = []
            for i in tqdm(range(0, n_samples, batch_size_nn), desc="Local Consistency Batches"):
                batch_indices_range = range(i, min(i + batch_size_nn, n_samples))
                current_batch_X = X_nn_input[i:min(i + batch_size_nn, n_samples)]
                if current_batch_X.shape[0] == 0: continue

                indices = nn.kneighbors(current_batch_X, return_distance=False)[:, 1:] 
                batch_labels_current = Y_labels[batch_indices_range]
                for j_idx_in_batch in range(len(batch_indices_range)):
                    neighbor_labels = Y_labels[indices[j_idx_in_batch]]
                    consistency = np.mean(neighbor_labels == batch_labels_current[j_idx_in_batch])
                    consistent_neighbor_ratios.append(consistency)
            
            if consistent_neighbor_ratios: results['local_consistency'] = float(np.mean(consistent_neighbor_ratios))
            print(f"  local_consistency: {results.get('local_consistency', 'N/A') if results.get('local_consistency') is None else results['local_consistency']:.4f}")
    except Exception as e: print(f"  Error calculating local_consistency: {e}")
    finally:
        if 'X_nn_input' in locals(): del X_nn_input 
        if 'nn' in locals(): del nn
    metric_times['local_consistency'] = time.time() - start

    # 6. Separability Score (Silhouette Score)
    start = time.time()
    print("Calculating separability_score (Silhouette Score)...")
    results['separability_score'] = None
    
    # Stricter check for silhouette: needs at least 2 distinct labels in the (sub)sample,
    # and sklearn's implementation needs at least 1 sample per cluster after potential subsampling.
    # More robustly, 2 samples per cluster is better for meaningful scores.
    
    # Check overall dataset first
    if results['num_classes'] < 2:
        print("  Skipping separability_score (requires >= 2 classes in the dataset).")
    else:
        print(f"  Preparing data for Silhouette score (max {silhouette_sample_size} samples).")
        X_sil_input = X_embed.astype(np.float32) 
        Y_sil_labels = Y_labels
        X_work, Y_work = None, None 

        if n_samples > silhouette_sample_size:
            print(f"  Subsampling to {silhouette_sample_size} samples for Silhouette.")
            try:
                # Attempt stratified sampling
                _, X_work_split, _, Y_work_split = train_test_split( # Correct order for train_test_split for sampling
                    X_sil_input, Y_sil_labels,
                    test_size=silhouette_sample_size, # Sample this many
                    stratify=Y_sil_labels,
                    random_state=42, shuffle=True
                )
                # Check if the subsample is valid for Silhouette
                unique_sub, counts_sub = np.unique(Y_work_split, return_counts=True)
                # Sklearn silhouette_score needs at least 2 labels, each with at least 1 sample.
                if len(unique_sub) >= 2 and np.all(counts_sub >= 1): 
                    X_work, Y_work = X_work_split, Y_work_split
                    print(f"  Stratified subsample created with {len(unique_sub)} classes.")
                else:
                    print(f"  Stratified subsampling resulted in <2 classes or classes with <1 sample (Labels: {unique_sub}, Counts: {counts_sub}). Trying random.")
                    raise ValueError("Stratified sample invalid for Silhouette.")
            except ValueError: # Fallback to random sampling
                 indices_subset = np.random.choice(n_samples, min(silhouette_sample_size, n_samples), replace=False)
                 X_work_rand, Y_work_rand = X_sil_input[indices_subset], Y_sil_labels[indices_subset]
                 unique_sub_rand, counts_sub_rand = np.unique(Y_work_rand, return_counts=True)
                 if len(unique_sub_rand) >= 2 and np.all(counts_sub_rand >= 1):
                     X_work, Y_work = X_work_rand, Y_work_rand
                     print(f"  Random subsample created with {len(unique_sub_rand)} classes.")
                 else:
                     print("  Random subsampling also failed Silhouette criteria. Skipping.")
            except Exception as e: print(f"  Error during subsampling for Silhouette: {e}.")
        else: # Use full dataset if small enough
            X_work, Y_work = X_sil_input, Y_sil_labels
            unique_full, counts_full = np.unique(Y_work, return_counts=True)
            if not (len(unique_full) >= 2 and np.all(counts_full >= 1)):
                print(f"  Full dataset ({n_samples} samples) not valid for Silhouette (Labels: {unique_full}, Counts: {counts_full}). Skipping.")
                X_work, Y_work = None, None 
            else:
                print(f"  Using full dataset ({n_samples} samples) for Silhouette.")


        if X_work is not None and Y_work is not None:
            try:
                print(f"  Calculating silhouette score on {X_work.shape[0]} samples...")
                score = silhouette_score(X_work, Y_work, metric='euclidean', sample_size=None, random_state=42) # sample_size=None as we pre-sampled
                results['separability_score'] = float(score)
                print(f"  separability_score: {results['separability_score']:.4f}")
            except ValueError as ve: 
                print(f"  ValueError calculating silhouette score (likely due to label distribution in subset): {ve}")
            except Exception as e: print(f"  Error calculating silhouette score: {e}")
            finally: 
                if 'X_work' in locals(): del X_work
                if 'Y_work' in locals(): del Y_work
    metric_times['separability_score'] = time.time() - start

    total_calculation_time = time.time() - calculation_start_time
    print(f"\nMetrics calculation finished in {total_calculation_time:.2f} seconds.")
    results['calculation_times'] = {k: round(v, 2) for k, v in metric_times.items()}

    for k, v in results.items():
        if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
             print(f"Warning: Metric '{k}' resulted in NaN or Inf. Setting to None.")
             results[k] = None
    return results


# === Main Execution ===

if __name__ == "__main__":
    start_time = time.time()
    parser = argparse.ArgumentParser(description="Calculate complexity metrics for various datasets.")
    all_dataset_choices = [
        'cifar10', 'mnist', 'fashionmnist', 'svhn', 'cifar100', 'stl10',
        'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'kmnist',
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft', 'gtsrb',
        'pcam', 'semeion', 'stanford_cars', 'usps',
        'digits', 'olivetti_faces', 'covertype',
        'spambase', 'adult', 'speech_commands'
    ]
    
    cv_model_choices = [
        'resnet18', 'resnet50', 'vgg16',
        'mobilenet_v3_large', 'efficientnet_b0', 'vit_b_16', # Existing
        'resnet101', 'resnet152', 'resnext101_32x8d', 'wide_resnet101_2', # New ResNet family
        'inception_v3', # New Inception
        'densenet161', # New DenseNet
        'efficientnet_b7', 'efficientnet_v2_l', # New EfficientNets
        'swin_b', # New Transformer
        'convnext_base' # New ConvNeXt
    ]

    parser.add_argument('-dataset', type=str, required=True,
                        choices=sorted(all_dataset_choices),
                        help='Name of the dataset to process.')
    parser.add_argument('--embedding_model_cv', type=str, default='resnet50',
                        choices=sorted(cv_model_choices),
                        help='Name of the pre-trained model for CV embeddings.')
    args = parser.parse_args()
    dataset_name = args.dataset
    embedding_model_name_cv_arg = args.embedding_model_cv

    OUTPUT_DIR = f'./data_analys_{embedding_model_name_cv_arg}'


    print(f"--- Processing dataset: {dataset_name} ---")
    
    torchvision_cv_datasets = [
        'cifar10', 'mnist', 'fashionmnist', 'svhn', 'cifar100', 'stl10',
        'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'kmnist',
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft', 'gtsrb',
        'pcam', 'semeion', 'stanford_cars', 'usps'
    ]
    sklearn_datasets = ['digits', 'olivetti_faces', 'covertype']
    other_tabular_datasets = ['spambase', 'adult']
    audio_datasets = ['speech_commands']

    if dataset_name in torchvision_cv_datasets:
        print(f"--- Using CV Embedding Model: {embedding_model_name_cv_arg} ---")
    print(f"--- Output directory: {OUTPUT_DIR} ---")


    X_embed = None
    Y_labels = None
    dataset_info = {'name': dataset_name, 'load_time': None, 'embedding_time': None}

    load_start_time = time.time()

    if dataset_name in torchvision_cv_datasets:
        dataset_info['type'] = 'cv_torchvision'
        dataset_info['embedding_model_name_cv'] = embedding_model_name_cv_arg

        cv_dataset, Y_labels = get_cv_dataset(dataset_name, DATA_ROOT)
        if cv_dataset is None or Y_labels is None:
            print(f"Exiting due to dataset loading failure for {dataset_name}.")
            exit(1)
        dataset_info['raw_samples'] = len(cv_dataset)
        dataset_info['raw_labels_count'] = len(np.unique(Y_labels)) if Y_labels is not None else 0
        dataset_info['load_time'] = time.time() - load_start_time

        print(f"\nLoading pre-trained {embedding_model_name_cv_arg} model for CV embeddings...")
        embedding_start_time = time.time()
        embedding_model = None
        try:
            if embedding_model_name_cv_arg == 'resnet18':
                weights = models.ResNet18_Weights.IMAGENET1K_V1
                embedding_model = models.resnet18(weights=weights)
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'resnet50':
                weights = models.ResNet50_Weights.IMAGENET1K_V2
                embedding_model = models.resnet50(weights=weights)
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'vgg16':
                weights = models.VGG16_Weights.IMAGENET1K_V1
                embedding_model = models.vgg16(weights=weights)
                embedding_model.classifier = torch.nn.Identity() 
            elif embedding_model_name_cv_arg == 'mobilenet_v3_large':
                weights = models.MobileNet_V3_Large_Weights.IMAGENET1K_V1
                embedding_model = models.mobilenet_v3_large(weights=weights)
                embedding_model.classifier = torch.nn.Identity() 
            elif embedding_model_name_cv_arg == 'efficientnet_b0':
                weights = models.EfficientNet_B0_Weights.IMAGENET1K_V1
                embedding_model = models.efficientnet_b0(weights=weights)
                embedding_model.classifier = torch.nn.Identity() 
            elif embedding_model_name_cv_arg == 'vit_b_16':
                weights = models.ViT_B_16_Weights.IMAGENET1K_V1
                embedding_model = models.vit_b_16(weights=weights)
                embedding_model.heads = torch.nn.Identity() 
            # --- New Models ---
            elif embedding_model_name_cv_arg == 'resnet101':
                weights = models.ResNet101_Weights.IMAGENET1K_V2 
                embedding_model = models.resnet101(weights=weights)
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'resnet152':
                weights = models.ResNet152_Weights.IMAGENET1K_V2
                embedding_model = models.resnet152(weights=weights)
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'resnext101_32x8d':
                weights = models.ResNeXt101_32X8D_Weights.IMAGENET1K_V1
                embedding_model = models.resnext101_32x8d(weights=weights)
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'wide_resnet101_2':
                weights = models.Wide_ResNet101_2_Weights.IMAGENET1K_V2
                embedding_model = models.wide_resnet101_2(weights=weights)
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'inception_v3':
                weights = models.Inception_V3_Weights.IMAGENET1K_V1
                embedding_model = models.inception_v3(weights=weights, aux_logits=False) 
                embedding_model.fc = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'densenet161':
                weights = models.DenseNet161_Weights.IMAGENET1K_V1
                embedding_model = models.densenet161(weights=weights)
                embedding_model.classifier = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'efficientnet_b7':
                weights = models.EfficientNet_B7_Weights.IMAGENET1K_V1
                embedding_model = models.efficientnet_b7(weights=weights)
                embedding_model.classifier = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'efficientnet_v2_l':
                weights = models.EfficientNet_V2_L_Weights.IMAGENET1K_V1
                embedding_model = models.efficientnet_v2_l(weights=weights)
                embedding_model.classifier = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'swin_b':
                weights = models.Swin_B_Weights.IMAGENET1K_V1
                embedding_model = models.swin_b(weights=weights)
                embedding_model.head = torch.nn.Identity()
            elif embedding_model_name_cv_arg == 'convnext_base':
                weights = models.ConvNeXt_Base_Weights.IMAGENET1K_V1
                embedding_model = models.convnext_base(weights=weights)
                embedding_model.classifier[2] = torch.nn.Identity() # Replace Linear layer in classifier Sequential
            else:
                raise ValueError(f"Unsupported CV embedding model: {embedding_model_name_cv_arg}")

            embedding_model = embedding_model.to(device)
            embedding_model.eval()
        except Exception as e:
             print(f"Error loading model {embedding_model_name_cv_arg}: {e}")
             exit(1)

        X_embed = get_cv_embeddings(embedding_model, cv_dataset, device)
        dataset_info['embedding_time'] = time.time() - embedding_start_time
        del embedding_model, cv_dataset
        torch.cuda.empty_cache() if device.type == 'cuda' else None
        if X_embed is None: 
            print(f"Exiting due to embedding generation failure for {dataset_name}.")
            exit(1)

    elif dataset_name in sklearn_datasets:
        X_embed, Y_labels, dataset_type_sklearn = load_sklearn_dataset(dataset_name, DATA_ROOT) 
        dataset_info['type'] = f'sklearn_{dataset_type_sklearn}'
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time

    elif dataset_name == 'spambase':
        dataset_info['type'] = 'tabular_spambase'
        spambase_path = os.path.join(DATA_ROOT, 'spambase', 'spambase.data')
        X_embed, Y_labels = load_and_preprocess_spambase(spambase_path)
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time

    elif dataset_name == 'adult':
        dataset_info['type'] = 'tabular_adult'
        X_embed, Y_labels = load_and_preprocess_adult(DATA_ROOT)
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time

    elif dataset_name == 'speech_commands':
        dataset_info['type'] = 'audio_speechcommands'
        X_embed, Y_labels = get_speech_commands_dataset(DATA_ROOT, SPEECH_TARGET_LENGTH_SAMPLES)
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time
    else:
        raise ValueError(f"Dataset name '{dataset_name}' not handled in main execution block.")


    if X_embed is not None and Y_labels is not None:
        if 'embedding_dim' not in dataset_info: 
             dataset_info['embedding_dim'] = X_embed.shape[1]
        if 'num_samples_processed' not in dataset_info: 
             dataset_info['num_samples_processed'] = X_embed.shape[0]

        metrics = calculate_metrics(X_embed, Y_labels, PCA_VARIANCE_THRESHOLD, K_NEIGHBORS, SILHOUETTE_SAMPLE_SIZE)

        if metrics:
            print("\nSaving results...")
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, f"{dataset_name}_complexity_metrics.json")

            full_results = dataset_info.copy() 
            for time_key in ['load_time', 'embedding_time']:
                if full_results.get(time_key) is not None:
                    full_results[time_key] = round(full_results[time_key], 2)

            full_results['complexity_metrics'] = {}
            metric_calculation_times = metrics.pop('calculation_times', {}) 

            for k, v in metrics.items():
                if v is None: full_results['complexity_metrics'][k] = None
                elif isinstance(v, np.bool_): full_results['complexity_metrics'][k] = bool(v)
                elif isinstance(v, np.generic): 
                    if isinstance(v, (np.floating, float)) and (np.isinf(v) or np.isnan(v)):
                        full_results['complexity_metrics'][k] = str(v) if np.isinf(v) else None 
                    else:
                        full_results['complexity_metrics'][k] = v.item() 
                elif isinstance(v, float) and (np.isinf(v) or np.isnan(v)): 
                    full_results['complexity_metrics'][k] = str(v) if np.isinf(v) else None
                else: full_results['complexity_metrics'][k] = v 

            full_results['metric_calculation_times_sec'] = metric_calculation_times

            try:
                with open(output_path, 'w') as f:
                    json.dump(full_results, f, indent=4) 
                print(f"Results saved to {output_path}")
                print("\n--- Final Calculated Metrics Summary ---")
                print(json.dumps(full_results['complexity_metrics'], indent=4))
            except TypeError as json_err:
                 print(f"\nError saving results to JSON: {json_err}")
                 print("Problematic data structure attempt for JSON:")
                 for key, val in full_results.items():
                     print(f"  {key}: {type(val)}")
                     if key == 'complexity_metrics':
                         for m_key, m_val in val.items():
                             print(f"    {m_key}: {type(m_val)}")
        else:
            print("Metrics calculation failed or returned None.")
    else:
        print("Failed to load data or generate embeddings; X_embed or Y_labels is None.")

    end_time = time.time()
    print(f"\n--- Finished processing {dataset_name} in {end_time - start_time:.2f} seconds ---")