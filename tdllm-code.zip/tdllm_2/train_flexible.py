# Keep all previous imports
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset, Dataset
import torchvision.models as models

import os
import argparse
import json
import random
import numpy as np
import time
from tqdm import tqdm

# --- Model Definitions ---

# Modified to accept input channels and image size for flexibility
class SimpleCNN(nn.Module):
    def __init__(self, input_channels=3, image_size=32, num_classes=10):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1)
        # Calculate flattened size dynamically
        # After two pools (stride 2), size becomes image_size / 4
        feature_size = image_size // 4
        self.fc1_input_features = 32 * feature_size * feature_size
        self.fc1 = nn.Linear(self.fc1_input_features, 128)
        self.fc2 = nn.Linear(128, num_classes)
        # Check for invalid size
        if feature_size <= 0:
             raise ValueError(f"Image size {image_size} too small for 2 pooling layers")


    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, self.fc1_input_features) # Flatten the tensor
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Modified to accept input channels and image size
class SimpleMLP(nn.Module):
    def __init__(self, input_channels=3, image_size=32, num_classes=10):
        super(SimpleMLP, self).__init__()
        # Calculate input size dynamically
        input_size_flat = input_channels * image_size * image_size
        self.fc1 = nn.Linear(input_size_flat, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_classes)
        self.flatten = nn.Flatten()

    def forward(self, x):
        x = self.flatten(x)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# --- Helper Functions ---

def set_seed(seed):
    """Sets random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

# Modified get_model to accept dataset characteristics
def get_model(model_name, num_classes=10, input_channels=3, image_size=32):
    """Loads the specified model, adapting for dataset specifics."""
    if model_name == 'resnet18':
        model = models.resnet18(weights=None)
        # Modify input layer if needed (e.g., for grayscale)
        if input_channels == 1:
            # Keep original weights, but sum them for the single channel
            original_weights = model.conv1.weight.data
            model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
            model.conv1.weight.data = original_weights.sum(dim=1, keepdim=True) # Sum R,G,B weights
        # Modify final layer for num_classes
        num_ftrs = model.fc.in_features
        model.fc = nn.Linear(num_ftrs, num_classes)
    elif model_name == 'resnet50':
        model = models.resnet50(weights=None)
        if input_channels == 1:
            original_weights = model.conv1.weight.data
            model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
            model.conv1.weight.data = original_weights.sum(dim=1, keepdim=True)
        num_ftrs = model.fc.in_features
        model.fc = nn.Linear(num_ftrs, num_classes)
    elif model_name == 'simple_cnn':
        model = SimpleCNN(input_channels=input_channels, image_size=image_size, num_classes=num_classes)
    elif model_name == 'mlp':
        model = SimpleMLP(input_channels=input_channels, image_size=image_size, num_classes=num_classes)
    else:
        raise ValueError(f"Unknown model name: {model_name}")
    return model

# NEW function to get datasets and their properties
def get_datasets(dataset_name, data_root='./data'):
    """Loads the specified dataset and returns datasets, transforms, and properties."""
    print(f"Loading {dataset_name} dataset...")
    if dataset_name == 'cifar10':
        num_classes = 10
        input_channels = 3
        image_size = 32
        # CIFAR-10 specific transforms
        # Mean/Std calculated for CIFAR-10
        normalize = transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize,
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
        # Load datasets
        train_dataset_full = torchvision.datasets.CIFAR10(
            root=data_root, train=True, download=True, transform=transform_train)
        test_dataset = torchvision.datasets.CIFAR10(
            root=data_root, train=False, download=True, transform=transform_test)

    elif dataset_name == 'mnist':
        num_classes = 10
        input_channels = 1
        image_size = 28
        # MNIST specific transforms
        # Mean/Std commonly used for MNIST
        normalize = transforms.Normalize((0.1307,), (0.3081,))
        transform_train = transforms.Compose([
            # transforms.RandomAffine(degrees=10, translate=(0.1, 0.1), scale=(0.9, 1.1)), # Example MNIST augmentation
            transforms.ToTensor(),
            normalize,
            # transforms.Pad(2) # Optional: Pad to 32x32 if needed for certain architectures, but better to adapt model
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            normalize,
            # transforms.Pad(2) # Match padding if used in train
        ])
        # Load datasets
        train_dataset_full = torchvision.datasets.MNIST(
            root=data_root, train=True, download=True, transform=transform_train)
        test_dataset = torchvision.datasets.MNIST(
            root=data_root, train=False, download=True, transform=transform_test)

    elif dataset_name == 'fashionmnist':
        num_classes = 10
        input_channels = 1
        image_size = 28
        # FashionMNIST specific transforms (often same structure as MNIST)
        normalize = transforms.Normalize((0.5,), (0.5,)) # Simpler normalization often used
        transform_train = transforms.Compose([
             transforms.RandomHorizontalFlip(), # Simple augmentation
             transforms.ToTensor(),
             normalize,
             # transforms.Pad(2)
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            normalize,
            # transforms.Pad(2)
        ])
        # Load datasets
        train_dataset_full = torchvision.datasets.FashionMNIST(
            root=data_root, train=True, download=True, transform=transform_train)
        test_dataset = torchvision.datasets.FashionMNIST(
            root=data_root, train=False, download=True, transform=transform_test)

    elif dataset_name == 'svhn':
        num_classes = 10
        input_channels = 3
        image_size = 32
        # SVHN specific transforms (RGB, 32x32 like CIFAR, but different distribution)
        # Calculate or find specific mean/std for SVHN for best results
        # Using CIFAR stats as a placeholder, but *should* be replaced
        normalize = transforms.Normalize((0.4377, 0.4438, 0.4728), (0.1980, 0.2010, 0.1970)) # Approx SVHN stats
        transform_train = transforms.Compose([
            # transforms.RandomCrop(32, padding=4), # SVHN images might have digits off-center
            transforms.ToTensor(),
            normalize,
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
        # Load datasets (Note: SVHN uses 'train' and 'test' splits directly)
        train_dataset_full = torchvision.datasets.SVHN(
            root=data_root, split='train', download=True, transform=transform_train)
        test_dataset = torchvision.datasets.SVHN(
            root=data_root, split='test', download=True, transform=transform_test)

    else:
        raise ValueError(f"Unknown dataset name: {dataset_name}")

    return train_dataset_full, test_dataset, num_classes, input_channels, image_size


def train(model, device, train_loader, optimizer, criterion, epoch):
    """Training loop for one epoch with tqdm progress bar."""
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    start_time = time.time()
    pbar = tqdm(enumerate(train_loader), total=len(train_loader), desc=f"Epoch {epoch} Training", leave=False)
    for batch_idx, (data, target) in pbar:
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
        _, predicted = output.max(1)
        total += target.size(0)
        correct += predicted.eq(target).sum().item()
        pbar.set_postfix(loss=f'{loss.item():.4f}', acc=f'{100.*correct/total:.2f}%')

    avg_loss = train_loss / len(train_loader)
    accuracy = 100. * correct / total
    end_time = time.time()
    # No need for extra print here if using tqdm correctly
    # print(f'\n--- Epoch {epoch} Training Summary ---')
    # print(f'Average Loss: {avg_loss:.4f}, Accuracy: {correct}/{total} ({accuracy:.2f}%)')
    # print(f'Time: {end_time - start_time:.2f}s')
    return avg_loss, accuracy


def test(model, device, test_loader, criterion):
    """Evaluation loop with tqdm progress bar."""
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    start_time = time.time()
    pbar = tqdm(test_loader, desc="Testing", leave=False)
    with torch.no_grad():
        for data, target in pbar:
            data, target = data.to(device), target.to(device)
            output = model(data)
            batch_loss = criterion(output, target).item()
            test_loss += batch_loss * data.size(0)
            _, predicted = output.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
            pbar.set_postfix(loss=f'{batch_loss:.4f}', acc=f'{100.*correct/total:.2f}%')

    avg_loss = test_loss / total
    accuracy = 100. * correct / total
    end_time = time.time()
    # No need for extra print here if using tqdm correctly
    # print(f'\n--- Test Set Performance Summary ---')
    # print(f'Average Loss: {avg_loss:.4f}, Accuracy: {correct}/{total} ({accuracy:.2f}%)')
    # print(f'Time: {end_time - start_time:.2f}s')
    return avg_loss, accuracy

# --- Main Execution ---

def main():
    # --- Argument Parsing ---
    parser = argparse.ArgumentParser(description='PyTorch Image Classification Training')
    parser.add_argument('--dataset', type=str, required=True, # Make dataset selection required
                        choices=['cifar10', 'mnist', 'fashionmnist', 'svhn'],
                        help='Dataset to use')
    parser.add_argument('--model', type=str, required=True,
                        choices=['resnet18', 'resnet50', 'simple_cnn', 'mlp'],
                        help='Model architecture to use')
    parser.add_argument('--num_train_samples', type=float, default=1.0,
                        help='Number or fraction of training samples (e.g., 0.1 for 10%, 5000 for 5000 samples)')
    parser.add_argument('--epochs', type=int, default=20, metavar='N',
                        help='number of epochs to train (default: 20)')
    parser.add_argument('--batch_size', type=int, default=128, metavar='N',
                        help='input batch size for training (default: 128)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                        help='learning rate (default: 0.001)')
    parser.add_argument('--seed', type=int, default=42, metavar='S',
                        help='random seed (default: 42)')
    parser.add_argument('--no_cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--results_dir', type=str, default='./results',
                        help='Base directory to save results')
    parser.add_argument('--data_root', type=str, default='./data',
                        help='Directory where datasets are stored/downloaded') # Add data root arg
    args = parser.parse_args()

    # --- Setup ---
    set_seed(args.seed)
    use_cuda = not args.no_cuda and torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    print(f"Using device: {device}")
    print(f"Selected Dataset: {args.dataset}")
    print(f"Selected Model: {args.model}")


    # --- Data Loading and Preprocessing (using get_datasets) ---
    train_dataset_full, test_dataset, num_classes, input_channels, image_size = get_datasets(
        args.dataset, data_root=args.data_root
    )

    # --- Handle Subset of Training Data ---
    num_train_samples_full = len(train_dataset_full)
    num_samples_input = args.num_train_samples

    if num_samples_input > 0 and num_samples_input <= 1:
        num_actual_train_samples = int(num_train_samples_full * num_samples_input)
        print(f"Using {num_samples_input * 100:.1f}% of training data: {num_actual_train_samples} samples.")
    elif num_samples_input > 1:
        num_actual_train_samples = int(num_samples_input)
        if num_actual_train_samples > num_train_samples_full:
            print(f"Warning: Requested {num_actual_train_samples} samples, but dataset only has {num_train_samples_full}. Using all {num_train_samples_full} samples.")
            num_actual_train_samples = num_train_samples_full
        print(f"Using {num_actual_train_samples} training samples.")
    else:
        raise ValueError("num_train_samples must be > 0")

    num_samples_str = str(num_actual_train_samples)

    # Create subset if necessary
    if num_actual_train_samples < num_train_samples_full:
        # Ensure reproducibility of subset selection
        g = torch.Generator()
        g.manual_seed(args.seed) # Use same seed for permutation
        indices = torch.randperm(num_train_samples_full, generator=g)[:num_actual_train_samples].tolist()
        train_dataset = Subset(train_dataset_full, indices)
    else:
        train_dataset = train_dataset_full

    # Adjust batch size if dataset is very small
    effective_batch_size = min(args.batch_size, len(train_dataset)) if len(train_dataset) > 0 else 1
    if effective_batch_size < args.batch_size :
         print(f"Warning: Reducing batch size from {args.batch_size} to {effective_batch_size} due to small dataset size.")

    # Avoid issues if train_dataset becomes empty (e.g. requesting 0 samples)
    if len(train_dataset) == 0:
        print("Warning: Number of training samples is 0. Skipping training.")
        train_loader = None # Set loader to None
    else:
       train_loader = DataLoader(train_dataset, batch_size=effective_batch_size, shuffle=True, num_workers=2, pin_memory=use_cuda)

    test_loader = DataLoader(test_dataset, batch_size=args.batch_size*2, shuffle=False, num_workers=2, pin_memory=use_cuda) # pin_memory=True usually helps GPU training

    # --- Model, Criterion, Optimizer ---
    # Pass dataset properties to get_model
    model = get_model(args.model, num_classes=num_classes, input_channels=input_channels, image_size=image_size).to(device)
    print(f"Instantiated model: {args.model} for {args.dataset}")
    # Print model structure (optional)
    # print(model)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    # Consider different optimizers/LRs per dataset/model? For now, use Adam.

    # --- Result Saving Setup ---
    # Path now includes args.dataset
    result_dir = os.path.join(args.results_dir, args.dataset, args.model, num_samples_str)
    os.makedirs(result_dir, exist_ok=True)
    result_file = os.path.join(result_dir, 'result.json')
    print(f"Results will be saved to: {result_file}")

    results_data = {
        'args': vars(args),
        'dataset_properties': {
            'num_classes': num_classes,
            'input_channels': input_channels,
            'image_size': image_size,
            'full_train_size': num_train_samples_full,
            'actual_train_samples': num_actual_train_samples
        },
        'best_test_accuracy': 0.0,
        'epoch_results': []
    }

    # --- Training and Evaluation Loop ---
    start_train_time = time.time()
    epoch_pbar = tqdm(range(1, args.epochs + 1), desc="Total Epochs")
    for epoch in epoch_pbar:

        # Only train if there's data
        if train_loader:
            train_loss, train_acc = train(model, device, train_loader, optimizer, criterion, epoch)
        else:
            # If no training data, set train metrics to indicate this
            train_loss, train_acc = -1.0, 0.0
            print(f"--- Epoch {epoch} Training Skipped (0 samples) ---")


        test_loss, test_acc = test(model, device, test_loader, criterion)

        epoch_summary = f"Epoch {epoch}/{args.epochs} -> Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}% | Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%"
        epoch_pbar.set_description(epoch_summary) # Update overall progress bar description

        # Store results for this epoch
        epoch_result = {
            'epoch': epoch,
            'train_loss': train_loss if train_loader else None, # Store None if skipped
            'train_accuracy': train_acc if train_loader else None,
            'test_loss': test_loss,
            'test_accuracy': test_acc,
        }
        results_data['epoch_results'].append(epoch_result)

        # Update best accuracy
        if test_acc > results_data['best_test_accuracy']:
            # print(f"*** New best test accuracy: {test_acc:.2f}% (Previous: {results_data['best_test_accuracy']:.2f}%) ***")
            results_data['best_test_accuracy'] = test_acc
            # Optional: Save best model checkpoint
            # torch.save(model.state_dict(), os.path.join(result_dir, 'best_model.pth'))

        # Save results after each epoch
        try:
            with open(result_file, 'w') as f:
                json.dump(results_data, f, indent=4)
        except IOError as e:
            print(f"Error saving results to {result_file}: {e}")
        except TypeError as e:
             print(f"Serialization Error: {e}. Check data types in results_data.")
             def default_serializer(o):
                 if isinstance(o, np.integer): return int(o)
                 if isinstance(o, np.floating): return float(o)
                 if isinstance(o, np.ndarray): return o.tolist()
                 raise TypeError
             try:
                 with open(result_file, 'w') as f:
                    json.dump(results_data, f, indent=4, default=default_serializer)
             except Exception as e_inner:
                 print(f"Fallback serialization also failed: {e_inner}")

        epoch_pbar.set_postfix(best_test_acc=f'{results_data["best_test_accuracy"]:.2f}%')


    end_train_time = time.time()
    total_training_time = end_train_time - start_train_time
    print(f"\n===== Training Complete =====")
    print(f"Total Training Time: {total_training_time:.2f}s ({total_training_time/60:.2f} minutes)")
    print(f"Best Test Accuracy Achieved: {results_data['best_test_accuracy']:.2f}%")
    print(f"Final results saved to: {result_file}")


if __name__ == '__main__':
    main()