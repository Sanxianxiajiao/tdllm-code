import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import json
import re
from sklearn.preprocessing import MinMaxScaler
from cycler import cycler # For custom color cycling
import seaborn as sns # For automatic color palette generation

# --- 0. Configuration and Constants ---
# Paths
DATA_ANALYSIS_DIR = './data_analys_k'
MIN_SAMPLE_SIZE_FILE = './min_sample_sizes.json'
OUTPUT_DIR = './pic/'

# Features and Target
FEATURES_RAW_NAMES = ['num_classes', 'label_entropy', 'effective_dim', 'intra_class_var', 'local_consistency', 'separability_score']
TARGET_COLUMN = 'min_sample_size'
KDL_FEATURES = ['K', 'D', 'L']

# Define the 6 features that will be used for the radar plot
RADAR_PLOT_FEATURES = FEATURES_RAW_NAMES

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(DATA_ANALYSIS_DIR, exist_ok=True)

# --- Create dummy files for testing if they don't exist ---
default_dummy_target_data_keys = {
    "taskA": 100, "taskB": 150, "taskC": 200, "taskD": 120, "taskE": 180,
    "taskF": 90, "taskG": 210, "taskH": 130, "taskI": 160, "taskJ": 220,
    "taskK": 110, "taskL": 170, "taskM": 230, "taskN": 140, "taskO": 190,
    "TaskP_metrics": 250, "TaskQ_complexity_metrics": 260, "task_r_extra": 270,
    "MyClutrrTaskSample": 280, "Another_clutrr_dataset": 290 # Added clutrr examples
}
dummy_tasks_bases = ["taskA", "taskB", "taskC", "taskD", "taskE",
               "taskF", "taskG", "taskH", "taskI", "taskJ",
               "taskK", "taskL", "taskM", "taskN", "taskO",
               "TaskP", "TaskQ", "task_r",
               "MyClutrrTaskSample", "Another_clutrr_dataset"] # Added clutrr examples
default_target_values = list(default_dummy_target_data_keys.values())
if len(default_target_values) < len(dummy_tasks_bases):
    default_target_values.extend([100 + i*10 for i in range(len(dummy_tasks_bases) - len(default_target_values))])

recreate_target_file = False
if not os.path.exists(MIN_SAMPLE_SIZE_FILE):
    recreate_target_file = True
else:
    try:
        with open(MIN_SAMPLE_SIZE_FILE, 'r') as f:
            existing_target_data = json.load(f)
        # Check if new dummy keys are missing or if old format is present
        is_old_format = any(old_key for old_key in ["taskA", "TaskP_metrics"] if old_key.lower() in existing_target_data) # simplified check
        new_dummy_keys_to_check = [f"dummy{i}_{name.lower().replace('_metrics','').replace('_complexity_metrics','').replace('_extra','').replace('task','tsk')}"
                                   for i, name in enumerate(dummy_tasks_bases) if "clutrr" in name.lower()]
        missing_new_clutrr_keys = any(key not in existing_target_data for key in new_dummy_keys_to_check)

        if is_old_format or missing_new_clutrr_keys:
            recreate_target_file = True
            print("Old target file format detected or new clutrr dummy keys missing, will recreate with unique keys including clutrr examples.")
    except json.JSONDecodeError:
        recreate_target_file = True
        print(f"Warning: {MIN_SAMPLE_SIZE_FILE} is corrupted. Recreating.")

if recreate_target_file:
    dummy_target_data_updated = {
        f"dummy{i}_{name.lower().replace('_metrics','').replace('_complexity_metrics','').replace('_extra','').replace('task','tsk')}": val
        for i, (name, val) in enumerate(zip(dummy_tasks_bases, default_target_values[:len(dummy_tasks_bases)]))
    }
    # with open(MIN_SAMPLE_SIZE_FILE, 'w') as f: json.dump(dummy_target_data_updated, f)
    # print(f"Recreated dummy target file with unique keys: {MIN_SAMPLE_SIZE_FILE}")

dummy_tasks_for_file_gen = [f"dummy{i}_{name.lower().replace('_metrics','').replace('_complexity_metrics','').replace('_extra','').replace('task','tsk')}"
                            for i, name in enumerate(dummy_tasks_bases)]

for i, task_name_base_unique in enumerate(dummy_tasks_for_file_gen):
    # Ensure clutrr tasks get diverse filenames for testing robustness
    original_base_name_for_suffix = dummy_tasks_bases[i] # Use original name to decide suffix pattern
    if "clutrr" in task_name_base_unique.lower() and "another" in task_name_base_unique.lower() : # specific clutrr task
        filename = f"{task_name_base_unique}.json"
    elif "clutrr" in task_name_base_unique.lower(): # other clutrr task
        filename = f"{task_name_base_unique}_metrics.json"
    elif i % 4 == 0: filename = f"{task_name_base_unique}_complexity_metrics.json"
    elif i % 4 == 1: filename = f"{task_name_base_unique}_metrics.json"
    elif i % 4 == 2: filename = f"{task_name_base_unique}.json"
    else: filename = f"{task_name_base_unique}_extra_info.json"
    filepath = os.path.join(DATA_ANALYSIS_DIR, filename)

    if not os.path.exists(filepath):
        dummy_metrics = {
            'num_classes': np.random.randint(2, 15) + (i%5),
            'label_entropy': np.random.rand() * (0.8 + 0.01*i),
            'effective_dim': np.random.rand() * 10 + (i%3),
            'intra_class_var' if i % 2 == 0 else 'intra_class_var_avg': np.random.rand() * 5 + (i%4),
            'local_consistency': np.random.rand()* (0.7 + 0.015*i),
            'separability_score': np.random.rand()* (0.6 + 0.02*i)
        }
        # Special values for clutrr tasks for easier identification in plot if needed
        if "clutrr" in task_name_base_unique.lower():
            dummy_metrics['num_classes'] = 5 + (i % 3) # Make clutrr num_classes distinct
            dummy_metrics['label_entropy'] = 0.1 + (i % 3) * 0.1 # Lower entropy for clutrr
            dummy_metrics['effective_dim'] = 2.0 + (i % 3) * 0.5

        dummy_metrics['label_entropy'] = np.clip(dummy_metrics['label_entropy'], 0.01, 1)
        dummy_metrics['local_consistency'] = np.clip(dummy_metrics['local_consistency'], 0, 1)
        dummy_metrics['separability_score'] = np.clip(dummy_metrics['separability_score'], 0, 1)
        dummy_metrics['num_classes'] = max(2, dummy_metrics['num_classes'])

        # Adapt data_to_write based on filename structure for clutrr tasks too
        if filename.endswith("_complexity_metrics.json"): data_to_write = {'complexity_metrics': dummy_metrics}
        elif filename.endswith("_metrics.json"): data_to_write = {'metrics': dummy_metrics}
        elif filename.endswith(".json"): data_to_write = dummy_metrics # Direct metrics or specific clutrr
        else: data_to_write = {'other_info': dummy_metrics} # Fallback for _extra_info

        with open(filepath, 'w') as f: json.dump(data_to_write, f)

if not any(os.scandir(DATA_ANALYSIS_DIR)):
    print(f"No dummy files were created in {DATA_ANALYSIS_DIR}. Check permissions or logic.")
else:
    print(f"Checked/created dummy metrics files in {DATA_ANALYSIS_DIR}")
# --- End dummy file creation ---

# --- 1. Load and Prepare Data ---
def load_target_data(filepath):
    print(f"Loading target values from {filepath}...")
    try:
        with open(filepath, 'r') as f: target_data_raw = json.load(f)
        target_data_lower = {k.lower(): pd.to_numeric(v, errors='coerce') for k, v in target_data_raw.items()}
        target_data_valid = {k: v for k, v in target_data_lower.items() if pd.notna(v)}
        print(f"Successfully loaded and validated target values for {len(target_data_valid)} tasks.")
        if len(target_data_lower) > len(target_data_valid):
            print(f"  - Warning: Removed {len(target_data_lower) - len(target_data_valid)} tasks from target list due to non-numeric values.")
        return target_data_valid
    except FileNotFoundError: print(f"Error: Target file not found {filepath}"); exit()
    except json.JSONDecodeError: print(f"Error: Could not parse target file {filepath}"); exit()

def load_complexity_metrics(data_dir, expected_features, target_data_keys_lower):
    print(f"\nLoading complexity metrics from directory {data_dir}...")
    all_task_metrics_list = []
    stats = {"processed": 0, "skipped_json": 0, "skipped_metrics": 0, "skipped_nomatch": 0, "matched_task":0}
    if not os.path.isdir(data_dir): print(f"Error: Metrics directory not found {data_dir}"); exit()

    known_suffixes = ["_complexity_metrics", "_metrics", "_extra_info", "_extra", ""] # Added "" for exact match before suffix stripping

    for filename in os.listdir(data_dir):
        if not filename.endswith('.json'): continue
        stats["processed"] += 1
        filepath = os.path.join(data_dir, filename)

        task_name_from_file_lc = None
        filename_base_lc_no_ext = os.path.splitext(filename)[0].lower()

        matched_key = None
        # Sort target keys by length (descending) to match longer keys first (e.g., "task_abc_metrics" vs "task_abc")
        sorted_target_keys = sorted(list(target_data_keys_lower), key=len, reverse=True)

        for t_key in sorted_target_keys:
            # Exact match check (e.g. t_key is "dummy0_tska" and filename_base is "dummy0_tska")
            if filename_base_lc_no_ext == t_key:
                matched_key = t_key
                break
            # Starts with check (e.g. t_key is "dummy0_tska" and filename_base is "dummy0_tska_metrics")
            if filename_base_lc_no_ext.startswith(t_key):
                remainder = filename_base_lc_no_ext[len(t_key):]
                # Check if remainder is one of the known suffixes or empty
                if remainder == "" or any(remainder == s for s in known_suffixes if s): # exact suffix match
                     matched_key = t_key
                     break
                if any(remainder.startswith(s) for s in known_suffixes if s): # starts with suffix (e.g. _metrics_v2)
                     matched_key = t_key
                     break


        if matched_key:
            task_name_from_file_lc = matched_key
            # print(f"Matched file '{filename}' to target key '{task_name_from_file_lc}'")
        else:
            stats["skipped_nomatch"] += 1
            # print(f"No match for file '{filename}' (base: '{filename_base_lc_no_ext}') among target keys.")
            continue


        stats["matched_task"] +=1
        try:
            with open(filepath, 'r') as f: data = json.load(f)
            metrics_values = {}; source_dict = None

            def check_keys(d, keys):
                return all(k in d or (k == 'intra_class_var' and 'intra_class_var_avg' in d) for k in keys)

            if isinstance(data, dict) and check_keys(data, expected_features): source_dict = data
            elif 'complexity_metrics' in data and isinstance(data['complexity_metrics'], dict) and \
                 check_keys(data['complexity_metrics'], expected_features):
                source_dict = data['complexity_metrics']
            elif 'metrics' in data and isinstance(data['metrics'], dict) and \
                 check_keys(data['metrics'], expected_features):
                source_dict = data['metrics']

            if source_dict:
                valid_metric_set = True
                for feat in expected_features:
                    val_key = feat
                    if feat == 'intra_class_var' and feat not in source_dict and 'intra_class_var_avg' in source_dict:
                        val_key = 'intra_class_var_avg'

                    val = source_dict.get(val_key)

                    if val is not None and np.isfinite(pd.to_numeric(val, errors='coerce')):
                         metrics_values[feat] = float(val)
                    else: valid_metric_set = False; break

                if valid_metric_set:
                    metrics_values['task_name'] = task_name_from_file_lc
                    all_task_metrics_list.append(metrics_values)
                else: stats["skipped_metrics"] += 1; # print(f"Skipped {filename} due to invalid/missing metric values in source_dict.")
            else: stats["skipped_metrics"] += 1; # print(f"Skipped {filename} due to no suitable metrics dictionary found.")
        except json.JSONDecodeError: stats["skipped_json"] += 1; print(f"JSONDecodeError for {filename}")
        except Exception as e: stats["skipped_json"] += 1; print(f"Error processing file {filename}: {e}")

    print_load_stats(stats)
    df_metrics = pd.DataFrame(all_task_metrics_list)
    if not df_metrics.empty: df_metrics.drop_duplicates(subset=['task_name'], keep='first', inplace=True)
    return df_metrics

def print_load_stats(stats):
    print(f"\nProcessed {stats['processed']} JSON files.")
    print(f"Matched {stats['matched_task']} files to target tasks.")
    if stats['skipped_json'] > 0: print(f"Skipped {stats['skipped_json']} files due to JSON parsing or other reading errors.")
    if stats['skipped_metrics'] > 0: print(f"Skipped {stats['skipped_metrics']} files due to missing or invalid metric data.")
    if stats['skipped_nomatch'] > 0: print(f"Skipped {stats['skipped_nomatch']} files (no match to target keys).")

target_data = load_target_data(MIN_SAMPLE_SIZE_FILE)
df_features_raw = load_complexity_metrics(DATA_ANALYSIS_DIR, FEATURES_RAW_NAMES, target_data.keys())

if df_features_raw.empty: print("\nError: No valid metric data loaded. Exiting."); exit()

df_features_raw.set_index('task_name', inplace=True)
df_target = pd.Series(target_data, name=TARGET_COLUMN); df_target.index.name = 'task_name'
df_merged_orig = pd.merge(df_features_raw, df_target, left_index=True, right_index=True, how='inner')

print(f"\nSuccessfully merged data for {len(df_merged_orig)} tasks.")
if len(df_merged_orig) == 0:
    print("No data after merging. Check target keys and metric file names/contents.")
    print("Target keys available:", list(target_data.keys()))
    print("Metric task names found:", list(df_features_raw.index) if not df_features_raw.empty else "None")
    exit()

if len(df_merged_orig) < len(target_data): print(f"  - Note: Merged fewer tasks than in target data ({len(df_merged_orig)} vs {len(target_data)}).")
if len(df_merged_orig) < df_features_raw.index.nunique(): print(f"  - Note: Merged fewer tasks than unique tasks in features ({len(df_merged_orig)} vs {df_features_raw.index.nunique()}).")

if df_merged_orig.empty: print("\nError: No tasks available for analysis after merging. Exiting."); exit()
num_samples_total = len(df_merged_orig)

# --- 2. Standardize Proxy Metrics (Original 6 Features) for KDL calculation ---
df_scaled_for_kdl = df_merged_orig.copy()
scaler_proxies_kdl = MinMaxScaler()
df_scaled_for_kdl[FEATURES_RAW_NAMES] = scaler_proxies_kdl.fit_transform(df_merged_orig[FEATURES_RAW_NAMES])
rename_map_kdl = {
    'num_classes': 'n_d_scaled', 'label_entropy': 'H_Y_scaled',
    'effective_dim': 'e_d_scaled', 'intra_class_var': 'v_d_scaled',
    'local_consistency': 'l_d_scaled', 'separability_score': 's_d_scaled'
}
df_scaled_for_kdl.rename(columns=rename_map_kdl, inplace=True)
print("\nOriginal 6 features standardized for KDL calculation.")

# --- 3. Calculate K, D, L Scores ---
df_scaled_for_kdl['K'] = ((1 - df_scaled_for_kdl['l_d_scaled']) + (1 - df_scaled_for_kdl['s_d_scaled'])) / 2
df_scaled_for_kdl['D'] = df_scaled_for_kdl[['e_d_scaled', 'n_d_scaled', 'H_Y_scaled', 'v_d_scaled']].mean(axis=1)
df_scaled_for_kdl['L'] = ((1 - df_scaled_for_kdl['H_Y_scaled']) + (1 - df_scaled_for_kdl['v_d_scaled']) + \
                           df_scaled_for_kdl['l_d_scaled'] + df_scaled_for_kdl['s_d_scaled']) / 4
kdl_scaler = MinMaxScaler()
df_scaled_for_kdl[KDL_FEATURES] = kdl_scaler.fit_transform(df_scaled_for_kdl[KDL_FEATURES])
print("K, D, L scores calculated and standardized.")

# --- 4. Prepare Data for Custom Remapped Radar Plot ---

def custom_linear_interpolate(value, x_known, y_known):
    if not isinstance(x_known, np.ndarray): x_known = np.array(x_known)
    if not isinstance(y_known, np.ndarray): y_known = np.array(y_known)

    unique_x_indices = np.sort(np.unique(x_known, return_index=True)[1])
    x_known = x_known[unique_x_indices]
    y_known = y_known[unique_x_indices]

    if len(x_known) == 0: return 0.5
    if len(x_known) == 1: return y_known[0]

    if value <= x_known[0]: return y_known[0]
    if value >= x_known[-1]: return y_known[-1]

    idx = np.searchsorted(x_known, value, side='right')

    if idx == 0:
        return y_known[0]
    if value == x_known[idx-1]:
        return y_known[idx-1]

    x0, x1 = x_known[idx-1], x_known[idx]
    y0, y1 = y_known[idx-1], y_known[idx]

    if x0 == x1:
        return y0

    interpolated_y = y0 + (value - x0) * (y1 - y0) / (x1 - x0)
    return interpolated_y

df_remapped_for_plot = pd.DataFrame(index=df_merged_orig.index)
segment_boundaries_all_features_detailed = {}

print("\nRemapping features for radar plot based on 'every 5th sample' segments:")
for feature_name in RADAR_PLOT_FEATURES:
    original_values_for_feature = df_merged_orig[feature_name].sort_values().values

    tick_ilocs = [0]
    current_sample_iloc = 4
    while current_sample_iloc < num_samples_total -1 :
        tick_ilocs.append(current_sample_iloc)
        current_sample_iloc += 5
    if num_samples_total > 0 :
        tick_ilocs.append(num_samples_total - 1)
    else:
        df_remapped_for_plot[feature_name] = 0.5
        segment_boundaries_all_features_detailed[feature_name] = {
            'orig_values': np.array([0]),
            'remapped_values': np.array([0.5])
        }
        print(f"  Feature '{feature_name}': No samples, mapping to 0.5.")
        continue

    tick_ilocs = sorted(list(set(tick_ilocs)))
    segment_boundaries_orig_raw = original_values_for_feature[tick_ilocs]
    segment_boundaries_orig = np.unique(segment_boundaries_orig_raw)

    num_unique_boundaries = len(segment_boundaries_orig)
    if feature_name is 'local_consistency':
        segment_boundaries_orig[0] = 0.01
        segment_boundaries_orig[1] = 0.02
        segment_boundaries_orig[2] = 0.04
        segment_boundaries_orig[3] = 0.08
        segment_boundaries_orig[4] = 0.16
        print(segment_boundaries_orig[0])
        print(segment_boundaries_orig)

    if num_unique_boundaries <= 1:
        print(f"  Feature '{feature_name}': All values are (nearly) identical. Mapping all to 0.5 for plot.")
        df_remapped_for_plot[feature_name] = 0.5
        val_to_use = segment_boundaries_orig[0] if num_unique_boundaries > 0 else 0
        segment_boundaries_all_features_detailed[feature_name] = {
            'orig_values': np.array([val_to_use]),
            'remapped_values': np.array([0.5])
        }
    else:
        y_points_for_interp = np.linspace(0, 1, num_unique_boundaries)
        segment_boundaries_all_features_detailed[feature_name] = {
            'orig_values': segment_boundaries_orig,
            'remapped_values': y_points_for_interp
        }

        remapped_values = []
        for task_idx in df_merged_orig.index:
            original_value_for_task = df_merged_orig.loc[task_idx, feature_name]
            remapped_val = custom_linear_interpolate(original_value_for_task, segment_boundaries_orig, y_points_for_interp)
            remapped_values.append(remapped_val)
        df_remapped_for_plot[feature_name] = remapped_values
        print(f"  Feature '{feature_name}': {len(segment_boundaries_orig)-1} segments defined by original boundaries {np.round(segment_boundaries_orig,2)} which map to remapped points {np.round(y_points_for_interp,2)}.")

print("\nRemapped data for radar plot (first 5 rows of all data):")
print(df_remapped_for_plot)

# --- 5. Generate Radar Plot using Remapped Features ---

# Define KDL relationships for axis labels
kdl_relationships_map = {
    'effective_dim': {'symbol': r'$e_d$', 'impact': r'($\mathcal{D} \uparrow$)'},
    'num_classes': {'symbol': r'$n_d$', 'impact': r'($\mathcal{D} \uparrow$)'},
    'label_entropy': {'symbol': r'$H(Y)$', 'impact': r'($\mathcal{D} \uparrow, \mathcal{L} \downarrow$)'},
    'intra_class_var': {'symbol': r'$v_d$', 'impact': r'($\mathcal{D} \uparrow, \mathcal{L} \downarrow$)'},
    'local_consistency': {'symbol': r'$l_d$', 'impact': r'($\mathcal{K} \downarrow, \mathcal{L} \uparrow$)'},
    'separability_score': {'symbol': r'$s_d$', 'impact': r'($\mathcal{K} \downarrow, \mathcal{L} \uparrow$)'}
}
base_feature_display_titles = {
    'num_classes': 'Num Classes',
    'label_entropy': 'Label Entropy',
    'effective_dim': 'Effective Dim',
    'intra_class_var': 'Intra-Class Var',
    'local_consistency': 'Local Consistency',
    'separability_score': 'Separability Score'
}

radar_labels_axes_display_kdl = []
for feature_name in RADAR_PLOT_FEATURES:
    title = base_feature_display_titles.get(feature_name, feature_name.replace('_', ' ').title())
    relationship = kdl_relationships_map.get(feature_name)
    if relationship:
        symbol_str = relationship['symbol']
        impact_str = relationship['impact']
        label = fr'{title} ({symbol_str})' + '\n' + fr'{impact_str}'
    else:
        label = title
    radar_labels_axes_display_kdl.append(label)
radar_labels_axes_display_kdl = np.array(radar_labels_axes_display_kdl)


# --- MODIFICATION: Filter for 'clutrr' datasets for plotting ---
# We operate on df_remapped_for_plot which contains all tasks after remapping.
# Now, we filter this DataFrame to get only 'clutrr' tasks for plotting.
df_remapped_for_plot_plotting = df_remapped_for_plot[
    df_remapped_for_plot.index.str.lower().str.contains('clutrr_')
].copy()
# --- END MODIFICATION ---

# --- Automatically generate color palette using seaborn ---
# --- MODIFICATION: Update num_tasks_to_plot based on filtered data ---
num_tasks_to_plot = len(df_remapped_for_plot_plotting)
# --- END MODIFICATION ---

if num_tasks_to_plot == 0:
    # --- MODIFICATION: Updated message ---
    print("\nNo 'clutrr' tasks found after filtering. Exiting plotting step for 'clutrr'-only plot.")
    # --- END MODIFICATION ---
else:
    # --- MODIFICATION: Updated message ---
    print(f"\nGenerating color palette for {num_tasks_to_plot} 'clutrr' task(s) using seaborn...")
    # --- END MODIFICATION ---
    try:
        if num_tasks_to_plot <= 10:
             plot_palette = sns.color_palette("tab10", num_tasks_to_plot)
        elif num_tasks_to_plot <= 20:
             plot_palette = sns.color_palette("tab20", num_tasks_to_plot)
        else:
            plot_palette = sns.color_palette("husl", num_tasks_to_plot)
        print(f"Successfully generated a palette of {len(plot_palette)} colors for 'clutrr' tasks.")
    except ValueError as e:
        print(f"Warning: Could not generate {num_tasks_to_plot} colors using preferred palettes for 'clutrr' tasks. Falling back to 'husl'. Error: {e}")
        try:
            plot_palette = sns.color_palette("husl", num_tasks_to_plot)
            print(f"Successfully generated a fallback palette of {len(plot_palette)} colors for 'clutrr' tasks using 'husl'.")
        except Exception as e_fallback:
            print(f"Error: Fallback palette generation failed for 'clutrr' tasks: {e_fallback}. Cannot plot.")
            plot_palette = []

    if plot_palette:
        original_rcParams = plt.rcParams.copy()
        plt.rcParams.update({
            "font.family": "serif", "font.serif": ["STIXGeneral", "Times New Roman", "DejaVu Serif", "Liberation Serif"],
            "font.size": 22,
            "axes.titlesize": 22,
            "axes.labelsize": 14,
            "xtick.labelsize": 11,
            "ytick.labelsize": 10,
            "legend.fontsize": 14,
            "legend.title_fontsize": 16,
            "lines.linewidth": 2.0,
            "lines.markersize": 2.5,
            "axes.grid": True, "grid.color": "#cccccc", "grid.linestyle": "--", "grid.linewidth": 0.6,
            "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
            "savefig.dpi": 300,
            "axes.prop_cycle": cycler(color=plot_palette)
        })

        num_radar_vars = len(RADAR_PLOT_FEATURES)
        angles = np.linspace(0, 2 * np.pi, num_radar_vars, endpoint=False).tolist()
        angles += angles[:1]

        fig, ax = plt.subplots(figsize=(15, 12), subplot_kw=dict(polar=True))
        ax.set_axisbelow(True)

        plot_handles = []
        plot_labels = []

        # --- MODIFICATION: Iterate over the filtered DataFrame ---
        for i, (task_name, row) in enumerate(df_remapped_for_plot_plotting.iterrows()):
        # --- END MODIFICATION ---
            feature_values = row[RADAR_PLOT_FEATURES].values.flatten().tolist()
            feature_values += feature_values[:1]
            line, = ax.plot(angles, feature_values, linestyle='solid', label=task_name, alpha=0.80, zorder=5)
            current_color = line.get_color()
            ax.fill(angles, feature_values, color=current_color, alpha=0.15, zorder=4)
            plot_handles.append(line)
            plot_labels.append(task_name)

        ax.set_yticks([])
        ax.set_yticklabels([])
        ax.set_ylim(0 - 0.02, 1 + 0.02)

        num_y_grid_lines = 5
        y_grid_values_for_lines = np.linspace(0, 1, num_y_grid_lines)
        for r_val in y_grid_values_for_lines:
            ax.plot(angles, [r_val] * len(angles), color='lightgray', linestyle=':', linewidth=0.6, zorder=0)

        max_labels_per_axis = 5
        tick_label_fontsize = 10
        tick_mark_color = 'gray'
        tick_mark_linewidth = 0.8
        tick_mark_radial_length = 0.01

        for i, feature_name in enumerate(RADAR_PLOT_FEATURES):
            axis_angle = angles[i]
            boundary_info = segment_boundaries_all_features_detailed.get(feature_name)
            if boundary_info:
                orig_tick_values_all = boundary_info['orig_values']
                remapped_positions_all = boundary_info['remapped_values']
                
                if len(orig_tick_values_all) <= max_labels_per_axis:
                    indices_to_show = np.arange(len(orig_tick_values_all))
                else:
                    _indices = np.linspace(0, len(orig_tick_values_all) - 1, max_labels_per_axis, dtype=int)
                    indices_to_show = np.unique(_indices)
                
                selected_orig_ticks = orig_tick_values_all[indices_to_show]
                selected_remapped_positions = remapped_positions_all[indices_to_show]

                for tick_idx, (orig_label_val, r_pos) in enumerate(zip(selected_orig_ticks, selected_remapped_positions)):
                    if tick_idx == 0 and np.isclose(r_pos, 0.0):
                        continue 

                    if feature_name == 'num_classes': label_text = f"{int(round(orig_label_val))}"
                    elif abs(orig_label_val) > 10000 or (abs(orig_label_val) != 0 and abs(orig_label_val) < 0.001): label_text = f"{orig_label_val:.1e}"
                    elif isinstance(orig_label_val, float) and orig_label_val.is_integer(): label_text = f"{int(orig_label_val)}"
                    else:
                        label_text = f"{orig_label_val:.2f}"
                        if '.' in label_text: label_text = label_text.rstrip('0').rstrip('.')
                    
                    ax.plot([axis_angle, axis_angle], [r_pos - tick_mark_radial_length / 2, r_pos + tick_mark_radial_length / 2], color=tick_mark_color, lw=tick_mark_linewidth, zorder=1)
                    
                    text_radial_offset = 0.03; text_angular_offset_rad = 0.00
                    current_text_r_pos = r_pos; va_text = 'center'; ha_text = 'center'
                    
                    if np.isclose(r_pos, 0.0): 
                        current_text_r_pos = r_pos + text_radial_offset; va_text = 'bottom'
                    elif np.isclose(r_pos, 1.0): 
                        current_text_r_pos = r_pos - text_radial_offset; va_text = 'top'
                    else:
                        display_angle_deg = np.rad2deg(axis_angle + ax.get_theta_offset()) * ax.get_theta_direction(); display_angle_deg %= 360
                        if 0 < display_angle_deg < 180: ha_text = 'left'; current_text_r_pos += 0.01
                        elif 180 < display_angle_deg < 360: ha_text = 'right'; current_text_r_pos += 0.01
                    
                    ax.text(axis_angle + text_angular_offset_rad, current_text_r_pos, label_text, 
                            ha=ha_text, va=va_text, fontsize=tick_label_fontsize, color='black', 
                            zorder=10, 
                            bbox=dict(facecolor='none', edgecolor='none', pad=0.1))

        ax.set_theta_offset(np.pi / 2)
        ax.set_theta_direction(-1)

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(radar_labels_axes_display_kdl, fontsize=10)
        for label_obj in ax.get_xticklabels():
            label_obj.set_bbox(dict(facecolor='white', edgecolor='none', alpha=0.85, pad=0.2))

        labeled_handles_sorted = sorted(zip(plot_labels, plot_handles), key=lambda x: x[0])
        final_legend_labels = [item[0] for item in labeled_handles_sorted]
        final_legend_handles = [item[1] for item in labeled_handles_sorted]
        
        legend = ax.legend(
            final_legend_handles, final_legend_labels, title="Datasets (CLUTRR-only)", # Updated legend title slightly
            loc='upper right', bbox_to_anchor=(1.5, 1.05), 
            frameon=True, facecolor='white', edgecolor='lightgray', framealpha=0.9,
            ncol=1
        )

        plt.tight_layout(pad=2.5, rect=[0, 0, 0.72, 1]) 
        # --- MODIFICATION: Update plot filename ---
        radar_plot_path = os.path.join(OUTPUT_DIR, 'radar_plot_kdl_annotated_ticks_transparent_tick_bg_clutrr_only.png')
        # --- END MODIFICATION ---
        try:
            plt.savefig(radar_plot_path, dpi=plt.rcParams["savefig.dpi"], bbox_inches='tight')
            # --- MODIFICATION: Updated save message ---
            print(f"\nCustom remapped radar plot (filtered for 'clutrr' tasks, transparent tick label background) saved to {radar_plot_path}")
            # --- END MODIFICATION ---
        except Exception as e:
            print(f"Error saving 'clutrr'-only radar plot: {e}")

        plt.close(fig)
        plt.rcParams.update(original_rcParams)

        # --- MODIFICATION: Updated final message ---
        print("\n'Clutrr'-only radar plot generated: Numeric tick labels on each axis now have a transparent background.")
        print("Axis labels include KDL impact. Colors automatically selected by seaborn for 'clutrr' tasks.")
        print("Y-axis shows original feature values at selected boundary points (excluding the first).")
        # --- END MODIFICATION ---
    else:
        print("\nPlotting of 'clutrr'-only tasks skipped because no 'clutrr' tasks were available or color palette generation failed.")

print("\nScript finished.")