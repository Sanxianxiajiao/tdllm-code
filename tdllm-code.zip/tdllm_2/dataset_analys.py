# -*- coding: utf-8 -*-
# 在文件开头添加这行来支持中文注释（如果需要）
import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.models as models
import torchaudio
import torchaudio.transforms as T
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.datasets import load_digits, fetch_olivetti_faces, fetch_covtype # New sklearn imports
from scipy.stats import entropy
from scipy.spatial.distance import euclidean
import pandas as pd
import os
import json
import argparse
from tqdm import tqdm
import warnings
import time # For simple timing

# Ignore specific warnings from libraries like sklearn or torchaudio if needed
warnings.filterwarnings("ignore", category=UserWarning, module='torchvision')
warnings.filterwarnings("ignore", category=UserWarning, module='torchaudio')
warnings.filterwarnings("ignore", category=FutureWarning) # Often from sklearn/numpy interactions
# Ignore specific sklearn warnings if they become noisy
# warnings.filterwarnings("ignore", category=ConvergenceWarning)

# --- Configuration ---
DATA_ROOT = './data'
OUTPUT_DIR = './data_analys'
EMBEDDING_MODEL_NAME_CV = 'resnet50' # For CV tasks
PCA_VARIANCE_THRESHOLD = 0.95
K_NEIGHBORS = 15 # For local_consistency
SILHOUETTE_SAMPLE_SIZE = 10000 # Max samples for Silhouette score for performance
SPEECH_TARGET_LENGTH_SAMPLES = 16000 # Pad/truncate audio to 1 second (16kHz)

# --- Device Setup ---
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# === Dataset Loading and Preprocessing Functions ===

def get_cv_dataset(dataset_name, data_root):
    """Loads CV datasets for embedding."""
    supported_cv_datasets = [
        'cifar10', 'mnist', 'fashionmnist', 'svhn',
        'cifar100', 'stl10', 'food101', 'flowers102',
        'oxfordiiitpet', 'emnist', 'kmnist',
        # New torchvision datasets
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft',
        'gtsrb', 'pcam', 'semeion', 'stanford_cars', 'usps'
    ]
    if dataset_name not in supported_cv_datasets:
        raise ValueError(f"Unsupported or unknown CV dataset in get_cv_dataset: {dataset_name}")

    # Datasets that are originally grayscale (1 channel)
    grayscale_datasets = ['mnist', 'fashionmnist', 'emnist', 'kmnist',
                          'fer2013', 'semeion', 'usps'] # Added new grayscale datasets

    # Standard transform for ResNet50 embedding (Resize, 3 channels, ImageNet norm)
    embedding_transform = transforms.Compose([
        transforms.Resize((224, 224), antialias=True),
        transforms.Grayscale(num_output_channels=3) if dataset_name in grayscale_datasets else transforms.Lambda(lambda x: x),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    train_dataset_full = None
    labels = None

    print(f"Attempting to load torchvision dataset: {dataset_name}")
    # --- Existing Datasets ---
    if dataset_name == 'cifar10':
        train_dataset_full = torchvision.datasets.CIFAR10(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.targets)
    elif dataset_name == 'mnist':
        train_dataset_full = torchvision.datasets.MNIST(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    elif dataset_name == 'fashionmnist':
        train_dataset_full = torchvision.datasets.FashionMNIST(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    elif dataset_name == 'svhn':
        train_dataset_full = torchvision.datasets.SVHN(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.labels)
    elif dataset_name == 'cifar100':
        train_dataset_full = torchvision.datasets.CIFAR100(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.targets)
    elif dataset_name == 'stl10':
        train_dataset_full = torchvision.datasets.STL10(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.labels)
    elif dataset_name == 'food101':
        train_dataset_full = torchvision.datasets.Food101(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'flowers102':
        train_dataset_full = torchvision.datasets.Flowers102(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'oxfordiiitpet':
        train_dataset_full = torchvision.datasets.OxfordIIITPet(root=data_root, split='trainval', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'emnist':
        train_dataset_full = torchvision.datasets.EMNIST(root=data_root, split='byclass', train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    elif dataset_name == 'kmnist':
        train_dataset_full = torchvision.datasets.KMNIST(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = train_dataset_full.targets.numpy()
    # --- New torchvision Datasets ---
    elif dataset_name == 'caltech101':
        train_dataset_full = torchvision.datasets.Caltech101(root=data_root, download=True, transform=embedding_transform)
        # Caltech101 doesn't have a standard train/test split in torchvision; uses all data.
        # Need to iterate to get labels
        labels = np.array([label for _, label in train_dataset_full])
    elif dataset_name == 'dtd':
        train_dataset_full = torchvision.datasets.DTD(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'eurosat':
        train_dataset_full = torchvision.datasets.EuroSAT(root=data_root, download=True, transform=embedding_transform)
        # EuroSAT also doesn't have standard splits in the dataset object
        labels = np.array([label for _, label in train_dataset_full])
    elif dataset_name == 'fer2013':
        train_dataset_full = torchvision.datasets.FER2013(root=data_root, split='train', transform=embedding_transform) # download=True is default
        labels = np.array(train_dataset_full._labels) # Check attribute if this fails
    elif dataset_name == 'fgvc_aircraft':
        # FGVCAircraft uses 'train' split
        train_dataset_full = torchvision.datasets.FGVCAircraft(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'gtsrb':
        train_dataset_full = torchvision.datasets.GTSRB(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full._labels)
    elif dataset_name == 'pcam':
        # PCAM uses 'train' split
        train_dataset_full = torchvision.datasets.PCAM(root=data_root, split='train', download=True, transform=embedding_transform)
        labels = np.array([label for _, label in train_dataset_full._labels]) # Labels are tuples (center_tumor, node_id) - take first element
    elif dataset_name == 'semeion':
        train_dataset_full = torchvision.datasets.SEMEION(root=data_root, download=True, transform=embedding_transform)
        labels = train_dataset_full.labels # SEMEION uses .labels
    elif dataset_name == 'stanford_cars':
        train_dataset_full = torchvision.datasets.StanfordCars(root=data_root, split='train', download=True, transform=embedding_transform)
        # Labels seem to be stored differently or require iteration
        # labels = np.array(train_dataset_full._labels) # Check if this works
        labels = np.array([label for _, label in train_dataset_full]) # Safer fallback
    elif dataset_name == 'usps':
        train_dataset_full = torchvision.datasets.USPS(root=data_root, train=True, download=True, transform=embedding_transform)
        labels = np.array(train_dataset_full.targets)
    else: # Should not happen due to initial check
         raise ValueError(f"Dataset {dataset_name} logic error in get_cv_dataset.")

    if train_dataset_full is None or labels is None:
         print(f"Failed to load dataset {dataset_name}.")
         # Provide more specific error info if possible (e.g., attribute name)
         exit(1)
    # Ensure labels are numpy array of integers
    try:
        labels = np.array(labels, dtype=int)
    except ValueError:
        print(f"Warning: Could not convert labels for {dataset_name} to integers directly. Check label format.")
        # Attempt fallback if labels might be strings/tuples, e.g., PCAM node IDs or multi-label
        # This might need dataset-specific handling if complex labels arise
        if isinstance(labels[0], (tuple, list)):
             print("Labels appear to be tuples/lists, taking the first element.")
             labels = np.array([l[0] for l in labels], dtype=int)
        # Add more specific handlers if needed

    print(f"Loaded {dataset_name} training set with {len(train_dataset_full)} samples.")
    return train_dataset_full, labels

def load_sklearn_dataset(dataset_name, data_root):
    """Loads specified sklearn datasets and preprocesses them."""
    print(f"Attempting to load sklearn dataset: {dataset_name}")
    X = None
    y = None
    sklearn_data_home = os.path.join(data_root, 'sklearn_data') # Store sklearn downloads in subfolder
    os.makedirs(sklearn_data_home, exist_ok=True)

    if dataset_name == 'digits':
        digits = load_digits()
        X = digits.data # (n_samples, 64) pixel features
        y = digits.target
        dataset_type = 'image_raw'
    elif dataset_name == 'olivetti_faces':
        # Needs internet connection first time
        try:
            faces = fetch_olivetti_faces(data_home=sklearn_data_home, shuffle=True, random_state=42) # shuffle for potential subsampling later if needed
            X = faces.data # (n_samples, 4096) pixel features
            y = faces.target
            dataset_type = 'image_raw'
        except Exception as e:
            print(f"Error fetching Olivetti Faces (might require internet): {e}")
            return None, None, None # Indicate failure
    elif dataset_name == 'covertype':
        # Needs internet connection first time
        try:
            covtype = fetch_covtype(data_home=sklearn_data_home, download_if_missing=True)
            X = covtype.data # Tabular data
            y = covtype.target
            # Original labels are 1-7, map to 0-6 for consistency with 0-based indexing
            y = y - 1
            dataset_type = 'tabular'
        except Exception as e:
            print(f"Error fetching Covertype (might require internet): {e}")
            return None, None, None # Indicate failure
    else:
        raise ValueError(f"Unsupported sklearn dataset: {dataset_name}")

    if X is None or y is None:
        print(f"Failed to load data for sklearn dataset {dataset_name}")
        return None, None, None

    print(f"Loaded {dataset_name}: X shape {X.shape}, y shape {y.shape}")
    print(f"{dataset_name} label distribution: {np.bincount(y)}")

    # Preprocess: Apply StandardScaler to all features (pixels or tabular)
    print(f"Scaling features for {dataset_name}...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X.astype(np.float32)) # Use float32 for consistency/memory

    print(f"Using {X_scaled.shape[0]} samples for {dataset_name} metrics.")
    return X_scaled, y, dataset_type


def load_and_preprocess_spambase(data_path, seed=42): # Removed test_size
    """Loads and preprocesses Spambase dataset for complexity metrics."""
    # ...(rest of the spambase function remains the same as previous version)...
    # Ensure it uses the full dataset (no train/test split here)
    try:
        # Try finding the file in common locations
        if not os.path.exists(data_path):
             alt_path = os.path.join(DATA_ROOT, 'spambase', 'spambase.data') # common structure
             if os.path.exists(alt_path):
                 data_path = alt_path
             else:
                 # Attempt to download if not found (common for public datasets)
                 print(f"Spambase file not found at {data_path} or {alt_path}. Attempting to download...")
                 spambase_dir = os.path.join(DATA_ROOT, 'spambase')
                 os.makedirs(spambase_dir, exist_ok=True)
                 url = "https://archive.ics.uci.edu/ml/machine-learning-databases/spambase/spambase.data"
                 try:
                     import requests
                     print(f"Downloading from {url}...")
                     r = requests.get(url)
                     r.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
                     with open(alt_path, 'wb') as f:
                         f.write(r.content)
                     print(f"Successfully downloaded to {alt_path}")
                     data_path = alt_path
                 except ImportError:
                     print("Error: 'requests' library needed to download Spambase. Please install it (`pip install requests`) or download 'spambase.data' manually.")
                     exit(1)
                 except requests.exceptions.RequestException as e:
                     print(f"Error downloading Spambase: {e}")
                     print(f"Please download 'spambase.data' manually from UCI ML Repository and place it in '{spambase_dir}'.")
                     exit(1)


        # Spambase has no header, need to define column names or load without header
        col_names = [f'feat_{i}' for i in range(57)] + ['spam']
        try:
            data = pd.read_csv(data_path, header=None, names=col_names, na_values='?') # Check for potential missing markers
            print(f"Loaded Spambase data, shape: {data.shape}")
        except Exception as e:
             print(f"Error reading Spambase CSV at {data_path}: {e}")
             exit(1)

    except FileNotFoundError: # This catch might be redundant now due to download attempt, but keep for safety
        print(f"Error: Spambase dataset file not found and download failed/skipped. Please place 'spambase.data' in '{os.path.join(DATA_ROOT, 'spambase')}' directory.")
        exit(1)
    except Exception as e:
        print(f"Error loading or initially processing Spambase dataset: {e}")
        exit(1)

    if data.empty:
        print("Error: Loaded Spambase data is empty.")
        exit(1)
    if data.isnull().values.any():
        print("Warning: NaN values detected in Spambase data. Filling with column mean.")
        data.fillna(data.mean(), inplace=True) # Fill NaNs with mean

    X = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values.astype(int) # Ensure integer labels

    print(f"Spambase raw features shape: {X.shape}, labels shape: {y.shape}")
    print(f"Spambase label distribution: {np.bincount(y)}")

    # Using full dataset for metrics
    X_train = X
    y_train = y

    # Scale numerical features (all features in Spambase are numerical)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train.astype(np.float32))

    print(f"Using {X_train_scaled.shape[0]} training samples for Spambase metrics.")
    return X_train_scaled, y_train


def load_and_preprocess_adult(data_root, random_state=42): # Removed test_size
    """Loads and preprocesses Adult dataset using fairlearn for complexity metrics."""
    # ...(rest of the adult function remains the same as previous version)...
    # Ensure it uses the full dataset (no train/test split here)
    try:
        from fairlearn import datasets
    except ImportError:
        print("Error: fairlearn library is required for the Adult dataset. Please install it (`pip install fairlearn`).")
        exit(1)

    print("Loading Adult dataset using fairlearn...")
    try:
        # Fairlearn handles download to its cache or specified data_home
        # Specify data_home to keep downloads organized with other datasets
        fairlearn_data_home = os.path.join(data_root, 'fairlearn_data')
        adult_data = datasets.fetch_adult(as_frame=True, data_home=fairlearn_data_home)
        df_combined = adult_data.frame
        TARGET_FEATURE = 'income' # fairlearn uses 'income' now
        if TARGET_FEATURE not in df_combined.columns:
             # Try the older 'class' column name if 'income' isn't present
             if 'class' in df_combined.columns:
                 print("Warning: Target column 'income' not found, using 'class' instead.")
                 df_combined.rename(columns={'class': TARGET_FEATURE}, inplace=True)
             else:
                 raise ValueError(f"Target column '{TARGET_FEATURE}' or 'class' not found.")

        print("Adult dataset loaded successfully.")
    except Exception as e:
        print(f"Error loading Adult data using fairlearn: {e}. Ensure the dataset is downloaded (fairlearn should attempt this). Check '{fairlearn_data_home}' or the default fairlearn cache ('~/fairlearn-data').")
        exit(1)

    # Identify categorical and numerical features based on documentation/common knowledge
    NUMERICAL_FEATURES = ['age', 'fnlwgt', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week']
    CATEGORICAL_FEATURES = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country']

    # Ensure all expected columns exist
    missing_cols = [col for col in NUMERICAL_FEATURES + CATEGORICAL_FEATURES if col not in df_combined.columns]
    if missing_cols:
        print(f"Error: Missing expected columns in Adult dataset: {missing_cols}")
        exit(1)


    # Filter df to only include known features + target
    known_features = NUMERICAL_FEATURES + CATEGORICAL_FEATURES
    df_filtered = df_combined[known_features + [TARGET_FEATURE]].copy() # Work on a copy

    # Basic cleaning (Handle missing values represented by '?')
    df_filtered.replace(' ?', np.nan, inplace=True) # Note the space before '?' often present in raw data
    df_filtered.replace('?', np.nan, inplace=True) # Also check without space

    # Fill missing values
    for col in CATEGORICAL_FEATURES:
        # Convert to string first to ensure fillna works as expected
        df_filtered[col] = df_filtered[col].astype(str).fillna('Missing') # Fill NaN categorical with 'Missing'
    for col in NUMERICAL_FEATURES:
        df_filtered[col].fillna(df_filtered[col].median(), inplace=True) # Fill NaN numerical with median

    # Encode target variable ('>50K' vs '<=50K')
    # Fairlearn often loads target as >50K and <=50K strings
    positive_class_label = '>50K'
    # Check if the positive label needs adjustment (e.g., '>50K.' with a period)
    unique_targets = df_filtered[TARGET_FEATURE].unique()
    possible_pos_labels = ['>50K', '>50K.', ' >50K', ' >50K.'] # Add common variations
    found_pos_label = False
    for label_variation in possible_pos_labels:
        if label_variation in unique_targets:
            positive_class_label = label_variation
            print(f"Using '{positive_class_label}' as the positive class label.")
            found_pos_label = True
            break
    if not found_pos_label:
        print(f"Warning: Could not find standard positive class label among {unique_targets}. Assuming '{positive_class_label}' structure.")
        # Continue assuming '>50K', but it might lead to incorrect distribution if target format differs


    y = (df_filtered[TARGET_FEATURE] == positive_class_label).astype(int).values
    X = df_filtered[known_features]

    print(f"Adult raw features shape: {X.shape}, labels shape: {y.shape}")
    print(f"Adult label distribution: {np.bincount(y)}")

    # Using full dataset for metrics
    X_train = X
    y_train = y

    # Create preprocessor (StandardScaler for numerical, OneHotEncoder for categorical)
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), NUMERICAL_FEATURES),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False, dtype=np.float32), CATEGORICAL_FEATURES)
        ],
        remainder='drop' # Drop any columns not specified (shouldn't be any here)
    )

    # Fit preprocessor ONLY on training data and transform training data
    X_train_processed = preprocessor.fit_transform(X_train)

    print(f"Using {X_train_processed.shape[0]} training samples for Adult metrics.")
    # Return the processed training features and corresponding labels
    return X_train_processed, y_train


def get_speech_commands_dataset(data_root, target_length_samples):
    """Loads Google Speech Commands V2 dataset and preprocesses to Mel Spectrograms."""
    # ...(rest of the speech_commands function remains the same as previous version)...
    try:
        # Check if torchaudio backend is available
        import torchaudio.backend
        print(f"Torchaudio backend: {torchaudio.get_audio_backend()}")
    except Exception as e:
        print(f"Error initializing torchaudio: {e}")
        print("Ensure you have backend dependencies like 'soundfile' or 'sox' installed if needed.")
        exit(1)

    try:
        train_set_full = torchaudio.datasets.SPEECHCOMMANDS(root=data_root, subset="training", download=True)
    except Exception as e:
        print(f"Error loading Speech Commands dataset: {e}")
        print("Please ensure the dataset is downloaded correctly or can be downloaded.")
        exit(1)


    # Create a list of labels corresponding to the dataset iteration order
    all_labels_list = sorted(list(set(item[2] for item in train_set_full))) # Get all unique labels
    label_to_int = {label: i for i, label in enumerate(all_labels_list)}
    print(f"Speech Commands - Found {len(all_labels_list)} unique labels: {all_labels_list}")

    # Define Mel Spectrogram transform
    sample_rate = 16000 # Speech Commands is 16kHz
    n_fft = 400
    hop_length = 160
    n_mels = 64
    mel_spectrogram = T.MelSpectrogram(
        sample_rate=sample_rate,
        n_fft=n_fft,
        hop_length=hop_length,
        n_mels=n_mels,
        power=2.0 # Use power=2.0 for power spectrogram
    )
    log_mel_spectrogram = transforms.Compose([
        mel_spectrogram,
        T.AmplitudeToDB(stype='power', top_db=80) # Convert power spectrogram to dB scale
    ])


    processed_spectrograms = []
    processed_labels = []

    print(f"Processing Speech Commands training set ({len(train_set_full)} samples)...")
    for i, item in enumerate(tqdm(train_set_full)):
        # Unpack item carefully - structure can vary slightly or contain extra info
        waveform, sr, label = item[0], item[1], item[2]

        # Ensure correct sample rate (should be 16k)
        if sr != sample_rate:
            # Use torchaudio functional for resampling
            try:
                 waveform = torchaudio.functional.resample(waveform, sr, sample_rate)
            except Exception as resample_e:
                 print(f"Warning: Resampling failed for sample {i} (Label: {label}, SR: {sr}): {resample_e}. Skipping sample.")
                 continue


        # Pad or truncate waveform
        waveform_processed = pad_or_truncate(waveform, target_length_samples)

        # Apply Mel Spectrogram transform
        try:
             spec = log_mel_spectrogram(waveform_processed)
        except Exception as e:
             print(f"\nError processing sample {i} (Label: {label}, Shape: {waveform.shape}): {e}")
             # Skip this sample if transform fails
             continue

        # Flatten the spectrogram (N_mel x Time) -> (N_mel * Time)
        # Ensure tensor has correct shape before flatten (e.g., [1, n_mels, time])
        if spec.dim() == 3 and spec.shape[0] == 1: # Common case [1, n_mels, time]
             processed_spectrograms.append(spec.squeeze(0).flatten().numpy())
        elif spec.dim() == 2: # Case [n_mels, time]
             processed_spectrograms.append(spec.flatten().numpy())
        else:
             print(f"\nWarning: Unexpected spectrogram shape {spec.shape} for sample {i}. Skipping.")
             continue

        processed_labels.append(label_to_int[label])

    if not processed_spectrograms: # Check if list is empty after loop
        print("\nError: No speech samples were successfully processed. Check audio files and processing steps.")
        return None, None

    X_embed = np.array(processed_spectrograms, dtype=np.float32) # Use float32
    Y_labels = np.array(processed_labels, dtype=int)


    print(f"Processed {X_embed.shape[0]} speech samples into embeddings of dimension {X_embed.shape[1]}.")
    print(f"Speech label distribution: {np.bincount(Y_labels)}")
    return X_embed, Y_labels


# === Embedding Generation (CV specific) ===

def get_cv_embeddings(model, dataset, device):
    """Generates embeddings for CV datasets using the provided model."""
    # Adjust batch size based on available memory if needed
    # Start smaller for potentially larger/higher-res datasets
    batch_size = 32 if device.type == 'cuda' else 16
    # Allow overriding batch size via environment variable if needed
    batch_size = int(os.environ.get("CV_EMBED_BATCH_SIZE", batch_size))

    dataloader = None
    try:
        dataloader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, shuffle=False,
            num_workers=min(os.cpu_count() // 2, 4) if device.type == 'cuda' else 0, # Safer num_workers
            pin_memory=True if device.type == 'cuda' else False, # Pin memory only if CUDA is used
            persistent_workers= (True if device.type == 'cuda' and min(os.cpu_count() // 2, 4) > 0 else False) # Potentially faster loading
            )
    except Exception as dl_e:
         print(f"Error creating DataLoader: {dl_e}. Try reducing num_workers if it's related to multiprocessing.")
         # Fallback to num_workers=0
         dataloader = torch.utils.data.DataLoader(
            dataset, batch_size=batch_size, shuffle=False,
            num_workers=0, pin_memory=False)


    all_embeddings = []
    print(f"Generating CV embeddings using {device} with batch size {batch_size}...")
    model.eval() # Ensure model is in eval mode
    with torch.no_grad():
        for inputs, _ in tqdm(dataloader, desc="Embedding"): # We get labels separately earlier
            if inputs is None: # Should not happen with standard datasets, but safety check
                print("Warning: Encountered None input in DataLoader batch.")
                continue
            try:
                inputs = inputs.to(device)
                outputs = model(inputs)
                all_embeddings.append(outputs.cpu().numpy())
            except RuntimeError as e:
                 if "out of memory" in str(e).lower():
                     print(f"\nCUDA out of memory during embedding generation (batch size {batch_size}). "
                           "Try reducing batch size (e.g., export CV_EMBED_BATCH_SIZE=16) or image resolution.")
                     torch.cuda.empty_cache()
                     print("Exiting due to OOM error.")
                     return None # Indicate failure
                 else:
                     print(f"\nRuntimeError during batch processing: {e}")
                     # Option: Try skipping batch? Safer to stop.
                     return None # Indicate failure
            except Exception as e:
                print(f"\nError during batch processing in embedding generation: {e}")
                # Decide whether to skip batch or stop
                return None # Indicate failure

    if not all_embeddings: # Check if list is empty (e.g., OOM on first batch or other error)
        print("Error: No embeddings were generated.")
        return None

    try:
        concatenated_embeddings = np.concatenate(all_embeddings, axis=0).astype(np.float32) # Use float32
        print(f"Generated embeddings shape: {concatenated_embeddings.shape}")
        return concatenated_embeddings
    except Exception as concat_e:
        print(f"Error concatenating embeddings: {concat_e}")
        return None


# === Complexity Metrics Calculation ===

def calculate_metrics(X_embed, Y_labels, pca_threshold, k_neighbors, silhouette_sample_size):
    """Calculates all complexity metrics."""
    print("\nCalculating complexity metrics...")
    calculation_start_time = time.time()
    results = {}
    if X_embed is None or Y_labels is None:
        print("Error: Input embeddings or labels are None. Cannot calculate metrics.")
        return None

    n_samples = X_embed.shape[0]
    n_features = X_embed.shape[1]
    results['n_samples'] = n_samples
    results['n_features_raw'] = n_features

    # --- Basic Checks ---
    if n_samples == 0 or n_features == 0:
        print("Error: Embedding data is empty (0 samples or 0 features). Cannot calculate metrics.")
        return None
    if len(X_embed) != len(Y_labels):
         print(f"Error: Number of embeddings ({len(X_embed)}) does not match number of labels ({len(Y_labels)}).")
         return None
    # Check for NaN/Inf values in embeddings BEFORE scaling
    if np.isnan(X_embed).any() or np.isinf(X_embed).any():
        num_nan = np.isnan(X_embed).sum()
        num_inf = np.isinf(X_embed).sum()
        print(f"Error: Input embeddings contain {num_nan} NaN or {num_inf} Inf values. Cannot proceed.")
        # Optional: Try imputation? Safer to fix upstream or skip analysis.
        # Example: Impute with mean (use carefully!)
        # if np.isnan(X_embed).any():
        #     print("Attempting to impute NaN with column means...")
        #     col_mean = np.nanmean(X_embed, axis=0)
        #     inds = np.where(np.isnan(X_embed))
        #     X_embed[inds] = np.take(col_mean, inds[1])
        #     if np.isnan(X_embed).any(): # Check if imputation worked
        #          print("Imputation failed (e.g., all NaNs in a column). Cannot proceed.")
        #          return None
        # if np.isinf(X_embed).any(): # Handling Inf is harder, maybe replace with large number or mean?
        #      print("Error: Inf values still present after potential NaN imputation. Cannot proceed.")
        #      return None
        return None # Stop if NaN/Inf found

    # --- Metric Calculations ---
    metric_times = {} # Store time for each metric

    # 1. num_classes & label distribution stats
    start = time.time()
    print("Calculating num_classes & label stats...")
    try:
        unique_labels, counts_per_class = np.unique(Y_labels, return_counts=True)
        results['num_classes'] = len(unique_labels)
        results['min_samples_per_class'] = int(np.min(counts_per_class)) if len(counts_per_class) > 0 else 0
        results['max_samples_per_class'] = int(np.max(counts_per_class)) if len(counts_per_class) > 0 else 0
        results['avg_samples_per_class'] = float(np.mean(counts_per_class)) if len(counts_per_class) > 0 else 0.0
        results['median_samples_per_class'] = float(np.median(counts_per_class)) if len(counts_per_class) > 0 else 0.0
        print(f"  num_classes: {results['num_classes']}")
        print(f"  Samples per class: min={results['min_samples_per_class']}, max={results['max_samples_per_class']}, avg={results['avg_samples_per_class']:.2f}, median={results['median_samples_per_class']:.2f}")
        if results['num_classes'] < 1:
             print("Error: No classes found in labels.")
             return None # Cannot proceed
        if results['num_classes'] < 2:
             print("Warning: Only found 1 class. Some metrics might not be meaningful.")
        metric_times['class_stats'] = time.time() - start
    except Exception as e:
        print(f"  Error calculating class stats: {e}")
        return None # Critical failure

    # 2. label_entropy
    start = time.time()
    print("Calculating label_entropy...")
    if results['num_classes'] > 0 and len(counts_per_class) > 0:
        # Ensure counts sum to n_samples (can fail if labels have issues)
        if counts_per_class.sum() != n_samples:
            print(f"Warning: Sum of counts ({counts_per_class.sum()}) != n_samples ({n_samples}). Check labels.")
        results['label_entropy'] = entropy(counts_per_class, base=2)
        print(f"  label_entropy: {results['label_entropy']:.4f}")
    else:
        results['label_entropy'] = None # Should not happen if class_stats passed
    metric_times['label_entropy'] = time.time() - start


    # --- Metrics requiring embeddings ---

    # Use a shared scaled version for PCA, Intra/Inter, NN if possible to save computation
    # But scale locally within each metric calculation for robustness if one fails
    X_scaled_shared = None
    try:
        print("Scaling data for subsequent metrics (PCA, distances, NN)...")
        scaler_shared = StandardScaler()
        X_scaled_shared = scaler_shared.fit_transform(X_embed) # Uses float64 by default
        # Check for issues after scaling
        if np.isnan(X_scaled_shared).any() or np.isinf(X_scaled_shared).any():
             print("Error: NaN/Inf values detected after scaling. Check input data for extreme values or zero variance features.")
             X_scaled_shared = None # Invalidate shared scaled data
             # Fallback: try scaling with float32? Might help with overflow but lose precision
             # print("Trying scaling with float32...")
             # X_scaled_shared = scaler_shared.fit_transform(X_embed.astype(np.float32))
             # if np.isnan(X_scaled_shared).any() or np.isinf(X_scaled_shared).any():
             #      print("Error persists even with float32 scaling.")
             #      X_scaled_shared = None

    except ValueError as ve:
        # Often "Input contains NaN, infinity or a value too large for dtype('float64')."
        print(f"  ValueError during scaling: {ve}. May indicate issues in input data.")
        X_scaled_shared = None
    except MemoryError:
        print("  MemoryError during scaling. Dataset might be too large for in-memory scaling.")
        X_scaled_shared = None
    except Exception as e:
        print(f"  Unexpected error during scaling: {e}")
        X_scaled_shared = None

    # 3. effective_dim
    start = time.time()
    print("Calculating effective_dim...")
    results['effective_dim'] = None # Default to None
    X_pca_input = X_scaled_shared # Use shared scaled data if available
    if X_pca_input is None:
        print("  Scaling failed previously, attempting local scaling for PCA (float32)...")
        try:
             scaler_pca = StandardScaler()
             X_pca_input = scaler_pca.fit_transform(X_embed.astype(np.float32))
             if np.isnan(X_pca_input).any() or np.isinf(X_pca_input).any():
                  print("  Local scaling for PCA also resulted in NaN/Inf. Skipping effective_dim.")
                  X_pca_input = None
        except Exception as e:
             print(f"  Local scaling attempt for PCA failed: {e}. Skipping effective_dim.")
             X_pca_input = None

    if X_pca_input is not None:
        try:
            print("  Fitting PCA...")
            n_components_limit = min(X_pca_input.shape)
            if X_pca_input.shape[0] < X_pca_input.shape[1]:
                 print(f"  Warning: n_samples ({X_pca_input.shape[0]}) < n_features ({X_pca_input.shape[1]}). PCA limited to {n_components_limit} components.")

            # Limit components if features > 5000 for performance, unless samples are fewer
            max_pca_comps = min(n_components_limit, 5000)
            if max_pca_comps < 1:
                print("  Not enough samples/features (min < 1) for PCA. Skipping.")
            else:
                # Use float32 for PCA input if memory is a concern (already done if local scaling used)
                pca = PCA(n_components=max_pca_comps, copy=False) # copy=False might save memory if input isn't needed after
                pca.fit(X_pca_input.astype(np.float32)) # Ensure float32 for fit
                cumulative_variance = np.cumsum(pca.explained_variance_ratio_)

                eff_dim_val = np.argmax(cumulative_variance >= pca_threshold) + 1
                if cumulative_variance[-1] < pca_threshold and len(cumulative_variance) > 0:
                    print(f"  Warning: PCA threshold {pca_threshold} not reached by {pca.n_components_} components. Max variance explained: {cumulative_variance[-1]:.4f}. Using all computed components.")
                    eff_dim_val = pca.n_components_
                elif len(cumulative_variance) == 0: # Should not happen if fit succeeds
                    print("  Warning: PCA explained variance calculation failed.")
                    eff_dim_val = None

                if eff_dim_val is not None:
                    results['effective_dim'] = int(eff_dim_val)
                    print(f"  effective_dim (at {pca_threshold*100}% variance): {results.get('effective_dim', 'N/A')}")

        except MemoryError:
            print("  MemoryError during PCA fitting. Consider reducing max_pca_comps or using IncrementalPCA/RandomizedPCA for very large datasets.")
        except Exception as e:
            print(f"  Error calculating effective_dim: {e}")
        finally:
            del X_pca_input # Free memory of potentially large scaled array
            if 'pca' in locals(): del pca # Delete PCA object

    metric_times['effective_dim'] = time.time() - start


    # 4. intra_class_var / inter_class_dist
    start = time.time()
    print("Calculating intra-class variance and inter-class distance...")
    results['intra_class_var_avg'] = None
    results['inter_class_dist_avg'] = None
    # Use original embeddings for distance calculations unless scaling is explicitly desired for this metric
    X_dist_input = X_embed.astype(np.float64) # Use float64 for precision in distances/centroids

    if results['num_classes'] < 2:
         print("  Skipping intra/inter class metrics (requires >= 2 classes).")
         results['intra_class_var_avg'] = 0.0 if results['num_classes'] == 1 else None
    else:
        intra_class_avg_dists = []
        class_centroids = {}
        try:
            # Calculate centroids and intra-class distances
            print("  Calculating centroids and intra-class distances...")
            # Check for sufficient samples per class for variance calculation
            if results.get('min_samples_per_class', 0) < 2:
                 print(f"  Warning: At least one class has < 2 samples (min={results.get('min_samples_per_class')}). Intra-class variance might be 0 or averaged over fewer classes.")

            for label in tqdm(unique_labels, desc="Intra/Inter Class"):
                class_indices = np.where(Y_labels == label)[0]
                class_embeddings = X_dist_input[class_indices]
                if len(class_embeddings) > 1:
                    centroid = np.mean(class_embeddings, axis=0)
                    class_centroids[label] = centroid
                    # Euclidean distance calculation can be memory intensive if done naively pairwise.
                    # Distance to centroid is more efficient.
                    distances = [euclidean(emb, centroid) for emb in class_embeddings]
                    intra_class_avg_dists.append(np.mean(distances))
                elif len(class_embeddings) == 1:
                    class_centroids[label] = class_embeddings[0]
                    intra_class_avg_dists.append(0.0) # Single point class

            # Calculate average intra-class variance
            valid_intra_dists = [d for d in intra_class_avg_dists if d is not None]
            if valid_intra_dists:
                 results['intra_class_var_avg'] = float(np.mean(valid_intra_dists))
                 print(f"  intra_class_var_avg: {results['intra_class_var_avg']:.4f}")
            else:
                 print("  Warning: Could not calculate any valid intra-class distances.")


            # Calculate average inter-class distance (between centroids)
            print("  Calculating inter-class distances...")
            inter_class_distances = []
            centroid_items = list(class_centroids.items())
            if len(centroid_items) > 1:
                for i in range(len(centroid_items)):
                    for j in range(i + 1, len(centroid_items)):
                        label1, centroid1 = centroid_items[i]
                        label2, centroid2 = centroid_items[j]
                        dist = euclidean(centroid1, centroid2)
                        inter_class_distances.append(dist)

                if inter_class_distances:
                    results['inter_class_dist_avg'] = float(np.mean(inter_class_distances))
                    print(f"  inter_class_dist_avg: {results['inter_class_dist_avg']:.4f}")
                else:
                    print("  Warning: Could not calculate any inter-class distances.")

        except MemoryError:
            print("  MemoryError calculating intra/inter class metrics (possibly during centroid storage or distance calculation).")
        except Exception as e:
            print(f"  Error calculating intra/inter class metrics: {e}")
        finally:
            del X_dist_input, class_centroids, intra_class_avg_dists, inter_class_distances # Free memory

    metric_times['intra_inter_dist'] = time.time() - start


    # 5. local_consistency
    start = time.time()
    print(f"Calculating local_consistency (k={k_neighbors})...")
    results['local_consistency'] = None
    # Use float32 for NN fit/query for efficiency/memory
    X_nn_input = X_embed.astype(np.float32)

    try:
        actual_k = min(k_neighbors, n_samples - 1)
        if actual_k < 1:
             print(f"  Skipping local_consistency (not enough samples ({n_samples}) for k={k_neighbors}).")
        elif results.get('num_classes', 0) < 2:
             print("  Skipping local_consistency (only 1 class). Consistency is trivially 1.0.")
             # results['local_consistency'] = 1.0 # Or keep as None? Let's keep None for consistency.
        else:
            print(f"  Fitting NearestNeighbors (k={actual_k})...")
            # Consider algorithm='kd_tree' or 'ball_tree' if 'auto' is slow or memory hungry, depends on data dim
            nn = NearestNeighbors(n_neighbors=actual_k + 1, metric='euclidean', n_jobs=-1, algorithm='auto')
            nn.fit(X_nn_input)

            print("  Querying neighbors and calculating consistency...")
            # Process in batches if memory is an issue for querying or storing indices
            batch_size_nn = 10000 # Adjust based on memory
            consistent_neighbor_ratios = []
            for i in tqdm(range(0, n_samples, batch_size_nn), desc="Local Consistency Batches"):
                batch_indices_nn = range(i, min(i + batch_size_nn, n_samples))
                # Query neighbors for the batch, exclude self ([:, 1:])
                indices = nn.kneighbors(X_nn_input[batch_indices_nn], return_distance=False)[:, 1:]

                batch_labels = Y_labels[batch_indices_nn]
                # Iterate through the batch results
                for j in range(len(batch_indices_nn)): # j is index within batch
                    neighbor_indices = indices[j]
                    neighbor_labels = Y_labels[neighbor_indices]
                    # Consistency for sample batch_indices_nn[j]
                    consistency = np.mean(neighbor_labels == batch_labels[j])
                    consistent_neighbor_ratios.append(consistency)

            if consistent_neighbor_ratios:
                 results['local_consistency'] = float(np.mean(consistent_neighbor_ratios))
                 print(f"  local_consistency: {results['local_consistency']:.4f}")
            else:
                 print("  Warning: Failed to calculate local consistency ratios.")


    except MemoryError:
         print("  MemoryError during Nearest Neighbors fit, query, or calculation. Try reducing k or using batch processing if not already.")
    except Exception as e:
        print(f"  Error calculating local_consistency: {e}")
    finally:
        del X_nn_input
        if 'nn' in locals(): del nn # Delete NN object

    metric_times['local_consistency'] = time.time() - start


    # 6. separability_score (Silhouette Score)
    start = time.time()
    print("Calculating separability_score (Silhouette Score)...")
    results['separability_score'] = None
    # Check requirements again
    if results['num_classes'] < 2:
         print("  Skipping separability_score (requires >= 2 classes).")
    elif results.get('min_samples_per_class', 0) < 2:
         print(f"  Skipping separability_score (at least one class has < 2 samples, min={results.get('min_samples_per_class')}).")
    # No heuristic n_samples check here, rely on min_samples_per_class which is more direct
    else:
        print(f"  WARNING: Silhouette score calculation can be slow and memory-intensive (using max {silhouette_sample_size} samples).")
        X_sil_input = X_embed.astype(np.float32) # Use float32 for efficiency
        Y_sil_labels = Y_labels

        # Subsample if dataset is too large
        if n_samples > silhouette_sample_size:
            print(f"  Subsampling to {silhouette_sample_size} samples for silhouette calculation.")
            # Stratified sampling is preferred if scikit-learn is available and classes are imbalanced
            try:
                # Attempt stratified sampling
                sss = train_test_split(X_sil_input, Y_sil_labels,
                                       train_size=silhouette_sample_size, # Use train_size for target count
                                       stratify=Y_sil_labels, random_state=42, shuffle=True)
                X_work = sss[0] # X_train from split
                Y_work = sss[2] # y_train from split

                # Check if subsampling was successful and maintained requirements
                unique_sub, counts_sub = np.unique(Y_work, return_counts=True)
                if len(unique_sub) < 2 or (len(counts_sub) > 0 and np.min(counts_sub) < 2):
                      print(f"  Subsampled data has < 2 classes or < 2 samples in a class ({len(unique_sub)} classes, min samples={np.min(counts_sub) if len(counts_sub) > 0 else 'N/A'}). Trying random sampling fallback.")
                      # Fallback to simple random sampling
                      indices_subset = np.random.choice(n_samples, silhouette_sample_size, replace=False)
                      X_work = X_sil_input[indices_subset]
                      Y_work = Y_sil_labels[indices_subset]
                      unique_sub_rand, counts_sub_rand = np.unique(Y_work, return_counts=True)
                      if len(unique_sub_rand) < 2 or (len(counts_sub_rand) > 0 and np.min(counts_sub_rand) < 2):
                          print("  Random sampling also failed to meet Silhouette criteria. Skipping.")
                          X_work = None # Skip calculation
                print(f"  Using {len(X_work)} stratified samples.")

            except ValueError as ve:
                 print(f"  Error during stratified subsampling (e.g., sample size > smallest class size): {ve}. Trying random sampling.")
                 try:
                    indices_subset = np.random.choice(n_samples, silhouette_sample_size, replace=False)
                    X_work = X_sil_input[indices_subset]
                    Y_work = Y_sil_labels[indices_subset]
                    unique_sub_rand, counts_sub_rand = np.unique(Y_work, return_counts=True)
                    if len(unique_sub_rand) < 2 or (len(counts_sub_rand) > 0 and np.min(counts_sub_rand) < 2):
                          print("  Random sampling also failed to meet Silhouette criteria. Skipping.")
                          X_work = None # Skip calculation
                    else:
                         print(f"  Using {len(X_work)} randomly sampled samples.")
                 except Exception as rand_e:
                    print(f"  Error during random sampling fallback: {rand_e}. Skipping silhouette.")
                    X_work = None
            except Exception as e:
                 print(f"  Unexpected error during subsampling: {e}. Skipping silhouette.")
                 X_work = None
        else:
            # Use full dataset if small enough
            X_work = X_sil_input
            Y_work = Y_sil_labels
            print(f"  Using full dataset ({n_samples} samples) for silhouette calculation.")


        if X_work is not None and Y_work is not None:
            try:
                print(f"  Calculating silhouette score on {X_work.shape[0]} samples (dim={X_work.shape[1]})...")
                # Use metric='euclidean' by default, adjust if needed
                # random_state for potential internal sampling if metric needs it
                score = silhouette_score(X_work, Y_work, metric='euclidean', sample_size=None, random_state=42)
                results['separability_score'] = float(score)
                print(f"  separability_score: {results['separability_score']:.4f}")
            except MemoryError:
                print("  MemoryError calculating silhouette score. Consider reducing silhouette_sample_size.")
            except ValueError as ve:
                 # Common issue: "Number of labels is invalid." -> needs >= 2 labels. Should be caught above.
                 print(f"  ValueError calculating silhouette score: {ve}. Check data validity and class distribution in the sample used.")
            except Exception as e:
                print(f"  Error calculating silhouette score: {e}")
            finally:
                del X_work, Y_work # Free memory

    metric_times['separability_score'] = time.time() - start


    # --- Finalization ---
    total_calculation_time = time.time() - calculation_start_time
    print(f"\nMetrics calculation finished in {total_calculation_time:.2f} seconds.")
    results['calculation_times'] = {k: round(v, 2) for k, v in metric_times.items()} # Store rounded times

    # Final check for NaN/Inf in results (should not happen if metrics return numbers)
    for k, v in results.items():
        if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
             print(f"Warning: Metric '{k}' resulted in NaN or Inf. Setting to None.")
             results[k] = None

    return results


# === Main Execution ===

if __name__ == "__main__":
    start_time = time.time()
    parser = argparse.ArgumentParser(description="Calculate complexity metrics for various datasets.")
    # Combine all dataset choices
    all_dataset_choices = [
        # Original + First Addition CV
        'cifar10', 'mnist', 'fashionmnist', 'svhn', 'cifar100', 'stl10',
        'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'kmnist',
        # New torchvision CV
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft', 'gtsrb',
        'pcam', 'semeion', 'stanford_cars', 'usps',
        # Sklearn datasets
        'digits', 'olivetti_faces', 'covertype',
        # Non-CV / Other
        'spambase', 'adult', 'speech_commands'
    ]
    parser.add_argument('-dataset', type=str, required=True,
                        choices=sorted(all_dataset_choices), # Keep choices sorted
                        help='Name of the dataset to process.')
    args = parser.parse_args()
    dataset_name = args.dataset

    print(f"--- Processing dataset: {dataset_name} ---")

    X_embed = None
    Y_labels = None
    dataset_info = {'name': dataset_name, 'load_time': None, 'embedding_time': None}

    # Define dataset categories for easier logic
    torchvision_cv_datasets = [
        'cifar10', 'mnist', 'fashionmnist', 'svhn', 'cifar100', 'stl10',
        'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'kmnist',
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft', 'gtsrb',
        'pcam', 'semeion', 'stanford_cars', 'usps'
    ]
    sklearn_datasets = ['digits', 'olivetti_faces', 'covertype']
    other_tabular_datasets = ['spambase', 'adult']
    audio_datasets = ['speech_commands']


    # --- Load Data and Prepare Embeddings/Features ---
    load_start_time = time.time()

    if dataset_name in torchvision_cv_datasets:
        dataset_info['type'] = 'cv_torchvision'
        # Load CV dataset
        cv_dataset, Y_labels = get_cv_dataset(dataset_name, DATA_ROOT)
        if cv_dataset is None or Y_labels is None:
            print(f"Exiting due to dataset loading failure for {dataset_name}.")
            exit(1)
        dataset_info['raw_samples'] = len(cv_dataset)
        dataset_info['raw_labels_count'] = len(np.unique(Y_labels)) if Y_labels is not None else 0
        dataset_info['load_time'] = time.time() - load_start_time

        # Load CV embedding model
        print(f"\nLoading pre-trained {EMBEDDING_MODEL_NAME_CV} model for CV embeddings...")
        embedding_start_time = time.time()
        try:
             weights = models.ResNet50_Weights.IMAGENET1K_V2
             embedding_model = models.resnet50(weights=weights)
             embedding_model.fc = torch.nn.Identity() # Remove classifier
             embedding_model = embedding_model.to(device)
             embedding_model.eval()
        except Exception as e:
             print(f"Error loading model {EMBEDDING_MODEL_NAME_CV}: {e}")
             exit(1)

        # Generate embeddings
        X_embed = get_cv_embeddings(embedding_model, cv_dataset, device)
        dataset_info['embedding_time'] = time.time() - embedding_start_time
        del embedding_model, cv_dataset # Free memory
        torch.cuda.empty_cache() if device.type == 'cuda' else None
        if X_embed is None:
            print(f"Exiting due to embedding generation failure for {dataset_name}.")
            exit(1)

    elif dataset_name in sklearn_datasets:
        # Load sklearn dataset (handles scaling internally)
        X_embed, Y_labels, dataset_type = load_sklearn_dataset(dataset_name, DATA_ROOT)
        dataset_info['type'] = f'sklearn_{dataset_type}' # e.g., sklearn_image_raw, sklearn_tabular
        if X_embed is None or Y_labels is None:
            print(f"Exiting due to dataset loading failure for {dataset_name}.")
            exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time
        # No separate embedding step for these, features are used directly

    elif dataset_name == 'spambase':
        dataset_info['type'] = 'tabular_spambase'
        spambase_path = os.path.join(DATA_ROOT, 'spambase', 'spambase.data')
        X_embed, Y_labels = load_and_preprocess_spambase(spambase_path)
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time

    elif dataset_name == 'adult':
        dataset_info['type'] = 'tabular_adult'
        X_embed, Y_labels = load_and_preprocess_adult(DATA_ROOT)
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0]
        dataset_info['load_time'] = time.time() - load_start_time

    elif dataset_name == 'speech_commands':
        dataset_info['type'] = 'audio_speechcommands'
        X_embed, Y_labels = get_speech_commands_dataset(DATA_ROOT, SPEECH_TARGET_LENGTH_SAMPLES)
        if X_embed is None or Y_labels is None: exit(1)
        dataset_info['raw_samples'] = X_embed.shape[0] # This is samples *after* processing
        dataset_info['load_time'] = time.time() - load_start_time # Includes processing time here

    else: # Should not be reached due to argparse choices
        raise ValueError(f"Dataset name '{dataset_name}' not handled in main execution block.")


    # --- Calculate Metrics ---
    if X_embed is not None and Y_labels is not None:
        # Add embedding dim info if not already present (e.g., for non-CV)
        if 'embedding_dim' not in dataset_info:
             dataset_info['embedding_dim'] = X_embed.shape[1]
        if 'num_samples_processed' not in dataset_info:
             dataset_info['num_samples_processed'] = X_embed.shape[0]

        metrics = calculate_metrics(X_embed, Y_labels, PCA_VARIANCE_THRESHOLD, K_NEIGHBORS, SILHOUETTE_SAMPLE_SIZE)

        if metrics:
            # --- Save Results ---
            print("\nSaving results...")
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, f"{dataset_name}_complexity_metrics.json")

            # Combine dataset info and metrics
            full_results = dataset_info.copy()
            # Round time values
            for time_key in ['load_time', 'embedding_time']:
                if full_results.get(time_key) is not None:
                    full_results[time_key] = round(full_results[time_key], 2)

            # Add calculated metrics under a sub-key, ensuring JSON serializability
            full_results['complexity_metrics'] = {}
            metric_calculation_times = metrics.pop('calculation_times', {}) # Extract calc times

            for k, v in metrics.items():
                if v is None:
                    full_results['complexity_metrics'][k] = None
                elif isinstance(v, (np.generic, np.number)): # Handles numpy int/float types
                    # Check for potential numpy bool type too
                    if isinstance(v, np.bool_):
                        full_results['complexity_metrics'][k] = bool(v)
                    else:
                         # Convert potential Inf/-Inf to strings, keep NaN as None (json standard usually handles NaN as null)
                         if np.isinf(v):
                             full_results['complexity_metrics'][k] = str(v) # "inf" or "-inf"
                         elif np.isnan(v):
                              full_results['complexity_metrics'][k] = None
                         else:
                              full_results['complexity_metrics'][k] = v.item() # Convert to standard Python type
                elif isinstance(v, (float, int, bool, str)):
                     # Check for Python float Inf/NaN
                     if isinstance(v, float) and (np.isinf(v) or np.isnan(v)):
                         full_results['complexity_metrics'][k] = str(v) if np.isinf(v) else None
                     else:
                         full_results['complexity_metrics'][k] = v # Already JSON serializable
                elif isinstance(v, (list, dict)):
                    full_results['complexity_metrics'][k] = v # Assume list/dict contents are serializable
                else:
                    print(f"Warning: Metric '{k}' has unserializable type {type(v)}. Converting to string.")
                    full_results['complexity_metrics'][k] = str(v)

            # Add calculation times separately
            full_results['metric_calculation_times_sec'] = metric_calculation_times

            try:
                with open(output_path, 'w') as f:
                    # Use allow_nan=False to ensure standard JSON (NaN becomes null)
                    json.dump(full_results, f, indent=4, allow_nan=False)
                print(f"Results saved to {output_path}")
                print("\n--- Final Calculated Metrics Summary ---")
                print(json.dumps(full_results['complexity_metrics'], indent=4))
            except TypeError as json_err:
                 print(f"\nError saving results to JSON: {json_err}")
                 print("Problematic data:", full_results)

        else:
            print("Metrics calculation failed or returned no results.")
    else:
        print("Failed to load data or generate embeddings. Cannot calculate metrics.")

    end_time = time.time()
    print(f"\n--- Finished processing {dataset_name} in {end_time - start_time:.2f} seconds ---")