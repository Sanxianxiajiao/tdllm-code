# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset, Dataset # Added Dataset
import torchvision.models as models
import torchaudio # Added
import torchaudio.transforms as T # Added

import os
import argparse
import json
import random
import numpy as np
import time
from tqdm import tqdm
import warnings
import pandas as pd # Added
from sklearn.preprocessing import StandardScaler, OneHotEncoder # Added
from sklearn.compose import ColumnTransformer # Added
from sklearn.model_selection import train_test_split # Added
from sklearn.datasets import load_digits, fetch_olivetti_faces, fetch_covtype # Added
import math # Added for ceiling in sampling

# Ignore specific warnings
warnings.filterwarnings("ignore", category=UserWarning, module='torchvision')
warnings.filterwarnings("ignore", category=UserWarning, module='torchaudio')
warnings.filterwarnings("ignore", category=FutureWarning)

# --- Configuration Constants ---
DATA_ROOT = './data'
RESULTS_BASE_DIR = './results' # Define base results directory

# === Custom Dataset for Numpy Arrays ===
class NumpyDataset(Dataset):
    """Dataset wrapping numpy arrays or tensors"""
    def __init__(self, data, targets, transform=None):
        # Convert numpy arrays to torch tensors if they aren't already
        if isinstance(data, np.ndarray):
            # Detect if data is image-like (needs channel dimension) or feature vector
            if data.ndim == 3: # Assume (N, H, W) -> Add channel dim (N, 1, H, W) for grayscale
                 data = torch.from_numpy(data).unsqueeze(1).float()
            elif data.ndim == 4: # Assume (N, H, W, C) -> Permute to (N, C, H, W)
                 data = torch.from_numpy(data).permute(0, 3, 1, 2).float()
            elif data.ndim == 2: # Assume (N, Features)
                 data = torch.from_numpy(data).float()
            else:
                 raise ValueError(f"Unsupported numpy data dimensions: {data.ndim}")
        elif not isinstance(data, torch.Tensor):
             raise TypeError(f"Data must be a numpy array or torch Tensor, got {type(data)}")

        if isinstance(targets, np.ndarray):
             targets = torch.from_numpy(targets).long() # Use long for CrossEntropyLoss
        elif not isinstance(targets, torch.Tensor):
             raise TypeError(f"Targets must be a numpy array or torch Tensor, got {type(targets)}")
        elif targets.dtype != torch.long:
             targets = targets.long() # Ensure long type

        self.data = data
        self.targets = targets
        self.transform = transform

    def __len__(self):
        return len(self.targets)

    def __getitem__(self, index):
        x = self.data[index]
        y = self.targets[index]

        # Apply transformations if any (useful for image-based numpy datasets)
        # Note: Tabular/Audio Spectrogram transforms usually applied *before* creating dataset
        if self.transform:
            # Ensure tensor is in a format transform expects (e.g., PIL Image or Tensor)
            # If data is already tensor, many torchvision transforms work directly
            x = self.transform(x)

        return x, y

# --- Model Definitions ---

# SimpleCNN (Modified as before)
class SimpleCNN(nn.Module):
    def __init__(self, input_channels=3, image_size=32, num_classes=10):
        super(SimpleCNN, self).__init__()
        # Handle potential non-integer image_size after pooling
        if image_size is None or image_size < 4:
             print(f"Warning: SimpleCNN received image_size={image_size}. Using default fallback size 32x32 for FC layer calculation.")
             image_size = 32 # Or another sensible default / error

        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1)
        # Calculate flattened size dynamically
        feature_size = image_size // 4
        if feature_size <= 0:
             # Handle cases where image_size // 4 is 0 (e.g., image_size=3)
             # Option 1: Raise error
             # raise ValueError(f"Image size {image_size} too small for 2 pooling layers in SimpleCNN")
             # Option 2: Use a minimum feature size (e.g., 1x1)
             print(f"Warning: Calculated feature_size {feature_size} is too small. Using 1x1.")
             feature_size = 1
        self.fc1_input_features = 32 * feature_size * feature_size
        self.fc1 = nn.Linear(self.fc1_input_features, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        # Ensure flatten operation matches calculated features
        x = x.view(-1, self.fc1_input_features)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# SimpleMLP (Modified as before, adapted for flat features)
class SimpleMLP(nn.Module):
    def __init__(self, input_features, num_classes=10): # Changed input signature
        super(SimpleMLP, self).__init__()
        self.fc1 = nn.Linear(input_features, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_classes)
        # No need for flatten if input is already flat

    def forward(self, x):
        # If input has spatial dimensions (e.g., from CNN mistakenly fed), flatten it
        if x.dim() > 2:
            x = torch.flatten(x, start_dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# --- Helper Functions ---

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        # Keep deterministic setting for reproducibility if desired
        # torch.backends.cudnn.deterministic = True
        # torch.backends.cudnn.benchmark = False
        # Or enable benchmark mode for potentially faster training if input sizes don't vary much
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.deterministic = False


# Modified get_model to accept dataset characteristics
def get_model(model_name, num_classes=10, input_channels=3, image_size=32, input_features=None):
    """Loads the specified model, adapting for dataset specifics."""
    print(f"Attempting to load model: {model_name} with num_classes={num_classes}, input_channels={input_channels}, image_size={image_size}, input_features={input_features}")
    if model_name.startswith('resnet'): # Handle ResNet18, ResNet50 etc.
        if 'resnet18' in model_name:
            try:
                weights = models.ResNet18_Weights.DEFAULT # Use default weights if available for pretraining potential (even if fine-tuning from scratch now)
                model = models.resnet18(weights=weights)
            except AttributeError: # Older torchvision might not have weights enum
                 print("ResNet18_Weights.DEFAULT not found, using weights=None.")
                 model = models.resnet18(weights=None) # Train from scratch
            base_name = 'resnet18'
        elif 'resnet50' in model_name:
            try:
                 weights = models.ResNet50_Weights.DEFAULT
                 model = models.resnet50(weights=weights)
            except AttributeError:
                 print("ResNet50_Weights.DEFAULT not found, using weights=None.")
                 model = models.resnet50(weights=None) # Train from scratch
            base_name = 'resnet50'
        else:
             raise ValueError(f"Unsupported ResNet variant: {model_name}")

        # --- Replace layers AFTER loading potentially pretrained weights ---
        # Modify input layer if needed (e.g., for grayscale)
        if input_channels == 1:
            print(f"Modifying {base_name} input layer for 1 channel.")
            # Get original weights and bias if exists
            original_weights = model.conv1.weight.data
            original_bias = model.conv1.bias.data if model.conv1.bias is not None else None

            # Create new conv layer
            new_conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=(original_bias is not None))

            # Adapt weights (e.g., average or sum channels)
            new_conv1.weight.data = original_weights.mean(dim=1, keepdim=True) # Mean is often preferred over sum

            if original_bias is not None:
                new_conv1.bias.data = original_bias # Keep original bias

            model.conv1 = new_conv1 # Replace the layer

        elif input_channels != 3:
             print(f"Warning: {base_name} expects 3 input channels, but got {input_channels}. Keeping original conv1 (expecting 3 channels). Ensure data matches or adapt the model further.")
             # If you need arbitrary channels, you'd replace conv1 similarly but without weight adaptation logic

        # Modify final layer for num_classes
        num_ftrs = model.fc.in_features
        model.fc = nn.Linear(num_ftrs, num_classes) # Replace the final layer
        print(f"Modified {base_name} final layer for {num_classes} classes.")

    elif model_name == 'simple_cnn':
        if input_channels is None or image_size is None:
             raise ValueError("SimpleCNN requires input_channels and image_size.")
        model = SimpleCNN(input_channels=input_channels, image_size=image_size, num_classes=num_classes)

    elif model_name == 'mlp':
        if input_features is None:
            # Try to infer from image size if it's image data
            if input_channels is not None and image_size is not None:
                 print("MLP input_features not provided, inferring from image dimensions.")
                 input_features = input_channels * image_size * image_size
            else:
                 raise ValueError("MLP requires input_features (or input_channels and image_size for image data).")
        model = SimpleMLP(input_features=input_features, num_classes=num_classes)
    else:
        raise ValueError(f"Unknown model name: {model_name}")
    return model


# === Dataset Loading Logic (Adapted from calculate_metrics.py) ===

# --- Replicated/Adapted Helper Functions ---

def pad_or_truncate(waveform, target_length):
    """Pads or truncates a waveform tensor to a target length."""
    length = waveform.shape[-1]
    if length < target_length:
        padding = target_length - length
        waveform = F.pad(waveform, (0, padding))
    elif length > target_length:
        waveform = waveform[..., :target_length]
    return waveform

# Replicate necessary parts of loading functions if not importing them
# (Example for Adult - assuming it's needed)
def load_and_preprocess_adult_train(data_root):
    # (Keep the existing load_and_preprocess_adult_train function here)
    print("Loading and preprocessing Adult dataset for training...")
    try:
        from fairlearn import datasets
    except ImportError:
        print("Error: fairlearn library is required for the Adult dataset. Please install it (`pip install fairlearn`).")
        return None, None, None, None, None, None

    fairlearn_data_home = os.path.join(data_root, 'fairlearn_data')
    try:
        # Specify cache_dir directly if needed, otherwise uses fairlearn default
        adult_data = datasets.fetch_adult(as_frame=True, data_home=fairlearn_data_home)
        df = adult_data.data
        y = adult_data.target
        print("Adult dataset loaded via fairlearn.")
        print(f"Features shape: {df.shape}, Target shape: {y.shape}")
    except FileNotFoundError:
         print(f"Error: Adult data not found. Fairlearn download might have failed. Check '{fairlearn_data_home}' or run the complexity script first.")
         return None, None, None, None, None, None
    except Exception as e:
        print(f"Error loading Adult data using fairlearn: {e}")
        return None, None, None, None, None, None

    NUMERICAL_FEATURES = ['age', 'fnlwgt', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week']
    CATEGORICAL_FEATURES = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country']
    known_features = NUMERICAL_FEATURES + CATEGORICAL_FEATURES

    missing_cols = [col for col in known_features if col not in df.columns]
    if missing_cols:
        print(f"Error: Missing expected columns in Adult data: {missing_cols}")
        return None, None, None, None, None, None

    X = df[known_features].copy()
    X.replace([' ?', '?'], np.nan, inplace=True)

    # Impute missing values - Fit on train only later if splitting first
    for col in CATEGORICAL_FEATURES:
        X[col] = X[col].astype(str).fillna('Missing') # Impute with 'Missing'
    for col in NUMERICAL_FEATURES:
        X[col].fillna(X[col].median(), inplace=True) # Impute with median

    # Encode target
    y_processed = (y == '>50K').astype(int)
    num_classes = 2

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_processed, test_size=0.2, random_state=42, stratify=y_processed
    )

    # Create preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), NUMERICAL_FEATURES),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False, dtype=np.float32), CATEGORICAL_FEATURES)
        ],
        remainder='drop' # Drop features not specified (shouldn't happen here)
    )

    print("Fitting preprocessor on training data and transforming train/test...")
    # Fit *only* on training data
    preprocessor.fit(X_train)
    # Transform train and test data
    X_train_processed = preprocessor.transform(X_train)
    X_test_processed = preprocessor.transform(X_test)

    feature_dim = X_train_processed.shape[1]

    print(f"Adult features processed. Train shape: {X_train_processed.shape}, Test shape: {X_test_processed.shape}")
    return X_train_processed, y_train.values, X_test_processed, y_test.values, feature_dim, num_classes


# Simplified Spambase loader for training
def load_and_preprocess_spambase_train(data_root):
    # (Keep the existing load_and_preprocess_spambase_train function here)
    print("Loading and preprocessing Spambase dataset for training...")
    data_path = os.path.join(data_root, 'spambase', 'spambase.data')
    # Add download logic if needed (similar to calculate_metrics.py)
    if not os.path.exists(data_path):
        alt_path = os.path.join(DATA_ROOT, 'spambase', 'spambase.data') # common structure
        if os.path.exists(alt_path):
            data_path = alt_path
        else:
             # Attempt download
             print(f"Spambase file not found at {data_path} or {alt_path}. Attempting download...")
             spambase_dir = os.path.dirname(alt_path)
             os.makedirs(spambase_dir, exist_ok=True)
             url = "https://archive.ics.uci.edu/ml/machine-learning-databases/spambase/spambase.data"
             try:
                 import requests
                 print(f"Downloading from {url}...")
                 r = requests.get(url, timeout=30) # Add timeout
                 r.raise_for_status()
                 with open(alt_path, 'wb') as f:
                     f.write(r.content)
                 print(f"Successfully downloaded to {alt_path}")
                 data_path = alt_path
             except ImportError:
                 print("Error: 'requests' library needed to download Spambase. Install with `pip install requests` or download manually.")
                 return None, None, None, None, None, None
             except requests.exceptions.RequestException as e:
                 print(f"Error downloading Spambase: {e}")
                 print(f"Please download 'spambase.data' manually and place it in '{spambase_dir}'.")
                 return None, None, None, None, None, None

    col_names = [f'feat_{i}' for i in range(57)] + ['spam']
    try:
        data = pd.read_csv(data_path, header=None, names=col_names)
        if data.isnull().values.any():
             print("Warning: NaN values found in Spambase, filling with mean.")
             data.fillna(data.mean(), inplace=True)
    except Exception as e:
        print(f"Error reading Spambase CSV: {e}")
        return None, None, None, None, None, None

    X = data.iloc[:, :-1].values.astype(np.float32)
    y = data.iloc[:, -1].values.astype(int)
    num_classes = 2

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test) # Use transform only on test
    feature_dim = X_train_scaled.shape[1]

    print(f"Spambase features processed. Train shape: {X_train_scaled.shape}, Test shape: {X_test_scaled.shape}")
    return X_train_scaled, y_train, X_test_scaled, y_test, feature_dim, num_classes


# Unified Dataset Loading Function for Training
def get_datasets_for_training(dataset_name, data_root='./data', target_image_size=224):
    # (Keep the existing get_datasets_for_training function here - it already handles all datasets)
    # Minor fix: Ensure dataset class lookup handles lowercase names if needed
    # Minor fix: Ensure effective_image_size is properly determined in manual split fallback
    """Loads the specified dataset and returns train/test datasets, transforms, and properties for training."""
    print(f"Loading {dataset_name} dataset for training...")
    train_dataset_full = None # Initialize with _full suffix to clarify it's pre-subsetting
    test_dataset = None
    num_classes = None
    input_channels = None # Channels expected by the *model*
    effective_image_size = None # Image size *after* transforms
    input_features = None # For MLP with non-image data
    dataset_type = 'image' # Default to image

    # --- Define dataset lists ---
    torchvision_cv_datasets = [
        'cifar10', 'mnist', 'fashionmnist', 'svhn', 'cifar100', 'stl10',
        'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'kmnist',
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft', 'gtsrb',
        'pcam', 'semeion', 'stanford_cars', 'usps'
    ]
    sklearn_img_datasets = ['digits', 'olivetti_faces']
    sklearn_tab_datasets = ['covertype']
    other_tabular_datasets = ['spambase', 'adult']
    audio_datasets = ['speech_commands']

    # --- Define Grayscale Datasets ---
    grayscale_datasets = ['mnist', 'fashionmnist', 'emnist', 'kmnist',
                          'fer2013', 'semeion', 'usps', 'digits', 'olivetti_faces']


    # --- Default Transforms (Resize for ResNet, Normalize) ---
    # Use ImageNet stats if resizing to 224, otherwise use dataset-specific or generic
    if target_image_size == 224:
         normalize_3channel = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
         effective_image_size = 224
    else:
         # Use target_image_size if provided and not 224
         normalize_3channel = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]) # Generic for 3 channels
         effective_image_size = target_image_size # Use the specified non-224 size

    # Use a separate normalizer for grayscale if we ever need 1-channel output (currently forcing 3 for ResNet)
    # normalize_gray = transforms.Normalize(mean=[0.5], std=[0.5])

    # --- Common Image Transforms ---
    # Basic train transform: Resize, maybe augment, ToTensor, Normalize
    # Use effective_image_size which is either target_image_size or inferred later if target is None
    current_size = effective_image_size if effective_image_size is not None else 224 # Fallback size if needed
    transform_train_list = [transforms.Resize((current_size, current_size), antialias=True)]
    # Basic test transform: Resize, ToTensor, Normalize
    transform_test_list = [transforms.Resize((current_size, current_size), antialias=True)]

    # Add grayscale handling if needed later
    grayscale_transform = transforms.Grayscale(num_output_channels=3) # Assume ResNet target

    # Add augmentations (example for CV)
    if dataset_name in torchvision_cv_datasets or dataset_name in sklearn_img_datasets:
         transform_train_list.extend([
             transforms.RandomHorizontalFlip(),
             # Add more robust augmentations like RandAugment or TrivialAugmentWide if desired
             # transforms.TrivialAugmentWide(),
             # transforms.RandomRotation(10),
             # transforms.ColorJitter(brightness=0.1, contrast=0.1),
         ])

    # Add ToTensor and Normalize at the end
    transform_train_list.append(transforms.ToTensor())
    transform_test_list.append(transforms.ToTensor())
    # Normalization applied after ToTensor
    # Note: Normalization object needs to match number of channels AFTER ToTensor and Grayscale

    # --- Load based on dataset name ---

    if dataset_name in torchvision_cv_datasets:
        input_channels_model = 3 # We will force 3 channels for ResNet/CNN compatibility
        is_grayscale = dataset_name in grayscale_datasets

        # Determine normalization and potentially update effective_image_size if not target_image_size
        current_normalize = normalize_3channel # Start with default based on target_image_size

        if is_grayscale:
             transform_train_list.insert(1, grayscale_transform) # Apply after Resize
             transform_test_list.insert(1, grayscale_transform)
             # Normalization remains 3-channel because Grayscale(3) outputs 3 channels
        else:
             # Use dataset-specific normalization ONLY if not resizing to 224
             if target_image_size != 224:
                 if dataset_name == 'cifar10':
                      current_normalize = transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
                      if effective_image_size is None: effective_image_size = 32 # Default CIFAR size
                 elif dataset_name == 'svhn':
                      current_normalize = transforms.Normalize((0.4377, 0.4438, 0.4728), (0.1980, 0.2010, 0.1970)) # Approx SVHN stats
                      if effective_image_size is None: effective_image_size = 32 # Default SVHN size
                 # Add elif for other datasets with known non-ImageNet stats if needed
                 else:
                      print(f"Warning: Using generic 3-channel normalization for {dataset_name} (non-224 resize)")
                      # effective_image_size should already be set from target_image_size here
                      if effective_image_size is None: # Should not happen if target_image_size != 224
                           print("Error: effective_image_size is None unexpectedly.")
                           effective_image_size = target_image_size # Attempt recovery
             # else: current_normalize remains the ImageNet one for 224x224


        # Rebuild transform lists if effective_image_size changed
        if effective_image_size != current_size:
             print(f"Adjusting resize transform to {effective_image_size}x{effective_image_size}")
             transform_train_list[0] = transforms.Resize((effective_image_size, effective_image_size), antialias=True)
             transform_test_list[0] = transforms.Resize((effective_image_size, effective_image_size), antialias=True)

        # Append the determined normalization
        transform_train_list.append(current_normalize)
        transform_test_list.append(current_normalize)

        # Compose the final transforms
        transform_train = transforms.Compose(transform_train_list)
        transform_test = transforms.Compose(transform_test_list)
        print(f"Using effective image size: {effective_image_size}x{effective_image_size}")


        # --- Load specific torchvision dataset ---
        try:
            # Use a mapping for cleaner loading
            dataset_map = {
                'cifar10': torchvision.datasets.CIFAR10,
                'mnist': torchvision.datasets.MNIST,
                'fashionmnist': torchvision.datasets.FashionMNIST,
                'svhn': torchvision.datasets.SVHN,
                'cifar100': torchvision.datasets.CIFAR100,
                'stl10': torchvision.datasets.STL10,
                'food101': torchvision.datasets.Food101,
                'flowers102': torchvision.datasets.Flowers102,
                'oxfordiiitpet': torchvision.datasets.OxfordIIITPet,
                'emnist': torchvision.datasets.EMNIST,
                'kmnist': torchvision.datasets.KMNIST,
                'caltech101': torchvision.datasets.Caltech101,
                'dtd': torchvision.datasets.DTD,
                'eurosat': torchvision.datasets.EuroSAT,
                'fer2013': torchvision.datasets.FER2013,
                'fgvc_aircraft': torchvision.datasets.FGVCAircraft,
                'gtsrb': torchvision.datasets.GTSRB,
                'pcam': torchvision.datasets.PCAM, # Note: PCAM labels might need special handling depending on task
                'semeion': torchvision.datasets.SEMEION,
                'stanford_cars': torchvision.datasets.StanfordCars,
                'usps': torchvision.datasets.USPS,
            }

            if dataset_name not in dataset_map:
                raise ValueError(f"Dataset {dataset_name} is in torchvision_cv_datasets list but not handled in map.")

            DatasetClass = dataset_map[dataset_name]
            print(f"Loading {dataset_name} using {DatasetClass.__name__}...")

            # Handle datasets with specific 'split' arguments or train/test bools
            if dataset_name in ['svhn', 'stl10', 'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'fer2013', 'fgvc_aircraft', 'gtsrb', 'pcam', 'stanford_cars']:
                split_args_train = {'split': 'train'}
                split_args_test = {'split': 'test'}
                # Adjust splits based on dataset documentation
                if dataset_name == 'svhn':
                     split_args_test = {'split': 'test'}
                elif dataset_name == 'stl10':
                     split_args_test = {'split': 'test'}
                elif dataset_name == 'food101':
                     # Food101 docs say split='train' or 'test'
                     pass
                elif dataset_name == 'flowers102':
                     # Flowers102 uses 'train', 'val', 'test'. Combine train+val? Or just use 'train'? Let's use 'train' and 'test'.
                     pass
                elif dataset_name == 'oxfordiiitpet':
                     split_args_train = {'split': 'trainval'} # Often combined for training
                     split_args_test = {'split': 'test'}
                elif dataset_name == 'emnist':
                     # Requires split like 'byclass', 'letters', etc. Assume 'byclass' if not specified.
                     split_args_train = {'split': 'byclass', 'train': True}
                     split_args_test = {'split': 'byclass', 'train': False}
                elif dataset_name == 'fer2013':
                     # FER2013 uses 'train', 'test' ('PrivateTest'), 'publictest' ('PublicTest')
                     split_args_test = {'split': 'test'} # Use PrivateTest as test set
                elif dataset_name == 'fgvc_aircraft':
                     split_args_train = {'split': 'trainval'} # Usually train+val
                     split_args_test = {'split': 'test'}
                elif dataset_name == 'gtsrb':
                     # GTSRB uses 'train', 'test'
                     pass
                elif dataset_name == 'pcam':
                     # PCAM uses 'train', 'val', 'test'. Use 'train' and 'test'.
                     pass
                elif dataset_name == 'stanford_cars':
                      split_args_train = {'split': 'train'}
                      split_args_test = {'split': 'test'}

                # Add 'train' bool if needed (like EMNIST)
                if 'train' not in split_args_train: split_args_train['train'] = True
                if 'train' not in split_args_test: split_args_test['train'] = False


                # Load with specific splits
                try:
                    train_dataset_full = DatasetClass(root=data_root, download=True, transform=transform_train, **{k:v for k,v in split_args_train.items() if k!='train'}) # Pass split args
                    test_dataset = DatasetClass(root=data_root, download=True, transform=transform_test, **{k:v for k,v in split_args_test.items() if k!='train'})
                except TypeError as te: # Handle cases where 'train' bool is the selector, not 'split'
                     if "'train' is an invalid keyword argument" in str(te) or "unexpected keyword argument 'split'" in str(te) :
                         print(f"Adjusting load arguments for {dataset_name} (train bool vs split).")
                         # Try using train=True/False
                         train_dataset_full = DatasetClass(root=data_root, train=True, download=True, transform=transform_train)
                         test_dataset = DatasetClass(root=data_root, train=False, download=True, transform=transform_test)
                     else: raise te # Re-raise other TypeErrors


            elif dataset_name in ['caltech101', 'dtd', 'eurosat', 'semeion']:
                 # These datasets might not have predefined splits in torchvision
                 print(f"Warning: Dataset {dataset_name} might not have standard train/test splits in torchvision. Loading all data and splitting manually (80/20).")
                 # Load the full dataset with train transforms first for splitting
                 full_dataset_train_tf = DatasetClass(root=data_root, download=True, transform=transform_train)

                 # Attempt to get labels for stratification
                 targets = None
                 try:
                     if hasattr(full_dataset_train_tf, 'targets') and full_dataset_train_tf.targets is not None:
                         targets = full_dataset_train_tf.targets
                     elif hasattr(full_dataset_train_tf, '_labels') and full_dataset_train_tf._labels is not None: # Common alternative attribute
                         targets = full_dataset_train_tf._labels
                     elif hasattr(full_dataset_train_tf, 'labels') and full_dataset_train_tf.labels is not None: # Another possibility
                          targets = full_dataset_train_tf.labels
                     else: # Iterate if no standard attribute found
                          print("Iterating to get targets for splitting...")
                          targets = [sample[1] for sample in tqdm(full_dataset_train_tf, desc="Getting targets")]
                     targets = np.array(targets) # Ensure numpy array for splitting
                     num_classes = len(np.unique(targets))
                     print(f"Inferred {num_classes} classes for {dataset_name}")
                 except Exception as e:
                     print(f"Could not automatically determine targets for {dataset_name} for stratified split: {e}. Using non-stratified split.")
                     targets = None
                     # Try to get num_classes from .classes attribute if available
                     if hasattr(full_dataset_train_tf, 'classes') and full_dataset_train_tf.classes:
                         num_classes = len(full_dataset_train_tf.classes)
                     else:
                          print("Warning: Could not determine number of classes.")
                          num_classes = 1 # Placeholder


                 # Manual split (80/20)
                 train_indices, test_indices = train_test_split(
                     np.arange(len(full_dataset_train_tf)),
                     test_size=0.2,
                     random_state=42,
                     stratify=targets if targets is not None and num_classes > 1 else None # Stratify if possible
                 )

                 # Create subset for training (using the dataset with train transforms)
                 train_dataset_full = Subset(full_dataset_train_tf, train_indices)

                 # Create a separate dataset instance with test transforms for the test subset
                 full_dataset_test_tf = DatasetClass(root=data_root, download=True, transform=transform_test)
                 test_dataset = Subset(full_dataset_test_tf, test_indices)

                 # Infer image size if not explicitly set
                 if effective_image_size is None:
                     try:
                         effective_image_size = train_dataset_full[0][0].shape[-1]
                         print(f"Inferred effective image size for {dataset_name}: {effective_image_size}")
                         # Update transforms if size changed from initial guess
                         if effective_image_size != current_size:
                             print(f"Adjusting resize transform to {effective_image_size}x{effective_image_size} after inference.")
                             new_resize = transforms.Resize((effective_image_size, effective_image_size), antialias=True)
                             # Need to rebuild the *entire* transform chain for the datasets
                             # This is complex; easier to ensure target_image_size is set appropriately beforehand
                             # Or accept the potentially mismatched size if inference happens late.
                             # Let's just update the variable for model creation.
                     except Exception as size_infer_e:
                          print(f"Warning: Could not infer image size for {dataset_name}: {size_infer_e}. Using default {current_size}.")
                          effective_image_size = current_size


            else: # Default: Use train=True/False argument
                train_dataset_full = DatasetClass(root=data_root, train=True, download=True, transform=transform_train)
                test_dataset = DatasetClass(root=data_root, train=False, download=True, transform=transform_test)

            # Infer num_classes if not set during split logic
            if num_classes is None:
                try:
                    # Prefer class attribute
                    if hasattr(train_dataset_full, 'classes') and train_dataset_full.classes:
                        num_classes = len(train_dataset_full.classes)
                    # Fallback to iterating through subset/dataset targets
                    else:
                         print(f"Inferring num_classes by checking unique labels for {dataset_name}...")
                         if isinstance(train_dataset_full, Subset):
                             targets = [train_dataset_full.dataset.targets[i] for i in train_dataset_full.indices] # Example for target attribute
                         elif hasattr(train_dataset_full, 'targets'):
                              targets = train_dataset_full.targets
                         elif hasattr(train_dataset_full, '_labels'):
                              targets = train_dataset_full._labels
                         elif hasattr(train_dataset_full, 'labels'):
                              targets = train_dataset_full.labels
                         else: # Last resort iteration (slow)
                             targets = [sample[1] for sample in train_dataset_full]
                         num_classes = len(np.unique(targets))
                    print(f"Determined {num_classes} classes for {dataset_name}.")
                except Exception as nc_err:
                    print(f"ERROR: Failed to determine number of classes for {dataset_name}: {nc_err}")
                    raise # Cannot proceed without num_classes

            # Infer image size if not set (e.g. target_image_size was None and not CIFAR/SVHN)
            if effective_image_size is None:
                try:
                     effective_image_size = train_dataset_full[0][0].shape[-1]
                     print(f"Inferred effective image size for {dataset_name}: {effective_image_size}")
                except Exception as size_err:
                     print(f"Warning: Could not infer image size for {dataset_name}: {size_err}. Using default 224.")
                     effective_image_size = 224


            print(f"Loaded {dataset_name}. Train samples (full): {len(train_dataset_full)}, Test samples: {len(test_dataset)}, Classes: {num_classes}")
            input_channels = input_channels_model # Channels the model expects (3)

        except AttributeError as ae:
             raise ValueError(f"Dataset {dataset_name} not found in torchvision.datasets (or requires specific arguments). Check spelling and availability. Error: {ae}")
        except Exception as e:
             print(f"!!! Error loading torchvision dataset {dataset_name} !!!")
             raise RuntimeError(f"Error details: {e}")


    elif dataset_name in sklearn_img_datasets:
        # (Keep the existing sklearn_img_datasets loading block)
        # Ensure effective_image_size is set based on target_image_size
        dataset_type = 'image'
        input_channels_model = 3 # Force 3 channels for model
        is_grayscale = True # These are inherently grayscale

        # Determine final size based on target_image_size
        current_size = target_image_size # Use the argument directly
        effective_image_size = current_size # Size after resize

        # Update transform lists with the definitive size
        transform_train_list = [transforms.Resize((current_size, current_size), antialias=True)]
        transform_test_list = [transforms.Resize((current_size, current_size), antialias=True)]

        # Add grayscale -> 3 channel transform
        transform_train_list.insert(1, grayscale_transform)
        transform_test_list.insert(1, grayscale_transform)

        # Add augmentations
        transform_train_list.extend([transforms.RandomHorizontalFlip()])

        # Add ToTensor + Normalize (using 3-channel normalize)
        transform_train_list.append(transforms.ToTensor())
        transform_test_list.append(transforms.ToTensor())
        transform_train_list.append(normalize_3channel)
        transform_test_list.append(normalize_3channel)

        # Compose transforms (split for PIL application)
        transform_train_pil = transforms.Compose(transform_train_list[0:-2]) # Exclude ToTensor/Normalize
        transform_test_pil = transforms.Compose(transform_test_list[0:-2]) # Exclude ToTensor/Normalize
        final_tensor_transform = transforms.Compose(transform_train_list[-2:]) # ToTensor + Normalize

        sklearn_data_home = os.path.join(data_root, 'sklearn_data')
        os.makedirs(sklearn_data_home, exist_ok=True)
        X, y = None, None
        img_h, img_w = None, None

        if dataset_name == 'digits':
            digits = load_digits()
            X = digits.data.astype(np.float32) # (n_samples, 64)
            y = digits.target
            num_classes = 10
            img_h, img_w = 8, 8
        elif dataset_name == 'olivetti_faces':
            try:
                faces = fetch_olivetti_faces(data_home=sklearn_data_home, shuffle=True, random_state=42)
                X = faces.data.astype(np.float32) # (n_samples, 4096)
                y = faces.target
                num_classes = 40
                img_h, img_w = 64, 64
            except Exception as e:
                print(f"Error fetching Olivetti Faces: {e}")
                raise

        if X is None: raise RuntimeError(f"Failed to load sklearn dataset {dataset_name}")

        # Reshape flat data to image format (N, H, W) - single channel initially
        X = X.reshape(-1, img_h, img_w)

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y if num_classes > 1 else None
        )

        # Apply transforms (needs PIL conversion temporarily)
        # Use Tqdm for progress as this can be slow
        def apply_pil_transforms_with_progress(data, pil_transform, final_transform, desc="Applying PIL transforms"):
             # Convert numpy HxW to PIL Image -> Apply PIL transforms -> Apply Tensor transforms
             processed_tensors = []
             for img_np in tqdm(data, desc=desc):
                 pil_img = transforms.ToPILImage()(img_np)
                 transformed_pil = pil_transform(pil_img)
                 tensor_img = final_tensor_transform(transformed_pil)
                 processed_tensors.append(tensor_img)
             return torch.stack(processed_tensors)

        print("Applying transforms to sklearn image data (this may take a while)...")
        X_train_tensor = apply_pil_transforms_with_progress(X_train, transform_train_pil, final_tensor_transform, desc="Transforming train data")
        X_test_tensor = apply_pil_transforms_with_progress(X_test, transform_test_pil, final_tensor_transform, desc="Transforming test data")

        # Create datasets from tensors
        train_dataset_full = NumpyDataset(X_train_tensor, y_train) # Use _full naming convention
        test_dataset = NumpyDataset(X_test_tensor, y_test)
        # effective_image_size is already set based on target_image_size
        input_channels = input_channels_model # Model expects 3
        print(f"Loaded {dataset_name}. Train: {len(train_dataset_full)}, Test: {len(test_dataset)}, Classes: {num_classes}")

    elif dataset_name in sklearn_tab_datasets or dataset_name in other_tabular_datasets:
        # (Keep the existing tabular loading block)
        dataset_type = 'tabular'
        input_channels = None # Not applicable
        effective_image_size = None # Not applicable
        X_train_processed, y_train, X_test_processed, y_test = None, None, None, None

        if dataset_name == 'covertype':
             sklearn_data_home = os.path.join(data_root, 'sklearn_data')
             try:
                 covtype = fetch_covtype(data_home=sklearn_data_home, download_if_missing=True)
                 X = covtype.data.astype(np.float32)
                 y = covtype.target - 1 # Map to 0-based
                 num_classes = 7

                 # Split first
                 X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
                 # Scale
                 scaler = StandardScaler()
                 X_train_processed = scaler.fit_transform(X_train)
                 X_test_processed = scaler.transform(X_test)
                 input_features = X_train_processed.shape[1]

             except Exception as e:
                 print(f"Error loading Covertype: {e}")
                 raise

        elif dataset_name == 'spambase':
            X_train_processed, y_train, X_test_processed, y_test, input_features, num_classes = \
                load_and_preprocess_spambase_train(data_root)

        elif dataset_name == 'adult':
            X_train_processed, y_train, X_test_processed, y_test, input_features, num_classes = \
                load_and_preprocess_adult_train(data_root)

        # Ensure loading was successful before creating datasets
        if X_train_processed is None or X_test_processed is None or y_train is None or y_test is None or input_features is None or num_classes is None:
             raise RuntimeError(f"Failed to load or process tabular dataset {dataset_name}")

        # Create NumpyDatasets
        train_dataset_full = NumpyDataset(X_train_processed, y_train)
        test_dataset = NumpyDataset(X_test_processed, y_test)
        print(f"Loaded {dataset_name}. Train: {len(train_dataset_full)}, Test: {len(test_dataset)}, Features: {input_features}, Classes: {num_classes}")


    elif dataset_name in audio_datasets:
        # (Keep the existing audio loading block)
        dataset_type = 'audio_spectrogram' # Treat spectrograms like tabular features for MLP
        input_channels = None
        effective_image_size = None
        SPEECH_TARGET_LENGTH_SAMPLES = 16000 # 1 second at 16kHz
        sample_rate = 16000
        n_fft = 400
        hop_length = 160
        n_mels = 64

        print("Loading Speech Commands...")
        try:
            # Load raw audio datasets
            # Handle potential download issues more gracefully
            try:
                train_set_raw = torchaudio.datasets.SPEECHCOMMANDS(root=data_root, subset="training", download=True)
            except Exception as e_train:
                 print(f"Error downloading/loading SpeechCommands training set: {e_train}")
                 print("Attempting to load from existing files if possible...")
                 train_set_raw = torchaudio.datasets.SPEECHCOMMANDS(root=data_root, subset="training", download=False) # Try without download

            try:
                 test_set_raw = torchaudio.datasets.SPEECHCOMMANDS(root=data_root, subset="testing", download=True)
            except Exception as e_test:
                 print(f"Error downloading/loading SpeechCommands testing set: {e_test}")
                 print("Attempting to load from existing files if possible...")
                 test_set_raw = torchaudio.datasets.SPEECHCOMMANDS(root=data_root, subset="testing", download=False)


            # Get label mapping from training set
            all_labels_list = sorted(list(set(item[2] for item in train_set_raw)))
            label_to_int = {label: i for i, label in enumerate(all_labels_list)}
            num_classes = len(all_labels_list)

            # Define Mel Spectrogram transform
            log_mel_spectrogram = transforms.Compose([
                T.MelSpectrogram(sample_rate=sample_rate, n_fft=n_fft, hop_length=hop_length, n_mels=n_mels, power=2.0),
                T.AmplitudeToDB(stype='power', top_db=80)
            ])

            # Process function
            def process_audio_dataset(dataset, split_name):
                 processed_spectrograms = []
                 processed_labels = []
                 print(f"Processing Speech Commands {split_name} set ({len(dataset)} samples)...")
                 skipped_resample = 0
                 skipped_transform = 0
                 for item in tqdm(dataset, desc=f"Processing {split_name}"):
                     waveform, sr, label, *_ = item # Unpack, ignore potential extra fields
                     if label not in label_to_int: # Skip labels not seen in training (e.g. _background_noise_)
                          continue
                     if sr != sample_rate:
                          try: waveform = torchaudio.functional.resample(waveform, sr, sample_rate)
                          except Exception as resample_err:
                               # print(f"Warning: Resample failed ({resample_err}), skipping sample.")
                               skipped_resample += 1
                               continue # Skip if resample fails
                     waveform_processed = pad_or_truncate(waveform, SPEECH_TARGET_LENGTH_SAMPLES)
                     try:
                          spec = log_mel_spectrogram(waveform_processed)
                          # Ensure spec is not empty or invalid
                          if spec.nelement() == 0 or torch.isnan(spec).any() or torch.isinf(spec).any():
                               # print("Warning: Invalid spectrogram generated, skipping.")
                               skipped_transform += 1
                               continue
                     except Exception as transform_err:
                           # print(f"Warning: Spectrogram failed ({transform_err}), skipping sample.")
                           skipped_transform +=1
                           continue # Skip if transform fails

                     # Flatten [Channel, Mel, Time] -> [Features]
                     if spec.dim() > 1:
                          processed_spectrograms.append(spec.flatten().numpy())
                          processed_labels.append(label_to_int[label])
                 if skipped_resample > 0: print(f"Skipped {skipped_resample} samples due to resampling errors.")
                 if skipped_transform > 0: print(f"Skipped {skipped_transform} samples due to transform errors or invalid output.")

                 if not processed_spectrograms: # Check if list is empty
                     return np.array([]), np.array([]) # Return empty arrays

                 X = np.array(processed_spectrograms, dtype=np.float32)
                 y = np.array(processed_labels, dtype=int)
                 return X, y

            X_train, y_train = process_audio_dataset(train_set_raw, "training")
            X_test, y_test = process_audio_dataset(test_set_raw, "testing")

            if X_train.size == 0 or X_test.size == 0:
                 raise RuntimeError("No speech samples processed successfully for train or test set.")

            input_features = X_train.shape[1] # Flattened spectrogram features

            # Create NumpyDatasets
            train_dataset_full = NumpyDataset(X_train, y_train)
            test_dataset = NumpyDataset(X_test, y_test)
            print(f"Loaded {dataset_name}. Train: {len(train_dataset_full)}, Test: {len(test_dataset)}, Features: {input_features}, Classes: {num_classes}")

        except Exception as e:
            print(f"!!! Error loading/processing Speech Commands !!!")
            raise RuntimeError(f"Error details: {e}")

    else:
        raise ValueError(f"Unknown or unsupported dataset name for training: {dataset_name}")

    # Final checks
    if train_dataset_full is None or test_dataset is None or num_classes is None:
        raise RuntimeError(f"Dataset loading failed for {dataset_name}: train_dataset_full, test_dataset, or num_classes is None.")
    if dataset_type == 'image':
        # Input channels should be the channels the *model* receives (forced to 3 for ResNet/CNN)
        # effective_image_size should be the size after transforms
        if input_channels_model is None or effective_image_size is None:
             raise RuntimeError(f"Image dataset {dataset_name} missing input_channels_model ({input_channels_model}) or effective_image_size ({effective_image_size}) info.")
        input_channels = input_channels_model # Set the return value for input_channels
    elif dataset_type in ['tabular', 'audio_spectrogram']:
        if input_features is None:
             raise RuntimeError(f"Non-image dataset {dataset_name} missing input_features info.")
    else:
         raise RuntimeError(f"Unknown dataset_type: {dataset_type}")


    return train_dataset_full, test_dataset, num_classes, input_channels, effective_image_size, input_features, dataset_type


def train(model, device, train_loader, optimizer, criterion, epoch):
    # (Keep existing train function)
    """Training loop for one epoch with tqdm progress bar."""
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    pbar = tqdm(enumerate(train_loader), total=len(train_loader), desc=f"Epoch {epoch} Training", leave=False)
    for batch_idx, (data, target) in pbar:
        data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True) # Use non_blocking for potential speedup with pin_memory=True
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
        _, predicted = output.max(1)
        total += target.size(0)
        correct += predicted.eq(target).sum().item()
        pbar.set_postfix(loss=f'{loss.item():.4f}', acc=f'{100.*correct/total:.2f}%')

    avg_loss = train_loss / len(train_loader) if len(train_loader) > 0 else 0
    accuracy = 100. * correct / total if total > 0 else 0
    return avg_loss, accuracy


def test(model, device, test_loader, criterion):
    # (Keep existing test function)
    """Evaluation loop with tqdm progress bar."""
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    pbar = tqdm(test_loader, desc="Testing", leave=False)
    with torch.no_grad():
        for data, target in pbar:
            data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)
            output = model(data)
            batch_loss = criterion(output, target).item()
            test_loss += batch_loss # Sum of losses for averaging per batch later
            _, predicted = output.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
            # pbar.set_postfix(loss=f'{batch_loss:.4f}', acc=f'{100.*correct/total:.2f}%') # Show running accuracy

    avg_loss = test_loss / len(test_loader) if len(test_loader) > 0 else 0 # Avg loss per batch
    accuracy = 100. * correct / total if total > 0 else 0
    return avg_loss, accuracy # Return avg loss per batch and total accuracy


# --- Main Execution ---

def main():
    # --- Argument Parsing ---
    all_datasets_list = sorted([
        'cifar10', 'mnist', 'fashionmnist', 'svhn', 'cifar100', 'stl10',
        'food101', 'flowers102', 'oxfordiiitpet', 'emnist', 'kmnist',
        'caltech101', 'dtd', 'eurosat', 'fer2013', 'fgvc_aircraft', 'gtsrb',
        'pcam', 'semeion', 'stanford_cars', 'usps',
        'digits', 'olivetti_faces', 'covertype',
        'spambase', 'adult', 'speech_commands'
    ])
    parser = argparse.ArgumentParser(description='PyTorch Universal Training Script')
    # Allow 'all' for dataset selection
    parser.add_argument('--dataset', type=str, required=True,
                        help=f'Dataset to use, or "all" to run all datasets. Choices: {all_datasets_list}')
    parser.add_argument('--model', type=str, default='auto',
                        choices=['auto', 'resnet18', 'resnet50', 'simple_cnn', 'mlp'],
                        help='Model architecture (auto: ResNet50 for image, MLP for others)')
    # Allow 'all' for num_train_samples
    parser.add_argument('--num_train_samples', type=str, default='1.0',
                        help='Number or fraction of training samples (e.g., 0.1, 5000), or "all" for specific sampling strategy')
    parser.add_argument('--epochs', type=int, default=20, metavar='N',
                        help='number of epochs to train (default: 20)')
    parser.add_argument('--batch_size', type=int, default=128, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                        help='learning rate (default: 0.001)')
    parser.add_argument('--seed', type=int, default=42, metavar='S',
                        help='random seed (default: 42)')
    parser.add_argument('--no_cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--results_dir', type=str, default=RESULTS_BASE_DIR,
                        help='Base directory to save results')
    parser.add_argument('--data_root', type=str, default=DATA_ROOT,
                        help='Directory where datasets are stored/downloaded')
    parser.add_argument('--img_size', type=int, default=224,
                        help='Target image size for resizing (affects CV datasets)')
    parser.add_argument('--num_workers', type=int, default=4, help='Number of dataloader workers') # Add num_workers arg

    args = parser.parse_args()

    # --- Setup ---
    set_seed(args.seed)
    use_cuda = not args.no_cuda and torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    print(f"Using device: {device}")

    # --- Determine Datasets to Run ---
    if args.dataset.lower() == 'all':
        datasets_to_run = all_datasets_list
    elif args.dataset in all_datasets_list:
        datasets_to_run = [args.dataset]
    else:
        raise ValueError(f"Invalid dataset name '{args.dataset}'. Choose from {all_datasets_list} or 'all'.")

    # --- Outer Loop: Iterate through datasets ---
    for current_dataset_name in datasets_to_run:
        print(f"\n{'='*20} Processing Dataset: {current_dataset_name} {'='*20}")

        # --- Load Full Dataset Info (needed for 'all' samples) ---
        try:
            print("Loading full dataset info to determine sample sizes...")
            train_dataset_full, test_dataset, num_classes, input_channels, image_size, input_features, dataset_type = get_datasets_for_training(
                current_dataset_name, data_root=args.data_root, target_image_size=args.img_size
            )
            num_train_samples_full = len(train_dataset_full)
            print(f"Full training set size: {num_train_samples_full}")
            # Free up memory if datasets are large, we'll reload subsets later if needed?
            # Or keep them if subsetting is efficient. Let's keep for now.
            # del test_dataset # Keep test set loaded
        except Exception as e:
            print(f"\n !!! Fatal Error during initial dataset loading for {current_dataset_name} !!!")
            print(f"Error details: {e}")
            print(f"Skipping dataset {current_dataset_name}...")
            continue # Skip to the next dataset

        # --- Determine Sample Sizes to Run ---
        sample_sizes_to_run = []
        if args.num_train_samples.lower() == 'all':
            print("Calculating 'all' sample sizes strategy...")
            threshold_10_percent = int(num_train_samples_full * 0.1)
            min_geometric_start = 16

            # Geometric sequence
            current_geom_size = min_geometric_start
            while current_geom_size < threshold_10_percent and current_geom_size < num_train_samples_full:
                sample_sizes_to_run.append(current_geom_size)
                current_geom_size *= 2
            # Ensure threshold is included if not hit exactly, and doesn't exceed full size
            if threshold_10_percent >= min_geometric_start and threshold_10_percent <= num_train_samples_full:
                 sample_sizes_to_run.append(threshold_10_percent)

            # Linear sequence (fractions 0.1 to 1.0)
            for fraction in np.arange(0.1, 1.01, 0.1): # Use 1.01 to include 1.0 due to float precision
                linear_size = int(math.ceil(num_train_samples_full * fraction)) # Use ceil to ensure 1.0 reaches full size
                linear_size = min(linear_size, num_train_samples_full) # Cap at full size
                sample_sizes_to_run.append(linear_size)

            # Ensure sorted, unique list, and handle small datasets
            sample_sizes_to_run = sorted(list(set(sample_sizes_to_run)))
            sample_sizes_to_run = [s for s in sample_sizes_to_run if s > 0] # Remove potentially zero size

            if not sample_sizes_to_run: # Handle very small datasets where all calculated sizes are 0 or empty
                 sample_sizes_to_run = [num_train_samples_full] # Just run the full dataset
                 print(f"Warning: Dataset too small for 'all' sampling strategy. Using full dataset ({num_train_samples_full} samples).")

            print(f"Calculated sample sizes: {sample_sizes_to_run}")

        else:
            try:
                num_samples_input = float(args.num_train_samples)
                if 0 < num_samples_input <= 1:
                    calculated_samples = int(num_train_samples_full * num_samples_input)
                elif num_samples_input > 1:
                    calculated_samples = int(num_samples_input)
                else:
                    raise ValueError("num_train_samples must be > 0")

                # Clamp to maximum available samples
                calculated_samples = min(calculated_samples, num_train_samples_full)
                calculated_samples = max(1, calculated_samples) # Ensure at least 1 sample if possible

                sample_sizes_to_run = [calculated_samples]
                print(f"Using specified sample size: {sample_sizes_to_run[0]}")

            except ValueError:
                raise ValueError(f"Invalid value for --num_train_samples: '{args.num_train_samples}'. Must be a number, fraction, or 'all'.")


        # --- Inner Loop: Iterate through sample sizes ---
        for current_num_samples in sample_sizes_to_run:
            print(f"\n--- Processing: Dataset={current_dataset_name}, Samples={current_num_samples} ---")

            num_samples_str = str(current_num_samples)

            # --- Determine Model ---
            selected_model_name = args.model
            if selected_model_name == 'auto':
                if dataset_type == 'image':
                    selected_model_name = 'resnet50'
                elif dataset_type in ['tabular', 'audio_spectrogram']:
                    selected_model_name = 'mlp'
                else:
                    print("Warning: Unknown dataset type for auto model selection. Defaulting to MLP.")
                    selected_model_name = 'mlp'
                print(f"Auto-selected model: {selected_model_name}")
            else:
                print(f"User selected model: {selected_model_name}")

             # --- Validate Model Choice ---
            if dataset_type != 'image' and selected_model_name not in ['mlp']:
                 print(f"Warning: Model '{selected_model_name}' may be unsuitable for data type '{dataset_type}'. Prefer 'mlp'.")
            if dataset_type == 'image' and selected_model_name == 'mlp':
                 current_input_features = input_channels * image_size * image_size # Calculate features for MLP on images
                 print(f"Using MLP for image data. Calculated input_features: {current_input_features}")
            else:
                 current_input_features = input_features # Use value from dataset loading (None for non-MLP image models)


            # --- Check if Result Exists ---
            result_dir = os.path.join(args.results_dir, current_dataset_name, selected_model_name, num_samples_str)
            result_file = os.path.join(result_dir, 'result.json')

            if os.path.exists(result_file):
                print(f"Result file already exists: {result_file}. Skipping.")
                continue # Skip to the next sample size or dataset

            # --- Create Result Directory ---
            try:
                 os.makedirs(result_dir, exist_ok=True)
                 print(f"Results will be saved to: {result_file}")
            except OSError as e:
                 print(f"Error creating results directory {result_dir}: {e}. Skipping run.")
                 continue


            # --- Prepare Subset and Dataloaders ---
            if current_num_samples < num_train_samples_full:
                print(f"Creating training subset with {current_num_samples} samples...")
                g = torch.Generator()
                g.manual_seed(args.seed) # Ensure subset is reproducible
                # Ensure indices are generated based on the *full* original dataset length before potential subsetting in get_datasets
                base_dataset_len = len(train_dataset_full.dataset) if isinstance(train_dataset_full, Subset) else num_train_samples_full
                if current_num_samples > base_dataset_len: # Should not happen with clamping, but double check
                     print(f"Warning: current_num_samples {current_num_samples} > base_dataset_len {base_dataset_len}. Using all base samples.")
                     indices = torch.arange(base_dataset_len).tolist()
                else:
                     indices = torch.randperm(base_dataset_len, generator=g)[:current_num_samples].tolist()

                # Handle if train_dataset_full was already a subset (manual split)
                if isinstance(train_dataset_full, Subset):
                     # Map the randomly selected indices back to the *original* dataset indices
                     original_dataset_indices = train_dataset_full.indices # Indices of the manual split
                     # We need indices relative to the *original* dataset
                     # The randperm indices are for the *base* dataset. We need to ensure these indices are *also* in the manual split subset.
                     # More robust: generate indices from the *subset's* indices
                     subset_g = torch.Generator()
                     subset_g.manual_seed(args.seed)
                     subset_relative_indices = torch.randperm(len(train_dataset_full), generator=subset_g)[:current_num_samples].tolist()
                     final_indices = [train_dataset_full.indices[i] for i in subset_relative_indices]
                     train_dataset = Subset(train_dataset_full.dataset, final_indices) # Use the base dataset and final indices
                else:
                     train_dataset = Subset(train_dataset_full, indices)
            else:
                train_dataset = train_dataset_full # Use the full dataset

            # Adjust batch size if subset is very small
            effective_batch_size = min(args.batch_size, len(train_dataset)) if len(train_dataset) > 0 else 1
            if effective_batch_size <= 0:
                 print("Warning: Training dataset size is 0. Skipping training for this sample size.")
                 train_loader = None
            elif effective_batch_size < args.batch_size:
                 print(f"Adjusting batch size from {args.batch_size} to {effective_batch_size} due to small dataset size.")
                 train_loader = DataLoader(train_dataset, batch_size=effective_batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=use_cuda, drop_last=False) # drop_last=False ok for small BS
            else:
                 # Use drop_last=True for stability with BatchNorm if batch size is large enough
                 drop_last_train = len(train_dataset) > effective_batch_size
                 train_loader = DataLoader(train_dataset, batch_size=effective_batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=use_cuda, drop_last=drop_last_train)

            # Test loader remains the same (uses full test set)
            test_loader = DataLoader(test_dataset, batch_size=args.batch_size*2, shuffle=False, num_workers=args.num_workers, pin_memory=use_cuda)


            # --- Model, Criterion, Optimizer ---
            try:
                # Instantiate a new model for each run to ensure clean state
                model = get_model(
                    selected_model_name,
                    num_classes=num_classes,
                    input_channels=input_channels,
                    image_size=image_size,
                    input_features=current_input_features # Use potentially updated features for MLP on images
                ).to(device)
                print(f"Instantiated model: {selected_model_name} for {current_dataset_name} ({current_num_samples} samples)")
            except Exception as model_err:
                print(f"\n !!! Fatal Error creating model '{selected_model_name}' for this run !!!")
                print(f"Dataset properties: type={dataset_type}, classes={num_classes}, channels={input_channels}, img_size={image_size}, features={current_input_features}")
                print(f"Error: {model_err}")
                print("Skipping this sample size...")
                # Clean up model variable if it exists partially
                if 'model' in locals(): del model
                torch.cuda.empty_cache() if use_cuda else None
                continue # Skip to next sample size

            criterion = nn.CrossEntropyLoss()
            optimizer = optim.Adam(model.parameters(), lr=args.lr)
            # Consider using a learning rate scheduler here (e.g., CosineAnnealingLR)
            # scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)


            # --- Setup Results Dict for this run ---
            results_data = {
                'args': vars(args), # Store args used for the whole script execution
                'run_specific_config': { # Store config specific to this run
                    'dataset': current_dataset_name,
                    'model_selected': selected_model_name,
                    'actual_train_samples': current_num_samples,
                    'effective_batch_size': effective_batch_size,
                    'target_image_size_arg': args.img_size,
                },
                'dataset_properties': { # Store properties of the loaded dataset
                    'dataset_type': dataset_type,
                    'num_classes': num_classes,
                    'input_channels_model': input_channels, # Channels model expects
                    'effective_image_size': image_size, # Size model sees after transforms
                    'input_features_mlp': current_input_features, # For MLP specifically
                    'full_train_size': num_train_samples_full,
                    'test_set_size': len(test_dataset)
                },
                'best_test_accuracy': 0.0,
                'epoch_results': [],
                'training_status': 'Pending',
                'total_training_time_sec': None,
            }

            # --- Training and Evaluation Loop ---
            start_train_time = time.time()
            training_successful = True
            try:
                epoch_pbar = tqdm(range(1, args.epochs + 1), desc=f"Epochs (Dataset: {current_dataset_name}, Model: {selected_model_name}, Samples: {current_num_samples})")
                for epoch in epoch_pbar:

                    train_loss, train_acc = 0.0, 0.0
                    if train_loader:
                         train_loss, train_acc = train(model, device, train_loader, optimizer, criterion, epoch)
                    else:
                        print(f"--- Epoch {epoch} Training Skipped (0 samples or loader failed) ---")

                    test_loss, test_acc = 0.0, 0.0
                    if test_loader:
                        test_loss, test_acc = test(model, device, test_loader, criterion)
                    else:
                         print(f"--- Epoch {epoch} Testing Skipped (loader failed) ---")

                    # Optional: Step the scheduler
                    # scheduler.step()

                    epoch_summary = f"E {epoch}/{args.epochs} | Tr L: {train_loss:.3f}, Tr A: {train_acc:.2f}% | Te L: {test_loss:.3f}, Te A: {test_acc:.2f}%"
                    epoch_pbar.set_description(epoch_summary)

                    epoch_result = {
                        'epoch': epoch,
                        'train_loss': train_loss if train_loader else None,
                        'train_accuracy': train_acc if train_loader else None,
                        'test_loss': test_loss if test_loader else None,
                        'test_accuracy': test_acc if test_loader else None,
                        # 'learning_rate': scheduler.get_last_lr()[0] # Log LR if using scheduler
                    }
                    results_data['epoch_results'].append(epoch_result)

                    if test_loader and test_acc > results_data['best_test_accuracy']:
                        results_data['best_test_accuracy'] = test_acc

                    epoch_pbar.set_postfix(best_test_acc=f'{results_data["best_test_accuracy"]:.2f}%')

                results_data['training_status'] = 'Completed'

            except Exception as train_err:
                 print(f"\n!!! Error during training/testing loop for {current_dataset_name}, {selected_model_name}, {current_num_samples} samples !!!")
                 print(f"Error: {train_err}")
                 results_data['training_status'] = 'Failed'
                 results_data['error_message'] = str(train_err)
                 training_successful = False
            finally:
                # --- Finalize and Save Results for this Run ---
                end_train_time = time.time()
                total_training_time = end_train_time - start_train_time
                results_data['total_training_time_sec'] = round(total_training_time, 2)

                print(f"\n----- Run Summary -----")
                print(f"Dataset: {current_dataset_name}, Model: {selected_model_name}, Samples: {current_num_samples}")
                print(f"Status: {results_data['training_status']}")
                if training_successful:
                    print(f"Best Test Accuracy: {results_data['best_test_accuracy']:.2f}%")
                else:
                    print(f"Error: {results_data.get('error_message', 'Unknown')}")
                print(f"Total Time: {results_data['total_training_time_sec']:.2f}s")

                try:
                    def default_serializer(o):
                         if isinstance(o, np.integer): return int(o)
                         if isinstance(o, np.floating): return float(o)
                         if isinstance(o, np.ndarray): return o.tolist()
                         if isinstance(o, (np.bool_, bool)): return bool(o)
                         # Add specific handling for torch tensors if they sneak in
                         if isinstance(o, torch.Tensor): return o.tolist()
                         # Fallback for other types
                         try:
                              return str(o) # Try string conversion
                         except Exception:
                              return f"<unserializable type: {type(o).__name__}>"

                    with open(result_file, 'w') as f:
                        json.dump(results_data, f, indent=4, default=default_serializer)
                    print(f"Results saved to: {result_file}")
                except IOError as e:
                    print(f"ERROR: Failed to save results to {result_file}: {e}")
                except TypeError as e:
                     print(f"ERROR: Serialization Error saving results: {e}. Check data types in results_data.")

                # --- Clean up memory for next run ---
                if 'model' in locals(): del model
                if 'optimizer' in locals(): del optimizer
                # if 'scheduler' in locals(): del scheduler
                if 'criterion' in locals(): del criterion
                if 'train_loader' in locals(): del train_loader
                if 'test_loader' in locals(): del test_loader # Recreated each outer loop iteration
                if 'train_dataset' in locals(): del train_dataset
                torch.cuda.empty_cache() if use_cuda else None
                # End of sample size loop

        # --- Clean up full datasets after processing all sample sizes for a dataset ---
        # This assumes subsetting doesn't keep large references. If memory is tight,
        # you might need to reload the full dataset inside the sample loop.
        if 'train_dataset_full' in locals(): del train_dataset_full
        if 'test_dataset' in locals(): del test_dataset
        torch.cuda.empty_cache() if use_cuda else None
        # End of dataset loop

    print("\n===== All Specified Runs Complete =====")


if __name__ == '__main__':
    main()