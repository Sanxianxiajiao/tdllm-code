import json
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np # For pd.NA if using older pandas, or just for general use

# 1. SETUP
# ------------------------------------------------------------------------------
DATASETS = [
    'cifar10', 'mnist', 'fashionmnist', 'svhn', 'stl10',
    'food101', 'flowers102', 'oxfordiiitpet', 'fgvc_aircraft',
    'semeion', 'usps', 'cifar100'
]

MODELS_UNSORTED = [
        # Original models
        'resnet18',
        'resnet50',
        'vgg16',
        'mobilenet_v3_large',
        'efficientnet_b0',
        'vit_b_16',
        # New models you added
        'resnet101',
        'resnet152',
        'resnext101_32x8d',
        'wide_resnet101_2',
        'densenet161',
        'efficientnet_b7',
        'efficientnet_v2_l',
        'swin_b',
        'convnext_base'
    ]

MODEL_PARAMETERS = {
    'resnet18': 11.69, 'resnet50': 25.56, 'vgg16': 138.36,
    'mobilenet_v3_large': 5.48, 'efficientnet_b0': 5.29, 'vit_b_16': 86.57,
    'resnet101': 44.55, 'resnet152': 60.19, 'resnext101_32x8d': 88.79,
    'wide_resnet101_2': 126.89, 'inception_v3': 23.83, 'densenet161': 28.68,
    'efficientnet_b7': 66.35, 'efficientnet_v2_l': 118.55, 'swin_b': 87.79,
    'convnext_base': 88.59
}

MODELS_MISSING_PARAMS = [m for m in MODELS_UNSORTED if m not in MODEL_PARAMETERS]
if MODELS_MISSING_PARAMS:
    print(f"Warning: The following models are missing parameter counts and will be sorted to the end: {MODELS_MISSING_PARAMS}")

MODELS = sorted(MODELS_UNSORTED, key=lambda m: MODEL_PARAMETERS.get(m, float('inf')))
print("Models sorted by parameter count (ascending):")
for model_name in MODELS:
    params = MODEL_PARAMETERS.get(model_name)
    print(f"  - {model_name}: {params if params is not None and params != float('inf') else 'N/A'} M params")

# Metrics to extract and plot
METRICS_OF_INTEREST = [
    "num_classes",
    "label_entropy",
    "effective_dim",
    "intra_class_var_avg",
    "local_consistency",
    "separability_score"
]

# KDL Relationship Information for title generation
# ↑: High Proxy -> High Property (harder for K, D; easier for L)
# ↓: High Proxy -> Low Property (easier for K, D; harder for L)
# Note from table: Higher K/D = harder; Higher L = easier.
# So for L, if High Proxy -> Low L Property, then it means harder.
# Example: H(Y) is the proxy. High H(Y) -> High D Property. High H(Y) -> Low L Property.
METRIC_KDL_INFO = {
    "num_classes":          {"symbol": "n_d",   "K_effect": None, "D_effect": "↑", "L_effect": None},
    "label_entropy":        {"symbol": "H(Y)",  "K_effect": None, "D_effect": "↑", "L_effect": "↓"},
    "effective_dim":        {"symbol": "e_d",   "K_effect": None, "D_effect": "↑", "L_effect": None},
    "intra_class_var_avg":  {"symbol": "v_d",   "K_effect": None, "D_effect": "↑", "L_effect": "↓"},
    "local_consistency":    {"symbol": "l_d",   "K_effect": "↓", "D_effect": None, "L_effect": "↑"}, # High proxy lc -> Low K property, High L property
    "separability_score":   {"symbol": "s_d",   "K_effect": "↓", "D_effect": None, "L_effect": "↑"}  # High proxy sc -> Low K property, High L property
}


# Path template for data files
DATA_FILE_TEMPLATE = "./data_analys_{model}/{dataset}_complexity_metrics.json"

# Directory to save plots and results
SAVE_PIC_DIR = "./pic_cv/"
os.makedirs(SAVE_PIC_DIR, exist_ok=True)
CORRELATION_PIC_DIR = os.path.join(SAVE_PIC_DIR, "model_correlations")
os.makedirs(CORRELATION_PIC_DIR, exist_ok=True)


# Plot styling
plt.rcParams.update({'font.size': 12})
TITLE_FONTSIZE = 16
AXIS_LABEL_FONTSIZE = 12
TICK_LABEL_FONTSIZE = 12
ANNOT_FONTSIZE = 10
NUM_COLORS_FOR_RANK = 12

def get_kdl_suffix(metric_name):
    """Generates a KDL relationship suffix for plot titles."""
    info = METRIC_KDL_INFO.get(metric_name)
    if not info:
        return ""
    
    parts = []
    if info['symbol']:
        parts.append(f"${info['symbol']}$") # Render symbol in math mode

    kdl_effects = []
    if info["K_effect"]:
        kdl_effects.append(f"$\mathcal{{K}}{info['K_effect']}$")
    if info["D_effect"]:
        kdl_effects.append(f"$\mathcal{{D}}{info['D_effect']}$")
    if info["L_effect"]:
        kdl_effects.append(f"$\mathcal{{L}}{info['L_effect']}$")
    
    if kdl_effects:
        parts.append(", ".join(kdl_effects))
        
    return f" ({', '.join(parts)})" if parts else ""

# 2. DATA LOADING
# ------------------------------------------------------------------------------
def load_all_metric_data(datasets, models, metrics_list, file_template):
    all_metrics_data = {metric: pd.DataFrame(index=models, columns=datasets, dtype=float)
                        for metric in metrics_list}
    for model_name in models:
        for dataset_name in datasets:
            file_path = file_template.format(model=model_name, dataset=dataset_name)
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                complexity_metrics = data.get("complexity_metrics", {})
                for metric_name in metrics_list:
                    value = complexity_metrics.get(metric_name)
                    if value is not None:
                        all_metrics_data[metric_name].loc[model_name, dataset_name] = float(value)
                    else:
                        all_metrics_data[metric_name].loc[model_name, dataset_name] = pd.NA
            except FileNotFoundError:
                for metric_name in metrics_list:
                    all_metrics_data[metric_name].loc[model_name, dataset_name] = pd.NA
            except json.JSONDecodeError:
                print(f"Warning: Could not decode JSON from {file_path}. Assigning NA.")
                for metric_name in metrics_list:
                    all_metrics_data[metric_name].loc[model_name, dataset_name] = pd.NA
            except Exception as e:
                print(f"Error loading {file_path}: {e}. Assigning NA.")
                for metric_name in metrics_list:
                    all_metrics_data[metric_name].loc[model_name, dataset_name] = pd.NA
    return all_metrics_data

# 3. RANKING AND PLOTTING
# ------------------------------------------------------------------------------
def create_rank_heatmap(metric_name, raw_metric_df, save_dir):
    cleaned_metric_df = raw_metric_df.dropna(how='all', axis=0).dropna(how='all', axis=1)
    if cleaned_metric_df.empty or cleaned_metric_df.isnull().all().all():
        print(f"Skipping dataset rank heatmap for {metric_name} as no sufficient data is available after cleaning.")
        return

    rank_df = pd.DataFrame(index=cleaned_metric_df.index, columns=cleaned_metric_df.columns, dtype=float)
    for model_name in cleaned_metric_df.index:
        model_scores = cleaned_metric_df.loc[model_name]
        if model_scores.notna().sum() < 1:
            ranks = pd.Series([pd.NA] * len(model_scores), index=model_scores.index)
        else:
            ranks = model_scores.rank(method='dense', ascending=True, na_option='keep')
        rank_df.loc[model_name] = ranks

    rank_df_cleaned = rank_df.dropna(how='all', axis=0).dropna(how='all', axis=1)
    if rank_df_cleaned.empty:
        print(f"Skipping dataset rank heatmap for {metric_name} as rank_df is empty after ranking.")
        return

    plt.figure(figsize=(max(12, len(rank_df_cleaned.columns)*0.8) , max(8, len(rank_df_cleaned.index)*0.6)))
    min_rank_val = 1
    if not rank_df_cleaned.empty and rank_df_cleaned.notna().any().any():
        max_rank_val = rank_df_cleaned.max().max()
        if pd.isna(max_rank_val): max_rank_val = min_rank_val
    else:
        max_rank_val = min_rank_val

    cmap = plt.get_cmap("RdYlBu", NUM_COLORS_FOR_RANK)
    
    kdl_suffix = get_kdl_suffix(metric_name)
    title_str = f"Dataset Ranks for Metric: {metric_name.replace('_', ' ').title()}{kdl_suffix}"

    sns.heatmap(
        rank_df_cleaned, annot=True, fmt=".0f", cmap=cmap, linewidths=.5, linecolor='gray',
        cbar=True, annot_kws={"size": ANNOT_FONTSIZE}, vmin=min_rank_val,
        vmax=max(max_rank_val, NUM_COLORS_FOR_RANK) if max_rank_val >= min_rank_val else NUM_COLORS_FOR_RANK,
        mask=rank_df_cleaned.isnull()
    )
    plt.title(title_str, fontsize=TITLE_FONTSIZE)
    plt.xlabel("Dataset", fontsize=AXIS_LABEL_FONTSIZE)
    plt.ylabel("Model (Sorted by Params)", fontsize=AXIS_LABEL_FONTSIZE)
    plt.xticks(rotation=45, ha="right", fontsize=TICK_LABEL_FONTSIZE)
    plt.yticks(rotation=0, fontsize=TICK_LABEL_FONTSIZE)
    plt.tight_layout()
    save_path = os.path.join(save_dir, f"dataset_ranks_heatmap_{metric_name}.png")
    plt.savefig(save_path)
    print(f"Saved dataset rank heatmap to {save_path}")
    plt.close()


def plot_model_correlation_heatmap(metric_name, metric_df, save_dir):
    cleaned_metric_df = metric_df.dropna(how='all', axis=0).dropna(how='all', axis=1)
    if cleaned_metric_df.shape[0] < 2 or cleaned_metric_df.shape[1] < 2:
        print(f"Skipping model correlation for {metric_name} due to insufficient models/datasets after NA removal.")
        return

    model_corr = cleaned_metric_df.T.corr(method='spearman', min_periods=max(2, int(cleaned_metric_df.shape[1] * 0.5)))
    if model_corr.empty or model_corr.isnull().all().all():
        print(f"Skipping model correlation heatmap for {metric_name} as no correlation could be computed.")
        return
    
    model_corr_cleaned = model_corr.dropna(how='all', axis=0).dropna(how='all', axis=1)
    if model_corr_cleaned.empty or model_corr_cleaned.shape[0] < 2:
         print(f"Skipping model correlation heatmap for {metric_name} as correlation matrix is empty or too small after cleaning.")
         return

    plt.figure(figsize=(max(10, len(model_corr_cleaned.columns)*0.8), max(8, len(model_corr_cleaned.index)*0.6)))
    
    kdl_suffix = get_kdl_suffix(metric_name)
    title_str = f"Model Spearman Correlation for Metric: {metric_name.replace('_', ' ').title()}{kdl_suffix}"

    sns.heatmap(
        model_corr_cleaned, annot=True, fmt=".2f", cmap="coolwarm", linewidths=.5, linecolor='gray',
        cbar=True, annot_kws={"size": ANNOT_FONTSIZE}, vmin=-1, vmax=1,
        mask=model_corr_cleaned.isnull()
    )
    plt.title(title_str, fontsize=TITLE_FONTSIZE)
    plt.xlabel("Model (Sorted by Params)", fontsize=AXIS_LABEL_FONTSIZE)
    plt.ylabel("Model (Sorted by Params)", fontsize=AXIS_LABEL_FONTSIZE)
    plt.xticks(rotation=45, ha="right", fontsize=TICK_LABEL_FONTSIZE)
    plt.yticks(rotation=0, fontsize=TICK_LABEL_FONTSIZE)
    plt.tight_layout()
    save_path = os.path.join(save_dir, f"model_correlation_spearman_{metric_name}.png")
    plt.savefig(save_path)
    print(f"Saved model correlation heatmap to {save_path}")
    plt.close()

    csv_save_path = os.path.join(save_dir, f"model_correlation_spearman_{metric_name}.csv")
    try:
        model_corr_cleaned.to_csv(csv_save_path)
        print(f"Saved model correlation matrix to {csv_save_path}")
    except Exception as e:
        print(f"Could not save correlation matrix to CSV {csv_save_path}: {e}")

# 4. SAVING RAW METRICS TO JSON
# ------------------------------------------------------------------------------
def save_metrics_to_json(all_loaded_data, models_list, datasets_list, metrics_list, save_dir):
    output_data = {}
    for model_name in models_list:
        output_data[model_name] = {}
        for dataset_name in datasets_list:
            output_data[model_name][dataset_name] = {}
            for metric_name in metrics_list:
                if model_name in all_loaded_data[metric_name].index and \
                   dataset_name in all_loaded_data[metric_name].columns:
                    value = all_loaded_data[metric_name].loc[model_name, dataset_name]
                else:
                    value = pd.NA 
                
                if pd.isna(value):
                    output_data[model_name][dataset_name][metric_name] = None
                elif isinstance(value, np.generic):
                    output_data[model_name][dataset_name][metric_name] = value.item()
                else:
                    output_data[model_name][dataset_name][metric_name] = value
    
    file_path = os.path.join(save_dir, "result.json")
    try:
        with open(file_path, 'w') as f:
            json.dump(output_data, f, indent=4, allow_nan=False)
        print(f"Successfully saved all metrics to {file_path}")
    except Exception as e:
        print(f"Error saving metrics to JSON {file_path}: {e}")

# 5. MAIN EXECUTION
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    print("Loading metric data...")
    all_data = load_all_metric_data(DATASETS, MODELS, METRICS_OF_INTEREST, DATA_FILE_TEMPLATE)
    print("Data loading complete.")

    actual_models_in_data = list(all_data[METRICS_OF_INTEREST[0]].index) if all_data and METRICS_OF_INTEREST else MODELS
    actual_datasets_in_data = list(all_data[METRICS_OF_INTEREST[0]].columns) if all_data and METRICS_OF_INTEREST else DATASETS

    for metric, data_df in all_data.items():
        print(f"\nProcessing metric: {metric}")
        create_rank_heatmap(metric_name=metric, raw_metric_df=data_df.copy(), save_dir=SAVE_PIC_DIR)
        plot_model_correlation_heatmap(metric_name=metric, metric_df=data_df.copy(), save_dir=CORRELATION_PIC_DIR)
    
    print("\nAll heatmaps generated.")

    print("\nSaving all raw metrics to result.json...")
    save_metrics_to_json(
        all_loaded_data=all_data, 
        models_list=actual_models_in_data, 
        datasets_list=actual_datasets_in_data,
        metrics_list=METRICS_OF_INTEREST, 
        save_dir=SAVE_PIC_DIR
    )