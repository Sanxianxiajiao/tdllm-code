import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset, ConcatDataset
import torchaudio
import torchaudio.transforms as T
from torchaudio.datasets import SPEECHCOMMANDS
import os
import argparse
import json
import random
import numpy as np
from tqdm import tqdm
import math


import platform
if platform.system() == 'Windows':
    import pathlib
    temp = pathlib.PosixPath
    pathlib.PosixPath = pathlib.WindowsPath

# --- Model Definitions ---
# Simple M5 model inspired by torchaudio tutorial
# (Can be replaced or extended with other models)
class M5(nn.Module):
    def __init__(self, n_input=1, n_output=35, stride=16, n_channel=32):
        super().__init__()
        self.conv1 = nn.Conv1d(n_input, n_channel, kernel_size=80, stride=stride)
        self.bn1 = nn.BatchNorm1d(n_channel)
        self.pool1 = nn.MaxPool1d(4)
        self.conv2 = nn.Conv1d(n_channel, n_channel, kernel_size=3)
        self.bn2 = nn.BatchNorm1d(n_channel)
        self.pool2 = nn.MaxPool1d(4)
        self.conv3 = nn.Conv1d(n_channel, 2 * n_channel, kernel_size=3)
        self.bn3 = nn.BatchNorm1d(2 * n_channel)
        self.pool3 = nn.MaxPool1d(4)
        self.conv4 = nn.Conv1d(2 * n_channel, 2 * n_channel, kernel_size=3)
        self.bn4 = nn.BatchNorm1d(2 * n_channel)
        self.pool4 = nn.MaxPool1d(4)
        # The input size to the final FC layer depends on the final pooling layer's output size.
        # We calculate it dynamically or use adaptive pooling.
        # Using AdaptiveAvgPool1d simplifies this.
        self.avgpool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(2 * n_channel, n_output)

    def forward(self, x):
        # Input x shape: (batch, channel, time) -> (batch, 1, time) for raw waveform
        x = self.conv1(x)
        x = F.relu(self.bn1(x))
        x = self.pool1(x)
        x = self.conv2(x)
        x = F.relu(self.bn2(x))
        x = self.pool2(x)
        x = self.conv3(x)
        x = F.relu(self.bn3(x))
        x = self.pool3(x)
        x = self.conv4(x)
        x = F.relu(self.bn4(x))
        # x = self.pool4(x) # Removing last pool to keep AdaptiveAvgPool flexible
        x = self.avgpool(x) # (batch, 2*n_channel, 1)
        x = x.permute(0, 2, 1) # (batch, 1, 2*n_channel)
        x = self.fc1(x)     # (batch, 1, n_output)
        # Return shape (batch, n_output) for CrossEntropyLoss
        return F.log_softmax(x.squeeze(1), dim=-1)

# Add more model definitions here if needed
# Example: A simple CNN for Spectrograms
class SimpleSpecCNN(nn.Module):
    def __init__(self, n_input_mels, n_output=35):
        super().__init__()
        # Input shape: (batch, 1, n_mels, time)
        self.conv1 = nn.Conv2d(1, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        self.bn1 = nn.BatchNorm2d(32)
        self.pool1 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2)) # Reduce n_mels and time
        self.conv2 = nn.Conv2d(32, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        self.bn2 = nn.BatchNorm2d(64)
        self.pool2 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
        self.conv3 = nn.Conv2d(64, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        self.bn3 = nn.BatchNorm2d(128)
        self.pool3 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))

        # Use AdaptiveMaxPool2d to handle variable time dimension after convolutions/pooling
        self.adaptive_pool = nn.AdaptiveMaxPool2d((1, 1)) # Output size (1, 1)
        self.flatten = nn.Flatten()
        # The number of features is now fixed at 128 * 1 * 1
        self.fc1 = nn.Linear(128, n_output)

    def forward(self, x):
        # x shape: (batch, 1, n_mels, time)
        x = self.pool1(F.relu(self.bn1(self.conv1(x))))
        x = self.pool2(F.relu(self.bn2(self.conv2(x))))
        x = self.pool3(F.relu(self.bn3(self.conv3(x))))
        x = self.adaptive_pool(x) # (batch, 128, 1, 1)
        x = self.flatten(x)      # (batch, 128)
        x = self.fc1(x)          # (batch, n_output)
        return F.log_softmax(x, dim=1)


# --- Utility Functions ---
def set_seed(seed):
    """Sets random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    # Ensure deterministic behavior for certain operations
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def label_to_index(word, labels):
    return torch.tensor(labels.index(word))

def index_to_label(index, labels):
    return labels[index]

# --- Data Handling ---
class SubsetSPEECHCOMMANDS(SPEECHCOMMANDS):
    def __init__(self, subset: str = None, *args, **kwargs):
        super().__init__(*args, **kwargs)

        def load_list(filename):
            filepath = os.path.join(self._path, filename)
            with open(filepath) as fileobj:
                # 转换为绝对路径并规范化路径格式
                return [os.path.abspath(os.path.normpath(os.path.join(self._path, line.strip()))) 
                       for line in fileobj 
                       if os.path.exists(os.path.abspath(os.path.join(self._path, line.strip())))]

        if subset == "validation":
            self._walker = load_list("validation_list.txt")
        elif subset == "testing":
            self._walker = load_list("testing_list.txt")
        elif subset == "training":
            excludes = set(load_list("validation_list.txt") + load_list("testing_list.txt"))
            self._walker = [w for w in self._walker if w not in excludes]
        elif subset is None:
             # Load all files if subset is None, but usually we want a specific split
             pass # Keep self._walker as is (all files)
        else:
            raise ValueError(f"Subset '{subset}' not recognized. Choose 'validation', 'testing', or 'training'.")


def get_speech_commands_datasets(data_path, use_spec_transform=False):
    """Loads the Google Speech Commands dataset splits."""
    train_set_full = SubsetSPEECHCOMMANDS(subset="training", root=data_path, download=True)
    valid_set = SubsetSPEECHCOMMANDS(subset="validation", root=data_path, download=True) # Although not used for final test, good to have
    test_set = SubsetSPEECHCOMMANDS(subset="testing", root=data_path, download=True)

    # Find all unique labels
    all_labels = sorted(list(set(data[2] for data in train_set_full))) # data format: (waveform, sample_rate, label, speaker_id, utterance_number)

    # Define transforms
    sample_rate = 16000 # Google Speech Commands is 16kHz
    if use_spec_transform:
        # --- Spectrogram Transform ---
        n_fft = 400 # Frame size
        hop_length = 160 # Stride between frames
        n_mels = 64 # Number of Mel filters
        transform = T.MelSpectrogram(
            sample_rate=sample_rate,
            n_fft=n_fft,
            hop_length=hop_length,
            n_mels=n_mels,
            power=2.0 # Power spectrogram
        )
    else:
        # --- Raw Waveform Transform (example: just ensure fixed length) ---
        # Models like M5 might work directly on waveforms.
        # We might need padding/truncation here or in collate_fn if model requires fixed length raw audio.
        # For simplicity, we'll handle padding/truncation in collate_fn for waveforms too.
        transform = None # Will handle in collate function

    return train_set_full, valid_set, test_set, all_labels, transform, sample_rate

def create_subset(full_dataset, num_samples):
    """Creates a subset of the dataset."""
    num_total_samples = len(full_dataset)

    if num_samples > 0 and num_samples <= 1:
        actual_num_samples = int(num_total_samples * num_samples)
        print(f"Using {num_samples*100:.1f}% of training data: {actual_num_samples} samples.")
    elif num_samples > 1:
        actual_num_samples = int(num_samples)
        if actual_num_samples > num_total_samples:
            print(f"Warning: Requested {actual_num_samples} samples, but only {num_total_samples} available. Using all {num_total_samples} samples.")
            actual_num_samples = num_total_samples
        else:
             print(f"Using {actual_num_samples} training samples.")
    else:
        raise ValueError("num_train_samples must be > 0")

    # Ensure reproducibility when subsetting
    # Generate random indices based on the fixed seed
    indices = torch.randperm(num_total_samples).tolist()
    subset_indices = indices[:actual_num_samples]

    subset_dataset = Subset(full_dataset, subset_indices)
    return subset_dataset, actual_num_samples

# --- Utility Classes ---
class CollateFunction:
    def __init__(self, transform, labels, sample_rate, use_spec_transform, target_waveform_len=16000):
        self.transform = transform
        self.labels = labels
        self.sample_rate = sample_rate
        self.use_spec_transform = use_spec_transform
        self.target_waveform_len = target_waveform_len
        self.labels_map = {label: i for i, label in enumerate(labels)}

    def __call__(self, batch):
        waveforms = []
        processed_labels = []

        for (waveform, sr, label, _, _) in batch:
            # 1. 统一采样率
            if sr != self.sample_rate:
                resampler = T.Resample(sr, self.sample_rate)
                waveform = resampler(waveform)
            
            # 2. 统一波形长度（关键修复点）
            if self.target_waveform_len:
                current_length = waveform.size(1)
                if current_length > self.target_waveform_len:
                    # 截断
                    waveform = waveform[:, :self.target_waveform_len]
                elif current_length < self.target_waveform_len:
                    # 填充右侧
                    padding = self.target_waveform_len - current_length
                    waveform = F.pad(waveform, (0, padding))
            
            # 3. 应用频谱变换
            if self.use_spec_transform and self.transform:
                mel_spec = self.transform(waveform)  # (1, n_mels, time)
                waveforms.append(mel_spec.squeeze(0))  # (n_mels, time)
            else:
                waveforms.append(waveform.squeeze(0))  # (time,)
            
            processed_labels.append(torch.tensor(self.labels.index(label)))

        if self.use_spec_transform:
            padded_waveforms = torch.nn.utils.rnn.pad_sequence(
                waveforms, batch_first=True, padding_value=0.0
            ).unsqueeze(1)
        else:
            padded_waveforms = torch.nn.utils.rnn.pad_sequence(
                waveforms, batch_first=True, padding_value=0.0
            ).unsqueeze(1)

        labels_tensor = torch.stack(processed_labels)
        return padded_waveforms, labels_tensor

# --- 修改DataLoader创建方式 ---
def collate_fn_factory(transform, labels, sample_rate, use_spec_transform, target_waveform_len=16000):
    return CollateFunction(
        transform=transform,
        labels=labels,
        sample_rate=sample_rate,
        use_spec_transform=use_spec_transform,
        target_waveform_len=target_waveform_len
    )

# --- Model Loading ---
def get_model(model_name, num_classes, n_mels=None):
    """Instantiates the model based on name."""
    if model_name == 'm5':
        print("Using M5 model (expects raw waveform)")
        return M5(n_output=num_classes)
    elif model_name == 'spec_cnn':
        if n_mels is None:
            raise ValueError("n_mels must be provided for spec_cnn model")
        print(f"Using SimpleSpecCNN model (expects Mel Spectrogram with {n_mels} mels)")
        return SimpleSpecCNN(n_input_mels=n_mels, n_output=num_classes)
    # Add more models here
    # elif model_name == 'resnet18_1d':
    #     from torchvision.models import resnet18 # Adapt for 1D? Or use a dedicated 1D ResNet lib
    #     print("Using ResNet18 (1D adaptation - placeholder)")
    #     # Requires adaptation for 1D input and correct number of classes
    #     model = resnet18(pretrained=False)
    #     # Example: Modify first conv layer for 1 channel input
    #     model.conv1 = nn.Conv2d(1, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False) # Need to adapt this for 1D audio (Conv1d) or spectrogram (Conv2d)
    #     # Example: Modify final layer for num_classes
    #     num_ftrs = model.fc.in_features
    #     model.fc = nn.Linear(num_ftrs, num_classes)
    #     return model # NOTE: This is a placeholder, requires proper adaptation!
    else:
        raise ValueError(f"Model '{model_name}' not recognized.")


# --- Training & Evaluation ---
def train_one_epoch(model, train_loader, optimizer, criterion, device, epoch, total_epochs):
    """Runs a single training epoch."""
    model.train()
    total_loss = 0.0
    correct = 0
    total = 0
    
    progress_bar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{total_epochs} [Train]", leave=False)
    for batch_idx, (data, target) in enumerate(progress_bar):
        data, target = data.to(device), target.to(device)

        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        pred = output.argmax(dim=-1, keepdim=True) # get the index of the max log-probability
        correct += pred.eq(target.view_as(pred)).sum().item()
        total += target.size(0)

        progress_bar.set_postfix(loss=f"{loss.item():.4f}", acc=f"{100.*correct/total:.2f}%")

    avg_loss = total_loss / len(train_loader)
    accuracy = 100. * correct / total
    return avg_loss, accuracy

def evaluate(model, test_loader, criterion, device, epoch, total_epochs):
    """Evaluates the model on the test set."""
    model.eval()
    test_loss = 0.0
    correct = 0
    total = 0

    progress_bar = tqdm(test_loader, desc=f"Epoch {epoch+1}/{total_epochs} [Test ]", leave=False)
    with torch.no_grad():
        for data, target in progress_bar:
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss = criterion(output, target).item() # sum up batch loss
            test_loss += loss
            pred = output.argmax(dim=-1, keepdim=True) # get the index of the max log-probability
            correct += pred.eq(target.view_as(pred)).sum().item()
            total += target.size(0)
            progress_bar.set_postfix(loss=f"{loss:.4f}", acc=f"{100.*correct/total:.2f}%")


    avg_loss = test_loss / len(test_loader)
    accuracy = 100. * correct / total
    print(f"\nEpoch {epoch+1}/{total_epochs} Test Set: Average loss: {avg_loss:.4f}, Accuracy: {correct}/{total} ({accuracy:.2f}%)")
    return avg_loss, accuracy


# --- Main Execution ---
def main(args):
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # --- Data Loading ---
    dataset_name = "GoogleSpeechCommandsV2" # Or derive from dataset object if possible
    use_spec_transform = args.model_name in ['spec_cnn'] # Add other spec models here
    
    # Determine n_mels if using spectrogram transform (could be moved to args)
    n_mels = 64 if use_spec_transform else None 

    train_set_full, _, test_set, labels, transform, sample_rate = get_speech_commands_datasets(
        args.data_dir, use_spec_transform=use_spec_transform
    )
    num_classes = len(labels)
    print(f"Found {num_classes} classes: {labels}")

    # --- Data Subsetting ---
    train_set, actual_num_train_samples = create_subset(train_set_full, args.num_train_samples)

    # --- Create DataLoaders ---
    collate_fn = collate_fn_factory(transform, labels, sample_rate, use_spec_transform)

    train_loader = DataLoader(
        train_set,
        batch_size=args.batch_size,
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=args.num_workers,
        pin_memory=True if device == 'cuda' else False
    )
    test_loader = DataLoader(
        test_set,
        batch_size=args.batch_size,
        shuffle=False, # No need to shuffle test set
        collate_fn=collate_fn,
        num_workers=args.num_workers,
        pin_memory=True if device == 'cuda' else False
    )

    # --- Model Initialization ---
    model = get_model(args.model_name, num_classes, n_mels=n_mels).to(device)
    print(f"Model: {args.model_name}")
    print(f"Number of parameters: {count_parameters(model):,}")
    print(f"Using Spectrogram Transform: {use_spec_transform}")


    # --- Optimizer and Loss ---
    optimizer = optim.AdamW(model.parameters(), lr=args.lr)
    criterion = nn.CrossEntropyLoss() # Use CrossEntropyLoss for multi-class classification with log_softmax output
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=args.lr_scheduler_step, gamma=args.lr_scheduler_gamma) # Optional LR scheduler

    # --- Result Saving Setup ---
    result_dir = os.path.join("./results", dataset_name, args.model_name, str(actual_num_train_samples))
    os.makedirs(result_dir, exist_ok=True)
    result_file = os.path.join(result_dir, "result.json")
    best_model_file = os.path.join(result_dir, "best_model.pth")

    epoch_results = []
    best_test_accuracy = 0.0

    # --- Training Loop ---
    print("\n--- Starting Training ---")
    for epoch in range(args.epochs):
        train_loss, train_acc = train_one_epoch(model, train_loader, optimizer, criterion, device, epoch, args.epochs)
        test_loss, test_acc = evaluate(model, test_loader, criterion, device, epoch, args.epochs)
        scheduler.step() # Update learning rate

        # Store results
        epoch_data = {
            'epoch': epoch + 1,
            'train_loss': train_loss,
            'train_accuracy': train_acc,
            'test_loss': test_loss,
            'test_accuracy': test_acc,
            'learning_rate': scheduler.get_last_lr()[0]
        }
        epoch_results.append(epoch_data)

        # Save best model based on test accuracy
        if test_acc > best_test_accuracy:
            print(f"*** New best accuracy ({test_acc:.2f}%) achieved.")
            best_test_accuracy = test_acc
            # torch.save(model.state_dict(), best_model_file)
            # Optionally save the best result summary separately
            with open(os.path.join(result_dir, "best_result_summary.json"), 'w') as f:
                 json.dump(epoch_data, f, indent=4)


        # Save results incrementally per epoch (optional, good for long runs)
        with open(result_file, 'w') as f:
            json.dump(epoch_results, f, indent=4)


    print("\n--- Training Finished ---")
    print(f"Results saved in: {result_dir}")
    print(f"Best Test Accuracy achieved: {best_test_accuracy:.2f}%")

    # Final save of all epoch results (redundant if saved incrementally, but safe)
    with open(result_file, 'w') as f:
        json.dump(epoch_results, f, indent=4)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='PyTorch Google Speech Commands Training')

    # Model and Data Arguments
    parser.add_argument('--model_name', type=str, default='m5',
                        help='Model to use (e.g., m5, spec_cnn)')
    parser.add_argument('--data_dir', type=str, default='./data',
                        help='Directory to download/load Google Speech Commands dataset')
    parser.add_argument('--num_train_samples', type=float, default=1.0,
                        help='Number or fraction of training samples to use (e.g., 0.1 for 10%, 1000 for 1000 samples)')

    # Training Hyperparameters
    parser.add_argument('--epochs', type=int, default=20, metavar='N',
                        help='number of epochs to train (default: 20)')
    parser.add_argument('--batch_size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                        help='learning rate (default: 0.001)')
    parser.add_argument('--lr_scheduler_step', type=int, default=10,
                        help='StepLR scheduler step size (default: 10 epochs)')
    parser.add_argument('--lr_scheduler_gamma', type=float, default=0.1,
                        help='StepLR scheduler gamma (default: 0.1)')


    # System Arguments
    parser.add_argument('--seed', type=int, default=42, metavar='S',
                        help='random seed (default: 42)')
    parser.add_argument('--num_workers', type=int, default=2,
                        help='number of dataloader workers (default: 2)')


    args = parser.parse_args()
    main(args)

# --- Example Command Line Usage ---
# 1. Train M5 model on 10% of training data for 15 epochs:
#    python your_script_name.py --model_name m5 --num_train_samples 0.1 --epochs 15 --batch_size 128 --lr 0.0005
#
# 2. Train SimpleSpecCNN model on exactly 5000 training samples for 30 epochs:
#    python your_script_name.py --model_name spec_cnn --num_train_samples 5000 --epochs 30 --batch_size 64
#
# 3. Train M5 model on all training data with a different seed:
#    python your_script_name.py --model_name m5 --num_train_samples 1.0 --seed 123