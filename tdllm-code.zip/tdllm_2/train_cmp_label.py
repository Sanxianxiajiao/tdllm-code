# Keep all previous imports
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset, Dataset # Added Dataset import
import torchvision.models as models

import os
import argparse
import json
import random
import numpy as np
import time
from tqdm import tqdm

# --- Model Definitions --- (Keep SimpleCNN and SimpleMLP as they are)
# Modified to accept input channels and image size for flexibility
class SimpleCNN(nn.Module):
    def __init__(self, input_channels=3, image_size=32, num_classes=10):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(input_channels, 16, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1)
        # Calculate flattened size dynamically
        # After two pools (stride 2), size becomes image_size / 4
        feature_size = image_size // 4
        if feature_size <= 0:
             raise ValueError(f"Image size {image_size} too small for 2 pooling layers")
        self.fc1_input_features = 32 * feature_size * feature_size
        self.fc1 = nn.Linear(self.fc1_input_features, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, self.fc1_input_features) # Flatten the tensor
        x = F.relu(self.fc1(x))
        x = self.fc2(x) # Output logits
        return x

# Modified to accept input channels and image size
class SimpleMLP(nn.Module):
    def __init__(self, input_channels=3, image_size=32, num_classes=10):
        super(SimpleMLP, self).__init__()
        # Calculate input size dynamically
        input_size_flat = input_channels * image_size * image_size
        self.fc1 = nn.Linear(input_size_flat, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_classes)
        self.flatten = nn.Flatten()

    def forward(self, x):
        x = self.flatten(x)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x) # Output logits
        return x

# --- Helper Functions ---
def set_seed(seed):
    """Sets random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

# Modified get_model to accept dataset characteristics
def get_model(model_name, num_classes=10, input_channels=3, image_size=32):
    """Loads the specified model, adapting for dataset specifics."""
    if model_name == 'resnet18':
        model = models.resnet18(weights=None) # No pretrained weights
        # Modify input layer if needed (e.g., for grayscale)
        if input_channels == 1:
            # Keep original weights, but sum them for the single channel
            original_weights = model.conv1.weight.data
            model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
            model.conv1.weight.data = original_weights.sum(dim=1, keepdim=True) # Sum R,G,B weights
        # Modify final layer for num_classes
        num_ftrs = model.fc.in_features
        model.fc = nn.Linear(num_ftrs, num_classes)
    elif model_name == 'resnet50':
        model = models.resnet50(weights=None) # No pretrained weights
        if input_channels == 1:
            original_weights = model.conv1.weight.data
            model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
            model.conv1.weight.data = original_weights.sum(dim=1, keepdim=True)
        num_ftrs = model.fc.in_features
        model.fc = nn.Linear(num_ftrs, num_classes)
    elif model_name == 'simple_cnn':
        model = SimpleCNN(input_channels=input_channels, image_size=image_size, num_classes=num_classes)
    elif model_name == 'mlp':
        model = SimpleMLP(input_channels=input_channels, image_size=image_size, num_classes=num_classes)
    else:
        raise ValueError(f"Unknown model name: {model_name}")
    return model

# NEW function to get datasets and their properties
def get_datasets(dataset_name, data_root='./data'):
    """Loads the specified dataset and returns datasets, transforms, and properties."""
    print(f"Loading {dataset_name} dataset...")
    if dataset_name == 'cifar10':
        num_classes = 10
        input_channels = 3
        image_size = 32
        # CIFAR-10 specific transforms
        normalize = transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize,
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
        train_dataset_full = torchvision.datasets.CIFAR10(
            root=data_root, train=True, download=True, transform=transform_train)
        test_dataset = torchvision.datasets.CIFAR10(
            root=data_root, train=False, download=True, transform=transform_test)

    elif dataset_name == 'mnist':
        num_classes = 10
        input_channels = 1
        image_size = 28
        normalize = transforms.Normalize((0.1307,), (0.3081,))
        transform_common = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
        train_dataset_full = torchvision.datasets.MNIST(
            root=data_root, train=True, download=True, transform=transform_common)
        test_dataset = torchvision.datasets.MNIST(
            root=data_root, train=False, download=True, transform=transform_common)

    elif dataset_name == 'fashionmnist':
        num_classes = 10
        input_channels = 1
        image_size = 28
        normalize = transforms.Normalize((0.5,), (0.5,)) # Simpler normalization
        transform_train = transforms.Compose([
             transforms.RandomHorizontalFlip(),
             transforms.ToTensor(),
             normalize,
        ])
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
        train_dataset_full = torchvision.datasets.FashionMNIST(
            root=data_root, train=True, download=True, transform=transform_train)
        test_dataset = torchvision.datasets.FashionMNIST(
            root=data_root, train=False, download=True, transform=transform_test)

    elif dataset_name == 'svhn':
        num_classes = 10
        input_channels = 3
        image_size = 32
        normalize = transforms.Normalize((0.4377, 0.4438, 0.4728), (0.1980, 0.2010, 0.1970)) # Approx SVHN stats
        transform_common = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
        train_dataset_full = torchvision.datasets.SVHN(
            root=data_root, split='train', download=True, transform=transform_common)
        # SVHN needs target_transform for labels 0-9 (they are 1-10 by default)
        train_dataset_full.labels = (train_dataset_full.labels % 10) # Map 10 to 0
        test_dataset = torchvision.datasets.SVHN(
            root=data_root, split='test', download=True, transform=transform_common)
        test_dataset.labels = (test_dataset.labels % 10) # Map 10 to 0

    else:
        raise ValueError(f"Unknown dataset name: {dataset_name}")

    # Try to access targets/labels for filtering later
    if hasattr(train_dataset_full, 'targets'): # MNIST, FashionMNIST, CIFAR10
        train_targets = train_dataset_full.targets
    elif hasattr(train_dataset_full, 'labels'): # SVHN
        train_targets = train_dataset_full.labels
    else:
        # Fallback for datasets that don't have direct access (might be slow)
        print("Warning: Accessing training targets via iteration, might be slow.")
        train_targets = [label for _, label in train_dataset_full]
    train_dataset_full._targets_list = list(train_targets) # Store for easier access

    if hasattr(test_dataset, 'targets'):
        test_targets = test_dataset.targets
    elif hasattr(test_dataset, 'labels'):
        test_targets = test_dataset.labels
    else:
        print("Warning: Accessing test targets via iteration, might be slow.")
        test_targets = [label for _, label in test_dataset]
    test_dataset._targets_list = list(test_targets) # Store for easier access

    return train_dataset_full, test_dataset, num_classes, input_channels, image_size

# --- NEW: Custom Dataset Wrapper for Label Remapping ---
class ClassSubsetWrapper(Dataset):
    """
    Wraps a Subset to remap class labels to be consecutive from 0.
    """
    def __init__(self, subset, original_classes):
        self.subset = subset
        # Create a mapping from original class index to new consecutive index
        self.class_map = {original_class: new_class for new_class, original_class in enumerate(sorted(original_classes))}
        self.original_classes = sorted(original_classes)
        print(f"Label mapping created: {self.class_map}")

    def __getitem__(self, index):
        # Get data and original target from the underlying subset
        data, original_target = self.subset[index]
        # Remap the target label
        new_target = self.class_map[original_target]
        return data, new_target

    def __len__(self):
        return len(self.subset)

# --- MODIFIED Training and Testing Functions ---

# MODIFIED: Added loss_type and num_classes args
def train(model, device, train_loader, optimizer, criterion, epoch, loss_type, num_classes):
    """Training loop for one epoch with tqdm progress bar."""
    model.train()
    train_loss = 0
    correct = 0
    total = 0
    start_time = time.time()
    pbar = tqdm(enumerate(train_loader), total=len(train_loader), desc=f"Epoch {epoch} Training", leave=False)
    for batch_idx, (data, target) in pbar:
        # print(target)
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data) # Logits

        # --- Loss Calculation based on loss_type ---
        if loss_type == 'cross_entropy':
            loss = criterion(output, target) # CE expects logits and class indices (0 to num_classes-1)
        elif loss_type == 'mse':
            probabilities = F.softmax(output, dim=1)
            # Ensure target is compatible with one_hot (needs to be LongTensor)
            target_one_hot = F.one_hot(target.long(), num_classes=num_classes).float().to(device)
            loss = criterion(probabilities, target_one_hot) # MSE expects same shape inputs
        elif loss_type == 'hinge':
            # MultiMarginLoss expects logits and class indices (0 to num_classes-1)
            loss = criterion(output, target)
        else:
             raise ValueError(f"Unsupported loss type in train loop: {loss_type}")
        # --- End Loss Calculation ---

        loss.backward()
        optimizer.step()
        train_loss += loss.item() # Accumulate batch loss

        # --- Accuracy Calculation (Always based on logits) ---
        _, predicted = output.max(1) # Get predicted class from logits
        total += target.size(0)
        correct += predicted.eq(target).sum().item()
        # --- End Accuracy Calculation ---

        # Report avg loss per item in batch for postfix
        batch_avg_loss = loss.item() / data.size(0) if data.size(0) > 0 else loss.item()
        pbar.set_postfix(loss=f'{batch_avg_loss:.4f}', acc=f'{100.*correct/total:.2f}%')

    avg_loss = train_loss / len(train_loader.dataset) # Average loss per sample for the epoch
    accuracy = 100. * correct / total
    end_time = time.time()
    return avg_loss, accuracy


# MODIFIED: Added loss_type and num_classes args
def test(model, device, test_loader, criterion, loss_type, num_classes):
    """Evaluation loop with tqdm progress bar."""
    model.eval()
    test_loss = 0
    correct = 0
    total = 0
    start_time = time.time()
    pbar = tqdm(test_loader, desc="Testing", leave=False)
    with torch.no_grad():
        for data, target in pbar:
            data, target = data.to(device), target.to(device)
            output = model(data) # Logits

            # --- Loss Calculation based on loss_type ---
            if loss_type == 'cross_entropy':
                batch_loss = criterion(output, target).item() # item() gives avg loss for the batch
            elif loss_type == 'mse':
                probabilities = F.softmax(output, dim=1)
                target_one_hot = F.one_hot(target.long(), num_classes=num_classes).float().to(device)
                batch_loss = criterion(probabilities, target_one_hot).item()
            elif loss_type == 'hinge':
                batch_loss = criterion(output, target).item()
            else:
                raise ValueError(f"Unsupported loss type in test loop: {loss_type}")
            # --- End Loss Calculation ---

            test_loss += batch_loss * data.size(0) # Accumulate total loss correctly (batch_loss is often pre-averaged)

            # --- Accuracy Calculation (Always based on logits) ---
            _, predicted = output.max(1) # Get predicted class from logits
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
            # --- End Accuracy Calculation ---

            # Report avg loss per item in batch for postfix
            batch_avg_loss = batch_loss # Assumes criterion returns average loss for the batch
            pbar.set_postfix(loss=f'{batch_avg_loss:.4f}', acc=f'{100.*correct/total:.2f}%')

    avg_loss = test_loss / total # Calculate average loss per sample over the entire test set
    accuracy = 100. * correct / total
    end_time = time.time()
    return avg_loss, accuracy

# --- Main Execution ---

def main():
    # --- Argument Parsing ---
    parser = argparse.ArgumentParser(description='PyTorch Image Classification Training')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['cifar10', 'mnist', 'fashionmnist', 'svhn'],
                        help='Dataset to use')
    parser.add_argument('--model', type=str, required=True,
                        choices=['resnet18', 'resnet50', 'simple_cnn', 'mlp'],
                        help='Model architecture to use')
    parser.add_argument('--loss', type=str, default='cross_entropy',
                        choices=['cross_entropy', 'mse', 'hinge'],
                        help='Loss function to use (default: cross_entropy)')
    parser.add_argument('--num_train_samples', type=float, default=1.0,
                        help='Number or fraction of training samples relative to available data (after class filtering if any) (e.g., 0.1 for 10%, 5000 for 5000 samples)')
    # NEW: Argument to specify which classes to include
    parser.add_argument('--include_classes', type=int, nargs='+', default=None,
                        help='List of original class indices to include (e.g., 0 1 5). If None, use all classes.')
    parser.add_argument('--epochs', type=int, default=20, metavar='N',
                        help='number of epochs to train (default: 20)')
    parser.add_argument('--batch_size', type=int, default=128, metavar='N',
                        help='input batch size for training (default: 128)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                        help='learning rate (default: 0.001)')
    parser.add_argument('--seed', type=int, default=42, metavar='S',
                        help='random seed (default: 42)')
    parser.add_argument('--no_cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--results_dir', type=str, default='./results_combined', # Generic results dir
                        help='Base directory to save results')
    parser.add_argument('--data_root', type=str, default='./data',
                        help='Directory where datasets are stored/downloaded')
    args = parser.parse_args()

    # --- Setup ---
    set_seed(args.seed)
    use_cuda = not args.no_cuda and torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    print(f"Using device: {device}")
    print(f"Selected Dataset: {args.dataset}")
    print(f"Selected Model: {args.model}")
    print(f"Selected Loss Function: {args.loss}")

    # --- Data Loading and Preprocessing (using get_datasets) ---
    train_dataset_full, test_dataset_full, original_num_classes, input_channels, image_size = get_datasets(
        args.dataset, data_root=args.data_root
    )

    # --- Filter Datasets by Class ---
    num_classes = original_num_classes # Start with original number
    actual_train_dataset = train_dataset_full # Default to full dataset
    actual_test_dataset = test_dataset_full  # Default to full dataset
    included_classes = list(range(original_num_classes)) # Default to all classes

    if args.include_classes:
        # Validate class indices
        if not all(0 <= c < original_num_classes for c in args.include_classes):
             raise ValueError(f"Invalid class indices in --include_classes. Must be between 0 and {original_num_classes-1} for {args.dataset}.")
        if len(args.include_classes) < 2:
            raise ValueError("Need at least two classes to perform classification.")

        included_classes = sorted(list(set(args.include_classes))) # Ensure unique and sorted
        num_classes = len(included_classes)
        print(f"Filtering dataset for {num_classes} classes: {included_classes}...")

        # --- Filter Training Set ---
        train_targets_np = np.array(train_dataset_full._targets_list)
        train_indices = [i for i, target in enumerate(train_targets_np) if target in included_classes]
        if not train_indices:
             print(f"Warning: No training samples found for the specified classes: {included_classes}")
        train_subset_filtered = Subset(train_dataset_full, train_indices)
        actual_train_dataset = ClassSubsetWrapper(train_subset_filtered, included_classes) # Wrap for label remapping

        # --- Filter Test Set ---
        test_targets_np = np.array(test_dataset_full._targets_list)
        test_indices = [i for i, target in enumerate(test_targets_np) if target in included_classes]
        if not test_indices:
             print(f"Warning: No test samples found for the specified classes: {included_classes}")
        test_subset_filtered = Subset(test_dataset_full, test_indices)
        actual_test_dataset = ClassSubsetWrapper(test_subset_filtered, included_classes) # Wrap for label remapping

        print(f"Filtered training set size: {len(actual_train_dataset)}")
        print(f"Filtered test set size: {len(actual_test_dataset)}")
        print(f"Number of classes to train on updated to: {num_classes}")
    else:
         print(f"Using all {original_num_classes} classes.")
         # Datasets remain as train_dataset_full, test_dataset_full
         # num_classes remains original_num_classes

    # --- Handle Subset of Training Data (Fraction/Number) based on AVAILABLE data ---
    num_train_samples_available = len(actual_train_dataset)
    num_samples_input = args.num_train_samples

    if num_train_samples_available == 0 and num_samples_input > 0:
         print("Warning: No training samples available after filtering, cannot select a subset.")
         num_actual_train_samples = 0
    elif num_samples_input > 0 and num_samples_input <= 1:
        # Interpret as fraction
        num_actual_train_samples = int(num_train_samples_available * num_samples_input)
        print(f"Using {num_samples_input * 100:.1f}% of available training data: {num_actual_train_samples} samples.")
    elif num_samples_input > 1:
        # Interpret as absolute number
        num_actual_train_samples = int(num_samples_input)
        if num_actual_train_samples > num_train_samples_available:
            print(f"Warning: Requested {num_actual_train_samples} samples, but only {num_train_samples_available} available after class filtering. Using all {num_train_samples_available} samples.")
            num_actual_train_samples = num_train_samples_available
        else:
             print(f"Using {num_actual_train_samples} training samples.")
    else:
        raise ValueError("--num_train_samples must be > 0")

    num_samples_str = str(num_actual_train_samples) # For path naming

    # Create the final training dataset (potentially subset of class-filtered set)
    if num_train_samples_available > 0 and num_actual_train_samples < num_train_samples_available:
        g = torch.Generator()
        g.manual_seed(args.seed)
        # Generate indices relative to the current actual_train_dataset
        indices = torch.randperm(num_train_samples_available, generator=g)[:num_actual_train_samples].tolist()
        final_train_dataset = Subset(actual_train_dataset, indices) # Create subset from (potentially wrapped) dataset
        print(f"Applied subset sampling: final training dataset size {len(final_train_dataset)}")
    elif num_train_samples_available > 0:
        final_train_dataset = actual_train_dataset # Use the full (potentially wrapped) dataset
        print(f"Using all available {len(final_train_dataset)} training samples.")
    else:
        final_train_dataset = actual_train_dataset # Will be empty dataset

    # --- Data Loaders ---
    if len(final_train_dataset) == 0:
        print("Warning: Final training dataset size is 0. Skipping training.")
        train_loader = None
        # Ensure effective_batch_size is not 0 if test_loader is still needed
        effective_batch_size = args.batch_size if len(actual_test_dataset) > 0 else 1
    else:
        effective_batch_size = min(args.batch_size, len(final_train_dataset))
        if effective_batch_size < args.batch_size :
            print(f"Warning: Reducing training batch size from {args.batch_size} to {effective_batch_size} due to small dataset size.")
        train_loader = DataLoader(final_train_dataset, batch_size=effective_batch_size, shuffle=True, num_workers=2, pin_memory=use_cuda, drop_last=(len(final_train_dataset)>effective_batch_size)) # drop_last if possible

    # Test loader always uses the filtered test set (actual_test_dataset)
    if len(actual_test_dataset) == 0:
        print("Warning: Test dataset size is 0. Skipping testing.")
        test_loader = None
    else:
        test_batch_size = min(args.batch_size * 2, len(actual_test_dataset)) # Avoid batch size > dataset size
        test_loader = DataLoader(actual_test_dataset, batch_size=test_batch_size, shuffle=False, num_workers=2, pin_memory=use_cuda)

    # --- Model ---
    # IMPORTANT: Pass the potentially updated num_classes
    model = get_model(args.model, num_classes=num_classes, input_channels=input_channels, image_size=image_size).to(device)
    print(f"Instantiated model: {args.model} for {args.dataset} with {num_classes} output classes")

    # --- Criterion (Loss Function) ---
    if args.loss == 'cross_entropy':
        criterion = nn.CrossEntropyLoss()
    elif args.loss == 'mse':
        criterion = nn.MSELoss()
    elif args.loss == 'hinge':
        # Use MultiMarginLoss for standard multi-class hinge
        criterion = nn.MultiMarginLoss()
    else:
        raise ValueError(f"Unknown loss function specified: {args.loss}")
    print(f"Using criterion: {type(criterion).__name__}")

    # --- Optimizer ---
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    # --- Result Saving Setup ---
    # Include class info in the path if specific classes were selected
    class_subset_str = f"classes_{'_'.join(map(str, included_classes))}" if args.include_classes else "all_classes"
    # Path: results_base / dataset / model / loss / class_subset / num_samples
    result_dir = os.path.join(args.results_dir, args.dataset, args.model, f"loss_{args.loss}", class_subset_str, num_samples_str)
    os.makedirs(result_dir, exist_ok=True)
    result_file = os.path.join(result_dir, 'result.json')
    print(f"Results will be saved to: {result_file}")

    results_data = {
        'args': vars(args),
        'dataset_properties': {
            'original_num_classes': original_num_classes,
            'used_num_classes': num_classes, # Actual number used
            'included_original_classes': included_classes, # List of original indices used
            'input_channels': input_channels,
            'image_size': image_size,
            'full_train_size_original': len(train_dataset_full),
            'full_train_size_filtered': len(actual_train_dataset), # Size after class filter
            'test_size_filtered': len(actual_test_dataset),      # Size after class filter
            'actual_train_samples_used': len(final_train_dataset) # Size after class filter AND num_samples limit
        },
        'best_test_accuracy': 0.0,
        'epoch_results': []
    }

    # --- Training and Evaluation Loop ---
    start_train_time = time.time()
    epoch_pbar = tqdm(range(1, args.epochs + 1), desc="Total Epochs")
    best_test_acc = 0.0

    for epoch in epoch_pbar:
        train_loss, train_acc = -1.0, 0.0 # Default values
        # Only train if there's a loader
        if train_loader:
            # IMPORTANT: Pass the correct num_classes for potential one-hot encoding in loss
            train_loss, train_acc = train(model, device, train_loader, optimizer, criterion, epoch, args.loss, num_classes)
        else:
            print(f"--- Epoch {epoch} Training Skipped ---")

        test_loss, test_acc = -1.0, 0.0 # Default values
        # Only test if there's a loader
        if test_loader:
            # IMPORTANT: Pass the correct num_classes for potential one-hot encoding in loss
            test_loss, test_acc = test(model, device, test_loader, criterion, args.loss, num_classes)
        else:
             print(f"--- Epoch {epoch} Testing Skipped ---")

        epoch_summary = f"Epoch {epoch}/{args.epochs} -> "
        if train_loader:
             epoch_summary += f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}% | "
        if test_loader:
            epoch_summary += f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%"
            # Update best accuracy only if testing was performed
            if test_acc > best_test_acc:
                best_test_acc = test_acc
                results_data['best_test_accuracy'] = best_test_acc
                # Optional: Save best model checkpoint
                # try:
                #     torch.save(model.state_dict(), os.path.join(result_dir, 'best_model.pth'))
                # except Exception as e:
                #     print(f"Error saving best model checkpoint: {e}")

        epoch_pbar.set_description(epoch_summary)

        # Store results for this epoch
        epoch_result = {
            'epoch': epoch,
            'train_loss': train_loss if train_loader else None,
            'train_accuracy': train_acc if train_loader else None,
            'test_loss': test_loss if test_loader else None,
            'test_accuracy': test_acc if test_loader else None,
        }
        results_data['epoch_results'].append(epoch_result)

        # Save results after each epoch (robust saving logic)
        try:
            with open(result_file, 'w') as f:
                json.dump(results_data, f, indent=4, default=lambda o: '<not serializable>') # Basic fallback
        except TypeError as e:
             print(f"Serialization Error: {e}. Check data types in results_data. Attempting fallback.")
             def default_serializer(o):
                 if isinstance(o, (np.integer, int)): return int(o)
                 if isinstance(o, (np.floating, float)): return float(o)
                 if isinstance(o, np.ndarray): return o.tolist()
                 if isinstance(o, torch.Tensor): return o.tolist() # Handle tensors
                 try:
                     # Attempt standard serialization first within the handler
                     return json.JSONEncoder.default(json.JSONEncoder(), o)
                 except TypeError:
                     try:
                         return str(o) # Fallback to string representation
                     except Exception:
                         return '<not serializable>' # Final fallback

             try:
                 with open(result_file, 'w') as f:
                    json.dump(results_data, f, indent=4, default=default_serializer)
                 # print("Saved results with custom serializer.") # Can be verbose
             except Exception as e_inner:
                 print(f"Error saving results to {result_file}: {e_inner}")
        except IOError as e:
             print(f"Error saving results to {result_file}: {e}")


        epoch_pbar.set_postfix(best_test_acc=f'{best_test_acc:.2f}%')


    end_train_time = time.time()
    total_training_time = end_train_time - start_train_time
    print(f"\n===== Training Complete =====")
    print(f"Dataset: {args.dataset}, Model: {args.model}, Loss: {args.loss}")
    print(f"Classes: {class_subset_str}, Samples: {num_samples_str}")
    print(f"Total Training Time: {total_training_time:.2f}s ({total_training_time/60:.2f} minutes)")
    print(f"Best Test Accuracy Achieved: {results_data['best_test_accuracy']:.2f}%")
    print(f"Final results saved to: {result_file}")
    # if best_test_acc > 0:
    #     print(f"Best model checkpoint saved to: {os.path.join(result_dir, 'best_model.pth')}")


if __name__ == '__main__':
    main()