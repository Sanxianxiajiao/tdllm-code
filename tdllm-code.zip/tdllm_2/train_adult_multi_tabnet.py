# Keep previous imports
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset # Still used for other models

import os
import argparse
import json
import random
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split # <--- 保持导入
from sklearn.preprocessing import StandardScaler, OneHotEncoder, OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
import time
from tqdm import tqdm
import warnings

# --- Import Fairlearn ---
try:
    from fairlearn import datasets # <--- 保持导入
except ImportError:
    print("fairlearn not found. Please install it: pip install fairlearn")
    datasets = None

# --- Import TabNet ---
try:
    from pytorch_tabnet.tab_model import TabNetClassifier
except ImportError:
    print("pytorch-tabnet not found. Please install it: pip install pytorch-tabnet")
    TabNetClassifier = None # Set to None if import fails

warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')
warnings.filterwarnings('ignore', category=FutureWarning, module='sklearn')

# --- Constants ---
DATASET_NAME = "adult"
# TRAIN_URL 和 TEST_URL 不再需要，但 COLUMN_NAMES 仍然有用
# TRAIN_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"
# TEST_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.test"
COLUMN_NAMES_FROM_UCI = [ # 保留原始名称用于映射或参考（如果需要）
    'age', 'workclass', 'fnlwgt', 'education', 'education-num', 'marital-status',
    'occupation', 'relationship', 'race', 'sex', 'capital-gain', 'capital-loss',
    'hours-per-week', 'native-country', 'income'
]
# fairlearn 使用的特征名通常与 UCI 类似，但可能略有不同或顺序不同
# 我们需要依赖 fetch_adult 返回的 feature_names
TARGET_FEATURE = 'income' # 我们将 fairlearn 的目标列重命名为此

# 特征列表需要根据 fairlearn 返回的实际列名来确认
# 这些列表基于 UCI 名称，通常可以直接使用，但最好检查
NUMERICAL_FEATURES = ['age', 'fnlwgt', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week']
CATEGORICAL_FEATURES = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country']

# --- Model Definitions (MLP models remain the same) ---
class AdultMLP(nn.Module):
    # ... (代码不变) ...
    def __init__(self, input_size, hidden_dim1=100, hidden_dim2=50, dropout_prob=0.3):
        super(AdultMLP, self).__init__()
        self.layer_1 = nn.Linear(input_size, hidden_dim1)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout_prob)
        self.layer_2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout_prob)
        self.output_layer = nn.Linear(hidden_dim2, 1)

    def forward(self, x):
        x = self.dropout1(self.relu1(self.layer_1(x)))
        x = self.dropout2(self.relu2(self.layer_2(x)))
        x = self.output_layer(x)
        return x

class AdultMLPWithEmbeddings(nn.Module):
    # ... (代码不变) ...
    def __init__(self, num_numerical_features, category_dims, embedding_dim=10,
                 hidden_dim1=100, hidden_dim2=50, dropout_prob=0.3):
        super(AdultMLPWithEmbeddings, self).__init__()
        self.num_numerical = num_numerical_features
        self.category_dims = category_dims
        self.embedding_dim = embedding_dim
        self.embeddings = nn.ModuleList(
            [nn.Embedding(num_categories, embedding_dim) for num_categories in category_dims]
        )
        total_embedding_size = len(category_dims) * embedding_dim
        mlp_input_size = total_embedding_size + num_numerical_features
        self.norm_numerical = nn.LayerNorm(num_numerical_features)
        self.layer_1 = nn.Linear(mlp_input_size, hidden_dim1)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout_prob)
        self.layer_2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout_prob)
        self.output_layer = nn.Linear(hidden_dim2, 1)

    def forward(self, x_num, x_cat):
        embedded_cats = [self.embeddings[i](x_cat[:, i]) for i in range(len(self.category_dims))]
        embedded_cats = torch.cat(embedded_cats, dim=1)
        x_num_normalized = self.norm_numerical(x_num)
        x = torch.cat([x_num_normalized, embedded_cats], dim=1)
        x = self.dropout1(self.relu1(self.layer_1(x)))
        x = self.dropout2(self.relu2(self.layer_2(x)))
        x = self.output_layer(x)
        return x


# --- PyTorch Datasets (remain the same for MLP models) ---
class TabularDataset(Dataset):
    # ... (代码不变) ...
    def __init__(self, features, labels):
        self.features = torch.tensor(features, dtype=torch.float32)
        self.labels = torch.tensor(labels, dtype=torch.float32).unsqueeze(1)
    def __len__(self): return len(self.features)
    def __getitem__(self, idx): return self.features[idx], self.labels[idx]

class TabularDatasetEmbed(Dataset):
    # ... (代码不变) ...
    def __init__(self, features_num, features_cat, labels):
        self.features_num = torch.tensor(features_num, dtype=torch.float32)
        self.features_cat = torch.tensor(features_cat, dtype=torch.long)
        self.labels = torch.tensor(labels, dtype=torch.float32).unsqueeze(1)
    def __len__(self): return len(self.labels)
    def __getitem__(self, idx): return self.features_num[idx], self.features_cat[idx], self.labels[idx]

# --- Helper Functions ---
def set_seed(seed):
    # ... (代码不变) ...
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

# --- Preprocessing (使用 fairlearn 加载) ---
def load_and_preprocess_adult(test_size=0.33, random_state=42): # 添加 test_size 和 random_state 参数
    """
    Loads the Adult dataset using fairlearn.datasets.fetch_adult, preprocesses it,
    and splits it into training and testing sets.

    Note: This uses train_test_split, so the split will differ from the
          original UCI .data/.test files split.
    """
    if datasets is None:
        print("Error: fairlearn library is required but not installed.")
        exit(1)

    print("Loading Adult dataset using fairlearn...")
    try:
        # as_frame=True 返回 Pandas DataFrame
        # return_X_y=False 返回 Bunch 对象，包含 data, target, frame, feature_names 等
        adult_data = datasets.fetch_adult(as_frame=True, return_X_y=False)
        df_combined = adult_data.frame
        # fairlearn 可能使用 'class' 作为目标列名，我们将其重命名为 'income'
        if 'class' in df_combined.columns and TARGET_FEATURE not in df_combined.columns:
            df_combined.rename(columns={'class': TARGET_FEATURE}, inplace=True)
            print(f"Renamed target column from 'class' to '{TARGET_FEATURE}'")
        elif TARGET_FEATURE not in df_combined.columns:
             print(f"Warning: Target column '{TARGET_FEATURE}' not found in loaded data. Available columns: {df_combined.columns}")
             # 可能需要手动指定目标列或检查 fairlearn 版本/数据
             # 这里我们假设目标列现在是 TARGET_FEATURE ('income')
        print("Dataset loaded successfully.")
        # print("Feature names from fairlearn:", adult_data.feature_names) # 可以取消注释来查看列名
        # print("DataFrame columns:", df_combined.columns)
        # print("DataFrame head:\n", df_combined.head())

    except Exception as e:
        print(f"Error loading data using fairlearn: {e}.")
        exit(1)

    # --- 基本清理 (与原脚本类似) ---
    # 检查并填充缺失值 (fairlearn 版本可能已经处理了一些，但以防万一)
    # 首先识别哪些是分类特征和数值特征 (根据我们的列表)
    actual_categorical_features = [col for col in CATEGORICAL_FEATURES if col in df_combined.columns]
    actual_numerical_features = [col for col in NUMERICAL_FEATURES if col in df_combined.columns]

    # 检查是否有未包含的特征
    processed_cols = set(actual_categorical_features) | set(actual_numerical_features) | {TARGET_FEATURE}
    all_cols = set(df_combined.columns)
    ignored_cols = all_cols - processed_cols
    if ignored_cols:
        print(f"Warning: The following columns from the loaded data are not in NUMERICAL_FEATURES or CATEGORICAL_FEATURES and will be ignored: {ignored_cols}")


    # 填充缺失值
    for col in actual_categorical_features:
        if df_combined[col].isnull().any():
            print(f"Filling NaNs in categorical column '{col}' with 'Missing'")
            # 需要确保 'Missing' 在后续编码时被处理
            df_combined[col] = df_combined[col].astype(str) # 确保是字符串类型
            df_combined[col].fillna('Missing', inplace=True)
        # Fairlearn 加载的数据类型可能是 category，转为 string 方便处理
        if pd.api.types.is_categorical_dtype(df_combined[col]):
             df_combined[col] = df_combined[col].astype(str)


    for col in actual_numerical_features:
        if df_combined[col].isnull().any():
            median_val = df_combined[col].median()
            print(f"Filling NaNs in numerical column '{col}' with median ({median_val})")
            df_combined[col].fillna(median_val, inplace=True)

    # --- 准备特征 X 和目标 y ---
    # 确保目标列存在
    if TARGET_FEATURE not in df_combined.columns:
        raise ValueError(f"Target feature '{TARGET_FEATURE}' not found in the dataframe columns: {df_combined.columns}")

    # 确保目标列编码方式与 UCI 相同 ('>50K', '<=50K')
    target_values = df_combined[TARGET_FEATURE].unique()
    print(f"Unique values in target column '{TARGET_FEATURE}': {target_values}")
    if '>50K' not in target_values:
        print(f"Warning: Expected target value '>50K' not found. Trying to determine positive class.")
        # Add logic here if fairlearn uses different labels (e.g., 1/0 or other strings)
        # For now, assume '>50K' is the positive class label
        positive_class_label = '>50K' # Default assumption
        # You might need to inspect adult_data.target_names or target_values further
    else:
        positive_class_label = '>50K'

    y = (df_combined[TARGET_FEATURE] == positive_class_label).astype(int).values
    X = df_combined[actual_numerical_features + actual_categorical_features] # 确保使用实际存在的列

    # --- 创建训练集和测试集 ---
    # **重要**: 在应用任何拟合（fit）操作之前进行分割
    print(f"Splitting data using train_test_split (test_size={test_size}, random_state={random_state})...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y # stratify 保持类别比例
    )
    print(f"Initial train samples: {len(y_train)}, Test samples: {len(y_test)}")

    # --- 创建预处理器 ---
    # OneHotEncoder 处理器
    preprocessor_onehot = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), actual_numerical_features),
            # handle_unknown='ignore' 很重要，以防测试集出现训练集未见过的类别
            # sparse_output=False 使得输出是 numpy array 而不是稀疏矩阵
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False, dtype=np.float32), actual_categorical_features) # Specify dtype
        ],
        remainder='drop' # 明确丢弃不在列表中的列
    )

    # OrdinalEncoder 处理器 (用于 MLP with Embeddings 和 TabNet)
    # 需要先在训练集上拟合 OrdinalEncoder 以确定类别
    ordinal_encoder = OrdinalEncoder(
        handle_unknown='use_encoded_value', # 将未知值编码为特定值
        unknown_value=-1, # 指定未知值的编码（例如 -1）
        dtype=np.int64 # Ensure output is integer type for embeddings/tabnet
        # categories='auto' # 让它自动从训练数据中检测类别
    )
    # 仅在训练数据的分类特征上拟合 OrdinalEncoder
    ordinal_encoder.fit(X_train[actual_categorical_features])
    category_dims = [len(cats) + 1 for cats in ordinal_encoder.categories_] # +1 for unknown_value=-1 -> index 0 potentially? Let's check TabNet reqs.
    # Let's stick to the original way, OrdinalEncoder handles unknown mapping internally
    category_dims = [len(cats) for cats in ordinal_encoder.categories_]
    # print(f"OrdinalEncoder categories detected: {ordinal_encoder.categories_}") # Debugging

    # 检查 'Missing' 是否被包含
    for i, col in enumerate(actual_categorical_features):
        if 'Missing' in X_train[col].unique() and 'Missing' not in ordinal_encoder.categories_[i]:
             print(f"Warning: 'Missing' category in training column '{col}' was not found by OrdinalEncoder. This might cause issues.")
        if 'Missing' in X_test[col].unique() and 'Missing' not in ordinal_encoder.categories_[i]:
             print(f"Warning: 'Missing' category detected in test column '{col}' but not in training categories for OrdinalEncoder. handle_unknown='use_encoded_value' will map it to -1.")


    preprocessor_ordinal = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), actual_numerical_features),
            # 使用已经拟合好的 categories 列表和 handle_unknown 策略
            ('cat', OrdinalEncoder(categories=ordinal_encoder.categories_,
                                   handle_unknown='use_encoded_value',
                                   unknown_value=-1,
                                   dtype=np.int64), # Ensure integer output
             actual_categorical_features)
        ],
        remainder='drop' # 明确丢弃
    )

    # --- 应用处理 ---
    # **重要**: 在训练数据上拟合预处理器，然后转换训练和测试数据
    print("Fitting preprocessors on training data and transforming train/test data...")

    # 处理 One-Hot 编码数据
    print("Applying One-Hot preprocessing...")
    preprocessor_onehot.fit(X_train)
    X_train_onehot = preprocessor_onehot.transform(X_train)
    X_test_onehot = preprocessor_onehot.transform(X_test)
    input_dim_onehot = X_train_onehot.shape[1]
    print(f"One-Hot encoded feature dimension: {input_dim_onehot}")

    # 处理 Ordinal 编码数据 (用于 MLP Embeddings 和 TabNet)
    print("Applying Ordinal preprocessing...")
    preprocessor_ordinal.fit(X_train)
    X_train_ordinal = preprocessor_ordinal.transform(X_train)
    X_test_ordinal = preprocessor_ordinal.transform(X_test)

    # 确定 TabNet 的 cat_idxs (分类特征在 ordinal 编码后的索引)
    # ColumnTransformer 默认将 'num' 放在前面，'cat' 放在后面
    num_numerical_features = len(actual_numerical_features)
    num_categorical_features = len(actual_categorical_features)
    cat_idxs = list(range(num_numerical_features, num_numerical_features + num_categorical_features))
    num_idxs = list(range(num_numerical_features))

    # Recalculate category_dims based on the *encoded values* in the training set + 1 for potential unknown
    # This is crucial for TabNet if unknown values (-1) are present.
    # Map -1 to 0, and shift others up by 1.
    X_train_cat_for_dims = X_train_ordinal[:, cat_idxs].astype(int)
    X_test_cat_for_dims = X_test_ordinal[:, cat_idxs].astype(int) # Check test set too

    # TabNet expects dimensions to be max_value + 1
    # If we use OrdinalEncoder with handle_unknown='use_encoded_value', unknown_value=-1,
    # the maximum encoded value for a category will be len(categories)-1.
    # The minimum value will be 0 (or -1 if unknown exists and is encoded as -1).
    # TabNet's `cat_dims` should reflect the number of unique *embeddings* needed.
    # If we have values 0, 1, 2, the dim should be 3.
    # If we have -1, 0, 1, 2, and -1 maps to a specific embedding (often index 0), dim should be 4.
    # Let's check the max value in the encoded categorical features.
    final_cat_dims = []
    for i in range(num_categorical_features):
        train_col_cats = X_train_cat_for_dims[:, i]
        max_encoded_val = int(train_col_cats.max()) # Max index used (e.g., 0, 1, 2 -> max is 2)
        min_encoded_val = int(train_col_cats.min())
        # Test set might introduce the unknown value (-1)
        if -1 in X_test_cat_for_dims[:, i]:
            min_encoded_val = min(min_encoded_val, -1)

        # If -1 (unknown) is present, we need an extra embedding slot.
        # TabNet internally might handle negative indices, but providing the correct dimension is safer.
        # Dimension should be max_value + 1. If -1 exists, we need to account for it.
        # Simplest: Dimension = max_value + 1 (if min >= 0)
        #           Dimension = max_value + 2 (if min == -1, effectively mapping -1 to index 0, 0 to 1, etc.) - This seems complex.
        # Let's assume TabNet handles indices >= 0. We map -1 to 0, and shift others.
        # This requires modifying the data *before* passing to TabNet.
        # Alternative: Use the original `category_dims` from OrdinalEncoder, assuming TabNet handles OOV internally or we rely on the encoder.
        # Let's stick to the simpler approach first: use dimensions from OrdinalEncoder.
        final_cat_dims = [len(cats) for cats in ordinal_encoder.categories_]
        # However, pytorch-tabnet docs suggest cat_dims should be number of unique values + 1 if using 0-based indexing.
        # Let's test with max_value + 1, handling the -1 case if it occurs.
        max_vals = []
        for i in range(num_categorical_features):
            all_cats = np.concatenate((X_train_cat_for_dims[:, i], X_test_cat_for_dims[:, i]))
            max_val = int(np.max(all_cats))
            min_val = int(np.min(all_cats))
            if min_val < 0: # Assumes -1 is the only negative possibility
                 # If -1 exists, the effective number of categories is max_val + 2 (-1 maps to one, 0..max_val maps to others)
                 # But TabNet expects indices >= 0. Let's modify the data instead.
                 # print(f"Warning: Column {i} contains -1 (unknown).")
                 pass # We will handle this before TabNet fit if necessary.
            max_vals.append(max_val)

        # Final decision: Use the length from ordinal_encoder.categories_ directly.
        # This assumes the encoder provides the correct cardinality.
        final_cat_dims = [len(cats) for cats in ordinal_encoder.categories_]
        print(f"Using category dimensions derived from OrdinalEncoder: {final_cat_dims}")


    print(f"Ordinal encoded numerical features: {num_numerical_features}")
    print(f"Ordinal encoded categorical features: {num_categorical_features}")
    print(f"Categorical dimensions (cardinalities): {final_cat_dims}")
    print(f"Categorical indices for TabNet: {cat_idxs}")

    # 提取 MLP with Embeddings 需要的数据
    X_train_num = X_train_ordinal[:, num_idxs]
    X_train_cat = X_train_ordinal[:, cat_idxs].astype(int) # 确保是整数类型 for embedding lookup
    X_test_num = X_test_ordinal[:, num_idxs]
    X_test_cat = X_test_ordinal[:, cat_idxs].astype(int)

    # Handle potential -1 from OrdinalEncoder for MLP Embeddings if needed
    # Usually, embedding layers expect non-negative indices. Let's map -1 to 0.
    if np.any(X_train_cat == -1) or np.any(X_test_cat == -1):
        print("Mapping OrdinalEncoder's unknown value (-1) to index 0 for MLP Embedding inputs.")
        X_train_cat[X_train_cat == -1] = 0 # Map -1 to 0
        X_test_cat[X_test_cat == -1] = 0   # Map -1 to 0
        # Note: This assumes category_dims were calculated correctly to accommodate this.
        # The original category_dims = [len(cats)...] should be okay, as index 0 exists.


    # TabNet 使用组合后的 ordinal 数据
    X_train_tabnet = X_train_ordinal
    X_test_tabnet = X_test_ordinal

    # Handle potential -1 for TabNet. TabNet expects non-negative indices.
    # We need to modify the data passed to TabNet. Map -1 to a specific index (e.g., 0)
    # AND adjust cat_dims accordingly if we haven't already.
    # Let's map -1 to 0 and shift existing indices up by 1. This requires adjusting cat_dims.
    X_train_tabnet_cat = X_train_tabnet[:, cat_idxs].astype(int)
    X_test_tabnet_cat = X_test_tabnet[:, cat_idxs].astype(int)
    needs_remapping_for_tabnet = False
    if np.any(X_train_tabnet_cat == -1) or np.any(X_test_tabnet_cat == -1):
        print("Detected -1 in Ordinal Encoded data for TabNet. Remapping: -1 -> 0, original 0 -> 1, etc.")
        needs_remapping_for_tabnet = True
        X_train_tabnet_cat[X_train_tabnet_cat == -1] = 0 # Tentative map -1 to 0
        X_train_tabnet_cat[X_train_tabnet_cat >= 0] += 1 # Shift others up

        X_test_tabnet_cat[X_test_tabnet_cat == -1] = 0
        X_test_tabnet_cat[X_test_tabnet_cat >= 0] += 1

        # Update cat_dims: add 1 to each dim because we introduced a new category (the unknown) at index 0
        tabnet_cat_dims = [d + 1 for d in final_cat_dims]

        # Update the main TabNet arrays
        X_train_tabnet = np.hstack((X_train_tabnet[:, num_idxs], X_train_tabnet_cat))
        X_test_tabnet = np.hstack((X_test_tabnet[:, num_idxs], X_test_tabnet_cat))
    else:
        # If no -1, use original dims
        tabnet_cat_dims = final_cat_dims


    # --- 返回处理好的数据字典 ---
    return {
        'onehot': {
            'X_train': X_train_onehot, 'y_train': y_train,
            'X_test': X_test_onehot, 'y_test': y_test,
            'input_dim': input_dim_onehot
        },
        'ordinal': { # For mlp_embed
            'X_train_num': X_train_num, 'X_train_cat': X_train_cat, 'y_train': y_train,
            'X_test_num': X_test_num, 'X_test_cat': X_test_cat, 'y_test': y_test,
            'num_numerical': num_numerical_features,
            'category_dims': final_cat_dims # Use consistent dims derived from encoder
        },
        'tabnet': { # For TabNet model
            'X_train': X_train_tabnet, 'y_train': y_train,
            'X_test': X_test_tabnet, 'y_test': y_test,
            'cat_idxs': cat_idxs,
            'cat_dims': tabnet_cat_dims, # Use potentially adjusted dims
            'num_features': num_numerical_features # Info only
        }
    }


# --- get_model function (only for MLP types now) ---
def get_model_mlp(model_name, model_params):
    """Instantiates MLP-based models."""
    if model_name == 'mlp':
        # 从 model_params 中提取 'input_dim' 的值，并将其从字典中移除
        # 使用 .pop() 方法，如果键不存在会报错，这有助于发现之前的逻辑错误
        input_dim_value = model_params.pop('input_dim', None) # 加一个默认值以防万一，虽然按逻辑应该存在
        if input_dim_value is None:
             raise ValueError("Critical error: 'input_dim' was not found in model_params for MLP model.")

        # 现在 model_params 不再包含 'input_dim' 键
        # 显式传递 input_size，解包剩余的参数
        model = AdultMLP(input_size=input_dim_value, **model_params)

    elif model_name == 'mlp_embed':
        # 对于 mlp_embed，不需要 input_size，参数直接从 model_params 解包
        # （假设 mlp_embed 的构造函数参数名与 model_params 中的键匹配）
        # 我们需要确认 mlp_embed 的参数，它需要 num_numerical, category_dims, embedding_dim 等
        # 这些已经在 main 函数中放入了 model_params
        model = AdultMLPWithEmbeddings(**model_params)
    else:
        raise ValueError(f"This function only handles mlp and mlp_embed: {model_name}")
    return model


# --- train & test functions (only used for MLP models) ---
def train(model, device, train_loader, optimizer, criterion, epoch, model_name):
    # ... (代码不变) ...
    model.train()
    train_loss = 0
    all_targets, all_predictions = [], []
    pbar = tqdm(train_loader, desc=f"Epoch {epoch} Training", leave=False)
    for batch_data in pbar:
        if model_name == 'mlp_embed':
            features_num, features_cat, target = batch_data
            features_num, features_cat, target = features_num.to(device), features_cat.to(device), target.to(device)
            outputs = model(features_num, features_cat)
        else:
            features, target = batch_data
            features, target = features.to(device), target.to(device)
            outputs = model(features)

        optimizer.zero_grad()
        loss = criterion(outputs, target)
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
        with torch.no_grad():
            predicted_probs = torch.sigmoid(outputs)
            predicted_labels = (predicted_probs > 0.5).float()
            all_targets.extend(target.cpu().numpy())
            all_predictions.extend(predicted_labels.cpu().numpy())
        pbar.set_postfix(loss=f'{loss.item():.4f}')
    avg_loss = train_loss / len(train_loader)
    accuracy = accuracy_score(np.array(all_targets), np.array(all_predictions)) * 100
    return avg_loss, accuracy

def test(model, device, test_loader, criterion, model_name):
    # ... (代码不变) ...
    model.eval()
    test_loss = 0
    all_targets, all_predictions = [], []
    pbar = tqdm(test_loader, desc="Testing", leave=False)
    with torch.no_grad():
        for batch_data in pbar:
            if model_name == 'mlp_embed':
                features_num, features_cat, target = batch_data
                features_num, features_cat, target = features_num.to(device), features_cat.to(device), target.to(device)
                outputs = model(features_num, features_cat)
            else:
                features, target = batch_data
                features, target = features.to(device), target.to(device)
                outputs = model(features)
            loss = criterion(outputs, target)
            test_loss += loss.item()
            predicted_probs = torch.sigmoid(outputs)
            predicted_labels = (predicted_probs > 0.5).float()
            all_targets.extend(target.cpu().numpy())
            all_predictions.extend(predicted_labels.cpu().numpy())
    avg_loss = test_loss / len(test_loader)
    accuracy = accuracy_score(np.array(all_targets), np.array(all_predictions)) * 100
    return avg_loss, accuracy

# --- JSON Serializer Helper ---
def default_serializer(o):
    if isinstance(o, (np.integer, np.int64)): return int(o)
    if isinstance(o, (np.floating, np.float32, np.float64)): return float(o)
    if isinstance(o, np.ndarray): return o.tolist()
    if isinstance(o, (torch.Tensor)): return o.tolist()
    # print(f"Cannot serialize type {type(o)}") # Debug
    raise TypeError(f"Object of type {o.__class__.__name__} is not JSON serializable")

# --- Main Execution ---
def main():
    # 检查 fairlearn 是否可用（如果脚本依赖它）
    if datasets is None:
         print("Error: fairlearn library is required but not installed. Please run 'pip install fairlearn'.")
         exit(1)

    if TabNetClassifier is None and '--model' in os.sys.argv and 'tabnet' in os.sys.argv:
         print("Error: --model tabnet selected but pytorch-tabnet is not installed.")
         exit(1)

    # --- Argument Parsing ---
    parser = argparse.ArgumentParser(description=f'PyTorch {DATASET_NAME.capitalize()} Training')
    # ... (其余参数解析代码不变) ...
    parser.add_argument('--model', type=str, required=True,
                        choices=['mlp', 'mlp_embed', 'tabnet'], # Added tabnet
                        help='Model architecture to use')
    # Common args
    parser.add_argument('--epochs', type=int, default=30, metavar='N', help='Max number of epochs (used by TabNet too)')
    parser.add_argument('--batch_size', type=int, default=1024, metavar='N', help='Training batch size (TabNet uses this too)')
    parser.add_argument('--lr', type=float, default=0.001, metavar='LR', help='Learning rate (Adam/AdamW for MLPs, default 0.02 for TabNet)')
    parser.add_argument('--seed', type=int, default=42, metavar='S', help='random seed')
    parser.add_argument('--no_cuda', action='store_true', default=False, help='disables CUDA training')
    parser.add_argument('--results_dir', type=str, default='./results', help='Base directory to save results')
    # MLP specific args
    parser.add_argument('--dropout', type=float, default=0.3, help='Dropout probability for MLPs')
    parser.add_argument('--embedding_dim', type=int, default=10, help='Embedding dimension for mlp_embed and TabNet') # Used by TabNet too
    parser.add_argument('--hidden_dim1', type=int, default=100, help='Neurons in first hidden layer for MLPs')
    parser.add_argument('--hidden_dim2', type=int, default=50, help='Neurons in second hidden layer for MLPs')
    # TabNet specific args (defaults often work well, but can be tuned)
    parser.add_argument('--tabnet_n_d', type=int, default=8, help='TabNet: Width of decision step')
    parser.add_argument('--tabnet_n_a', type=int, default=8, help='TabNet: Width of attention embedding')
    parser.add_argument('--tabnet_n_steps', type=int, default=3, help='TabNet: Number of decision steps')
    parser.add_argument('--tabnet_gamma', type=float, default=1.3, help='TabNet: Coefficient for feature reusage')
    parser.add_argument('--tabnet_lambda_sparse', type=float, default=1e-3, help='TabNet: Sparsity loss coefficient')
    parser.add_argument('--tabnet_mask_type', type=str, default='sparsemax', choices=['sparsemax', 'entmax'], help='TabNet: Mask function type')
    parser.add_argument('--tabnet_patience', type=int, default=10, help='TabNet: Early stopping patience (0 or <0 to disable)') # Default patience 10
    parser.add_argument('--tabnet_lr', type=float, default=0.02, help='TabNet: Initial learning rate') # TabNet default is often higher
    parser.add_argument('--tabnet_virtual_batch_size', type=int, default=256, help='TabNet: Virtual batch size for Ghost BN')
    # 新增参数控制 train_test_split 行为
    parser.add_argument('--test_split_ratio', type=float, default=0.33, help='Fraction of data to use for the test set (since fairlearn load combines data)')
    # 新增参数控制训练样本数量
    parser.add_argument('--num_train_samples', type=float, default=None,
                        help='Number or fraction of training samples to use. '
                             'E.g., 0.1 for 10%, 1000 for 1000 samples. '
                             'If None or not provided, uses all training data.')


    args = parser.parse_args()

    # --- Setup ---
    set_seed(args.seed)
    use_cuda = not args.no_cuda and torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    device_name = "cuda" if use_cuda else "cpu" # For TabNet device parameter
    print(f"Using device: {device_name}")
    print(f"Selected Model: {args.model}")

    # --- Data Loading and Preprocessing ---
    # 使用修改后的函数，传入 test_split_ratio 和 seed
    processed_data = load_and_preprocess_adult(test_size=args.test_split_ratio, random_state=args.seed)

    # --- Training Data Subsetting --- # <<<< NEW SECTION >>>>
    # Grab initial full training data (labels are same across dict keys)
    y_train_full = processed_data['onehot']['y_train'] # Or from 'ordinal'/'tabnet'
    num_train_samples_full = len(y_train_full)
    actual_num_train_samples = num_train_samples_full # Default: use all

    if args.num_train_samples is not None:
        requested_samples = args.num_train_samples
        calculated_num_samples = -1

        if requested_samples > 0 and requested_samples <= 1:
            # Calculate fraction
            calculated_num_samples = int(num_train_samples_full * requested_samples)
            print(f"Requested {requested_samples*100:.1f}% of training samples.")
        elif requested_samples > 1:
            # Treat as absolute number
            calculated_num_samples = int(requested_samples)
            print(f"Requested {calculated_num_samples} training samples.")
        else: # requested_samples <= 0
            print(f"Warning: Invalid num_train_samples ({requested_samples}). Using all {num_train_samples_full} training samples.")
            calculated_num_samples = num_train_samples_full # Fallback to using all

        # Ensure the number is within bounds [1, num_train_samples_full]
        actual_num_train_samples = max(1, min(calculated_num_samples, num_train_samples_full))

        if actual_num_train_samples != calculated_num_samples:
             print(f"Adjusted number of training samples to {actual_num_train_samples} (must be between 1 and {num_train_samples_full}).")
        else:
             print(f"Using {actual_num_train_samples} training samples.")


        if actual_num_train_samples < num_train_samples_full:
            # Apply subsetting to all relevant X_train and y_train arrays
            # Use the same slice for all to maintain correspondence
            indices_to_keep = np.arange(actual_num_train_samples) # Simple slice from start

            print(f"Subsetting training data to {actual_num_train_samples} samples...")

            # OneHot data
            processed_data['onehot']['X_train'] = processed_data['onehot']['X_train'][indices_to_keep]
            processed_data['onehot']['y_train'] = processed_data['onehot']['y_train'][indices_to_keep]

            # Ordinal data (MLP Embed)
            processed_data['ordinal']['X_train_num'] = processed_data['ordinal']['X_train_num'][indices_to_keep]
            processed_data['ordinal']['X_train_cat'] = processed_data['ordinal']['X_train_cat'][indices_to_keep]
            processed_data['ordinal']['y_train'] = processed_data['ordinal']['y_train'][indices_to_keep]

            # TabNet data
            processed_data['tabnet']['X_train'] = processed_data['tabnet']['X_train'][indices_to_keep]
            processed_data['tabnet']['y_train'] = processed_data['tabnet']['y_train'][indices_to_keep]

            # Verify (optional)
            print(f"Actual y_train length after subsetting: {len(processed_data['onehot']['y_train'])}")

    else: # args.num_train_samples is None
        print(f"Using all {actual_num_train_samples} training samples.")

    # --- Result Saving Setup --- # <<<< MODIFIED >>>>
    # Use the *actual* number of training samples in the path
    result_dir = os.path.join(args.results_dir, DATASET_NAME, args.model, str(actual_num_train_samples))
    os.makedirs(result_dir, exist_ok=True)
    result_file = os.path.join(result_dir, 'result.json')
    print(f"Results will be saved to: {result_file}")

    # Store arguments and initialize results dict
    results_data = {
        'args': vars(args),
        'actual_num_train_samples': actual_num_train_samples, # Store the actual number used
        'best_test_accuracy': 0.0,
        'epoch_results': []
    }


    start_train_time = time.time()

    # --- Model Specific Handling ---
    if args.model in ['mlp', 'mlp_embed']:
        # --- Standard PyTorch Model Training ---
        # Data is now potentially subsetted in processed_data
        model_params = {
            'dropout_prob': args.dropout,
            'hidden_dim1': args.hidden_dim1,
            'hidden_dim2': args.hidden_dim2,
        }
        if args.model == 'mlp':
            data = processed_data['onehot']
            train_dataset = TabularDataset(data['X_train'], data['y_train'])
            test_dataset = TabularDataset(data['X_test'], data['y_test'])
            model_params['input_dim'] = data['input_dim']
        else: # mlp_embed
            data = processed_data['ordinal']
            train_dataset = TabularDatasetEmbed(data['X_train_num'], data['X_train_cat'], data['y_train'])
            test_dataset = TabularDatasetEmbed(data['X_test_num'], data['X_test_cat'], data['y_test'])
            model_params['num_numerical_features'] = data['num_numerical'] # Use correct key
            model_params['category_dims'] = data['category_dims']
            model_params['embedding_dim'] = args.embedding_dim

        train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=use_cuda)
        test_loader = DataLoader(test_dataset, batch_size=args.batch_size * 2, shuffle=False, num_workers=0, pin_memory=use_cuda)

        model = get_model_mlp(args.model, model_params).to(device)
        print(f"Instantiated model: {args.model} with {actual_num_train_samples} training samples.")
        print(f"Model architecture:\n{model}")

        criterion = nn.BCEWithLogitsLoss()
        optimizer = optim.AdamW(model.parameters(), lr=args.lr)

        epoch_pbar = tqdm(range(1, args.epochs + 1), desc="Total Epochs")
        for epoch in epoch_pbar:
            train_loss, train_acc = train(model, device, train_loader, optimizer, criterion, epoch, args.model)
            test_loss, test_acc = test(model, device, test_loader, criterion, args.model)

            epoch_summary = f"E{epoch} | Tr L:{train_loss:.4f} Tr A:{train_acc:.2f}% | Te L:{test_loss:.4f} Te A:{test_acc:.2f}%"
            epoch_pbar.set_description(epoch_summary)

            epoch_result = {'epoch': epoch, 'train_loss': train_loss, 'train_accuracy': train_acc, 'test_loss': test_loss, 'test_accuracy': test_acc}
            results_data['epoch_results'].append(epoch_result)
            if test_acc > results_data['best_test_accuracy']:
                results_data['best_test_accuracy'] = test_acc
            epoch_pbar.set_postfix(best_acc=f'{results_data["best_test_accuracy"]:.2f}%')

            # Save intermediate results (optional but good practice)
            try:
                 with open(result_file, 'w') as f:
                     json.dump(results_data, f, indent=4, default=default_serializer)
            except Exception as e: print(f"Error saving results during epoch {epoch}: {e}")


    elif args.model == 'tabnet':
        # --- TabNet Model Training ---
        if TabNetClassifier is None:
             print("TabNet model selected but library not installed. Exiting.")
             exit(1)

        # Get potentially subsetted data
        data = processed_data['tabnet']
        X_train, y_train = data['X_train'], data['y_train']
        X_test, y_test = data['X_test'], data['y_test'] # Test set is not subsetted

        # Ensure virtual_batch_size <= actual_num_train_samples and <= batch_size
        effective_vbs = args.tabnet_virtual_batch_size
        if effective_vbs > args.batch_size:
            print(f"Warning: virtual_batch_size ({effective_vbs}) > batch_size ({args.batch_size}). Setting virtual_batch_size = batch_size.")
            effective_vbs = args.batch_size
        if effective_vbs > actual_num_train_samples:
             print(f"Warning: virtual_batch_size ({effective_vbs}) > num_train_samples ({actual_num_train_samples}). Setting virtual_batch_size = {actual_num_train_samples}.")
             effective_vbs = actual_num_train_samples


        # Instantiate TabNetClassifier
        # Use tabnet_lr argument for optimizer
        # Use embedding_dim argument for cat_emb_dim
        model = TabNetClassifier(
            n_d=args.tabnet_n_d,
            n_a=args.tabnet_n_a,
            n_steps=args.tabnet_n_steps,
            gamma=args.tabnet_gamma,
            lambda_sparse=args.tabnet_lambda_sparse,
            cat_idxs=data['cat_idxs'],
            cat_dims=data['cat_dims'],
            cat_emb_dim=args.embedding_dim, # Use the common embedding dim arg
            optimizer_fn=torch.optim.AdamW, # Using AdamW like MLP models
            optimizer_params=dict(lr=args.tabnet_lr), # Use the specific TabNet LR arg
            mask_type=args.tabnet_mask_type,
            scheduler_params={"step_size":10, "gamma":0.9}, # Example scheduler
            scheduler_fn=torch.optim.lr_scheduler.StepLR,
            seed=args.seed,
            verbose=1, # Show epoch progress
            device_name=device_name
        )
        print(f"Instantiated model: {args.model} with {actual_num_train_samples} training samples.")
        print(f"TabNet Params: n_d={args.tabnet_n_d}, n_a={args.tabnet_n_a}, n_steps={args.tabnet_n_steps}, emb_dim={args.embedding_dim}")
        print(f"TabNet Cat Dims: {data['cat_dims']}")
        print(f"TabNet Cat Idxs: {data['cat_idxs']}")

        # Train using TabNet's fit method
        print("Starting TabNet training...")
        eval_patience = args.tabnet_patience if args.tabnet_patience > 0 else args.epochs + 1
        model.fit(
            X_train=X_train, y_train=y_train, # Use potentially subsetted training data
            eval_set=[(X_test, y_test)],       # Use original test set for evaluation
            eval_name=['test'],                # Name for the evaluation set
            eval_metric=['accuracy', 'logloss'], # Metrics to compute
            max_epochs=args.epochs,
            patience=eval_patience, # Use argument for early stopping
            batch_size=args.batch_size,
            virtual_batch_size=effective_vbs, # Use adjusted virtual batch size
            num_workers=0, # Often safer for TabNet
            drop_last=False, # Keep last batch even if smaller
            # Note: TabNet's fit logs metrics based on the eval_set.
        )
        print("TabNet training finished.")

        # --- Extract results from TabNet history ---
        history_callback = model.history # Get the callback object
        history_dict = history_callback.history # Access the underlying dictionary of lists

        # print("Available history keys:", list(history_dict.keys())) # Debugging: See available keys

        best_acc = 0.0
        # Determine the number of epochs based on the 'loss' list length (usually reliable)
        num_epochs_recorded = len(history_dict.get('loss', []))

        if num_epochs_recorded == 0:
            print("Warning: No epochs recorded in TabNet history ('loss' key is empty).")
            # If training stopped early due to no improvement, we might need the best score directly
            best_acc = model.best_cost * 100 if hasattr(model, 'best_cost') and model.best_cost is not None else 0.0 # TabNet stores best *cost* (loss), need accuracy
            # Let's try getting accuracy from final prediction if history is empty
            try:
                y_pred_test = model.predict(X_test)
                final_test_acc = accuracy_score(y_test, y_pred_test) * 100
                print(f"TabNet history empty, using final test accuracy: {final_test_acc:.2f}%")
                results_data['best_test_accuracy'] = final_test_acc
            except Exception as e:
                 print(f"Could not calculate final accuracy after empty history: {e}")
                 results_data['best_test_accuracy'] = 0.0


        else:
            print(f"Extracting results for {num_epochs_recorded} recorded epochs...")

            for epoch_idx in range(num_epochs_recorded): # Iterate from 0 to num_epochs_recorded - 1
                epoch_num = epoch_idx + 1 # Human-readable epoch number (1-based)

                # Safely retrieve metrics for the current epoch index
                train_loss_list = history_dict.get('loss', [])
                train_loss = train_loss_list[epoch_idx] if len(train_loss_list) > epoch_idx else None

                # Test Loss (Check common keys)
                test_loss_key = None
                if 'test_logloss' in history_dict: test_loss_key = 'test_logloss'
                elif 'val_0_logloss' in history_dict: test_loss_key = 'val_0_logloss'
                test_loss_list = history_dict.get(test_loss_key, []) if test_loss_key else []
                test_loss = test_loss_list[epoch_idx] if len(test_loss_list) > epoch_idx else None

                # Test Accuracy (Check common keys)
                test_acc_key = None
                if 'test_accuracy' in history_dict: test_acc_key = 'test_accuracy'
                elif 'val_0_accuracy' in history_dict: test_acc_key = 'val_0_accuracy'
                test_acc_list = history_dict.get(test_acc_key, []) if test_acc_key else []
                test_acc = (test_acc_list[epoch_idx] * 100) if len(test_acc_list) > epoch_idx else None # Scale to percentage

                # Train Accuracy (Might not be logged by default)
                train_acc_key = None # Check if exists, e.g., 'train_accuracy'
                if 'train_accuracy' in history_dict: train_acc_key = 'train_accuracy'
                train_acc_list = history_dict.get(train_acc_key, []) if train_acc_key else []
                train_acc = (train_acc_list[epoch_idx] * 100) if len(train_acc_list) > epoch_idx else None # Scale to percentage

                # Store results
                epoch_result = {
                    'epoch': epoch_num,
                    'train_loss': train_loss,
                    'train_accuracy': train_acc, # Will be None if key missing or list too short
                    'test_loss': test_loss,     # Will be None if key missing or list too short
                    'test_accuracy': test_acc   # Will be None if key missing or list too short
                }
                results_data['epoch_results'].append(epoch_result)

                # Update best accuracy
                if test_acc is not None and test_acc > best_acc:
                    best_acc = test_acc

            # Final best accuracy from history
            valid_test_accuracies = [res['test_accuracy'] for res in results_data['epoch_results'] if res['test_accuracy'] is not None]
            results_data['best_test_accuracy'] = max(valid_test_accuracies) if valid_test_accuracies else 0.0
            print(f"Best test accuracy found in history: {results_data['best_test_accuracy']:.2f}%")

            # Note: TabNet with patience > 0 automatically loads the best model weights found during training based on the *first* eval metric ('accuracy' in our case).
            # So, we can also potentially get the best score directly from the model if needed, although history is preferred.
            # final_pred = model.predict(X_test)
            # final_acc = accuracy_score(y_test, final_pred) * 100
            # print(f"Final accuracy of loaded best TabNet model: {final_acc:.2f}%")
            # results_data['best_test_accuracy'] = max(results_data['best_test_accuracy'], final_acc) # Use the higher one


    else:
        raise ValueError(f"Model type {args.model} handling not implemented.")

    # --- Final Reporting and Saving ---
    end_train_time = time.time()
    total_training_time = end_train_time - start_train_time
    results_data['total_training_time_sec'] = total_training_time # Add training time to results

    print(f"\n===== Training Complete ({args.model} with {actual_num_train_samples} samples) =====")
    print(f"Total Training Time: {total_training_time:.2f}s ({total_training_time/60:.2f} minutes)")
    print(f"Best Test Accuracy Achieved: {results_data['best_test_accuracy']:.2f}%")

    # Final save of results
    try:
         with open(result_file, 'w') as f:
             json.dump(results_data, f, indent=4, default=default_serializer)
         print(f"Final results saved to: {result_file}")
    except Exception as e:
        print(f"Error saving final results: {e}")


if __name__ == '__main__':
    main()