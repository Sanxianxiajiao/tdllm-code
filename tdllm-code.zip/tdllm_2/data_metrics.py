# -*- coding: utf-8 -*-
# --- 0. Import Libraries ---
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import io
import os
import math
from scipy.stats import spearmanr, pearsonr, kendalltau
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error, r2_score
import json
import re
from adjustText import adjust_text
from scipy.signal import savgol_filter # For more advanced smoothing, if needed

# --- Style Configuration for Plots (Nature Research Paper Style) ---
plt.style.use('seaborn-v0_8-paper')
NATURE_BLUE = '#0072B2'
NATURE_ORANGE = '#D55E00'
NATURE_GREEN = '#009E73'
NATURE_GREY = '#888888'
NATURE_LIGHT_BLUE = '#56B4E9'

TITLE_FONTSIZE = 26
LABEL_FONTSIZE = 24
TICK_FONTSIZE = 22
LEGEND_FONTSIZE = 22
ANNOTATION_FONTSIZE = 11 # For text labels on points/bars
POINT_LABEL_FONTSIZE = 11 # Specific for scatter plot point labels

# --- 1. Load the Data from JSON Files ---
data_analysis_dir = '/home/mqc/tdllm_2/data_analys/'
min_sample_size_file = '/home/mqc/tdllm_2/min_sample_sizes.json'
features = ['num_classes', 'label_entropy', 'effective_dim', 'intra_class_var', 'local_consistency', 'separability_score']
target = 'min_sample_size'
output_dir = './pic/'
os.makedirs(output_dir, exist_ok=True)

print(f"Loading target values from {min_sample_size_file}...")
try:
    with open(min_sample_size_file, 'r') as f:
        target_sizes_raw = json.load(f)
    target_sizes_lower = {k.lower(): v for k, v in target_sizes_raw.items()}
    print(f"Successfully loaded target values for {len(target_sizes_lower)} tasks.")
except Exception as e:
    print(f"Error loading target file {min_sample_size_file}: {e}"); exit()

print(f"\nLoading complexity metrics from directory {data_analysis_dir}...")
all_task_data = []
files_processed, files_skipped_json_error, files_skipped_missing_metrics, files_skipped_no_match = 0, 0, 0, 0
if not os.path.isdir(data_analysis_dir): print(f"Error: Metrics directory not found {data_analysis_dir}"); exit()

for filename in os.listdir(data_analysis_dir):
    if filename.endswith('.json'):
        files_processed += 1; filepath = os.path.join(data_analysis_dir, filename)
        task_name_match = re.match(r'([a-zA-Z0-9_\-]+?)(_complexity_metrics|_metrics)?\.json', filename)
        task_name = ""
        if not task_name_match:
            base_name = filename.replace('.json', '').lower()
            matched_target = next((tgt_name for tgt_name in target_sizes_lower.keys() if base_name == tgt_name or base_name.startswith(tgt_name + '_')), None)
            if matched_target: task_name = matched_target
            else: files_skipped_no_match += 1; continue
        else: task_name = task_name_match.group(1).lower()
        try:
            with open(filepath, 'r') as f_metrics_file: data = json.load(f_metrics_file)
            metrics_data = {}; extracted = False
            potential_metric_sources = [data, data.get('complexity_metrics', {}), data.get('metrics', {})]
            for source in potential_metric_sources:
                if isinstance(source, dict):
                    temp_metrics = {}
                    all_found = True
                    for f_iter in features:
                        if f_iter in source: temp_metrics[f_iter] = source[f_iter]
                        elif f_iter == 'intra_class_var' and 'intra_class_var_avg' in source: temp_metrics[f_iter] = source['intra_class_var_avg']
                        else: all_found = False; break
                    if all_found: metrics_data = temp_metrics; extracted = True; break
            if extracted and all(metrics_data.get(f_val) is not None and np.isfinite(pd.to_numeric(metrics_data.get(f_val), errors='coerce')) for f_val in features):
                for f_val in features: metrics_data[f_val] = float(metrics_data[f_val])
                metrics_data['task_name_in_json'] = task_name; all_task_data.append(metrics_data)
            elif extracted: files_skipped_missing_metrics += 1
            else: files_skipped_missing_metrics += 1
        except json.JSONDecodeError: files_skipped_json_error += 1
        except Exception as e: print(f"  - Unknown error processing '{filename}': {e}"); files_skipped_json_error += 1

print(f"\nProcessed {files_processed} JSON files. Skipped: {files_skipped_json_error} (JSON err), {files_skipped_missing_metrics} (metric err), {files_skipped_no_match} (name err).")
if not all_task_data: print("\nError: No valid metric data loaded."); exit()

df_metrics = pd.DataFrame(all_task_data)
if df_metrics['task_name_in_json'].duplicated().any():
    print("\nWarning: Duplicate task names. Keeping first occurrence."); df_metrics.drop_duplicates(subset='task_name_in_json', keep='first', inplace=True)
df_metrics.set_index('task_name_in_json', inplace=True)
target_sizes_numeric = {k: pd.to_numeric(v, errors='coerce') for k, v in target_sizes_lower.items()}
target_sizes_valid = {k: v for k, v in target_sizes_numeric.items() if pd.notna(v)}
if len(target_sizes_lower) - len(target_sizes_valid) > 0: print(f"  - Warning: Removed {len(target_sizes_lower) - len(target_sizes_valid)} tasks from target due to non-numeric values.")
df_target = pd.Series(target_sizes_valid, name=target); df_target.index.name = 'task_name_in_json'
df = pd.merge(df_metrics, df_target, left_index=True, right_index=True, how='inner')
print("\n--- Loaded and Merged Data Preview ---"); print(f"\nLoaded {len(df)} tasks with valid metrics and target.")
if df.isnull().values.any(): print("\nWarning: NaNs in merged DataFrame!"); df.dropna(inplace=True)

# --- 2. Assign Groups ---
original_group1_tasks = ['adult', 'fashionmnist', 'cifar10', 'svhn', 'mnist', 'speech_commands']
new_group1_tasks = ['stl10', 'olivetti_faces', 'food101', 'clutrr', 'oxfordiiitpet', 'digits', 'flowers102', 'fgvc_aircraft', 'dtd', 'semeion', 'kmnist', 'usps', 'spambase', 'cifar100', 'clutrr_k2', 'clutrr_k3', 'clutrr_k4']
group2_tasks = ['sem_eval_2010_task_8', 'sciq', 'piqa', 'aqua_rat', 'ag_news', 'conll2003']
group1_tasks_lower = [t.lower() for t in original_group1_tasks + new_group1_tasks]; group2_tasks_lower = [t.lower() for t in group2_tasks]
group1_name = 'Group 1 (Mixed Tasks)'; group2_name = 'Group 2 (NLP or Reasoning)'
assigned_tasks_count = {'Group 1': 0, 'Group 2': 0}
def assign_group(task_name):
    task_name_lower = task_name.lower()
    if task_name_lower in group2_tasks_lower: assigned_tasks_count['Group 2'] += 1; return group2_name
    else: assigned_tasks_count['Group 1'] += 1; return group1_name
df['group'] = df.index.map(assign_group)
print(f"\nAll {len(df)} tasks assigned: {assigned_tasks_count['Group 1']} to '{group1_name}', {assigned_tasks_count['Group 2']} to '{group2_name}'.")
if df.empty: print("\nError: No tasks available for analysis."); exit()

# --- 3. Define Prediction Functions ---
def safe_get(row, key, default=0.0):
    val = row.get(key, default); return default if val is None or not np.isfinite(val) else float(val)
def predict_min_sample_size_manual_group1(row):
    W_K_LD_G1, W_K_SD_G1, K_DIFFICULTY_BASE_G1 = 1e-1, 4e0, 1e0
    W_D_ED_G1, W_D_VD_G1, W_D_ND_G1, W_D_HY_G1, D_DIFFICULTY_BASE_G1 = 1e0, 1e0, 1e0, 1e0, 1e0
    W_L_LD_G1, W_L_SD_G1, W_L_VD_G1, W_L_HY_G1 = 1e0, 1e0, 1e0, 1e0
    C_SCALE_G1, C_BASE_G1, MIN_K_FOR_LOG_G1, MIN_PREDICTION_FLOOR_G1 = 8e0, 0e0, 1e0, 1e2
    l_d, s_d, e_d, v_d, n_d, H_Y = safe_get(row,'local_consistency',0.5), safe_get(row,'separability_score',0.0), safe_get(row,'effective_dim',10.0), safe_get(row,'intra_class_var',1.0), safe_get(row,'num_classes',2.0), safe_get(row,'label_entropy',0.7)
    k_comp_ld, k_comp_sd = W_K_LD_G1 * max(0.001,(1.001-l_d)), W_K_SD_G1 * max(0.001,(0.251-s_d))
    K_difficulty_approx = K_DIFFICULTY_BASE_G1 + k_comp_ld + k_comp_sd
    K_difficulty_approx_for_log = max(MIN_K_FOR_LOG_G1, K_difficulty_approx)
    D_difficulty_approx = max(0.001, D_DIFFICULTY_BASE_G1 + W_D_ED_G1*e_d + W_D_VD_G1*v_d + W_D_ND_G1*n_d + W_D_HY_G1*H_Y)
    L_clarity_approx = max(0.001, (W_L_LD_G1*l_d) + (W_L_SD_G1*(s_d+1.001)) + (W_L_VD_G1*(1.0/(1.001+max(0,v_d)))) + (W_L_HY_G1*(1.0/(1.001+max(0,H_Y)))))
    k_log_k_term = K_difficulty_approx_for_log * np.log(K_difficulty_approx_for_log)
    predicted_N_min = max(MIN_PREDICTION_FLOOR_G1, C_BASE_G1 + (C_SCALE_G1 * (k_log_k_term * D_difficulty_approx)) / max(0.001, L_clarity_approx))
    return MIN_PREDICTION_FLOOR_G1 * 10 if not np.isfinite(predicted_N_min) else predicted_N_min
def predict_min_sample_size_manual_group2(row): # Using G2 specific constants (can be same as G1 if desired)
    W_K_LD_G2, W_K_SD_G2, K_DIFFICULTY_BASE_G2 = 1e-1, 1e-1, 1e0 # Adjusted W_K_SD
    W_D_ED_G2, W_D_VD_G2, W_D_ND_G2, W_D_HY_G2, D_DIFFICULTY_BASE_G2 = 1e-1, 1e-1, 1e-1, 1e-1, 1e0
    W_L_LD_G2, W_L_SD_G2, W_L_VD_G2, W_L_HY_G2, L_CLARITY_OFFSET_G2 = 1e0, 1e0, 1e0, 1e0, 1e0
    C_OVERALL_G2, MIN_EFFECTIVE_DIFFICULTY_FOR_LOG_G2, MIN_PREDICTION_FLOOR_G2 = 8e0, 1.1e0, 1e2
    l_d, s_d, e_d, v_d, n_d, H_Y = safe_get(row,'local_consistency',0.5), safe_get(row,'separability_score',0.0), safe_get(row,'effective_dim',10.0), safe_get(row,'intra_class_var',1.0), safe_get(row,'num_classes',2.0), safe_get(row,'label_entropy',0.7)
    K_difficulty_approx = max(0.001, K_DIFFICULTY_BASE_G2 + (W_K_LD_G2*max(0.001,(1.001-l_d))) + (W_K_SD_G2*max(0.001,(0.251-s_d))))
    D_difficulty_approx = max(0.001, D_DIFFICULTY_BASE_G2 + W_D_ED_G2*e_d + W_D_VD_G2*v_d + W_D_ND_G2*n_d + W_D_HY_G2*H_Y)
    L_clarity_approx = max(0.001, (W_L_LD_G2*l_d) + (W_L_SD_G2*(s_d+1.001)) + (W_L_VD_G2*(1.0/(1.001+max(0,v_d)))) + (W_L_HY_G2*(1.0/(1.001+max(0,H_Y)))))
    Effective_Difficulty_K_D = max(MIN_EFFECTIVE_DIFFICULTY_FOR_LOG_G2, K_difficulty_approx * D_difficulty_approx)
    k_log_k_term = Effective_Difficulty_K_D * np.log(Effective_Difficulty_K_D)
    denominator = L_CLARITY_OFFSET_G2 + L_clarity_approx
    predicted_N_min = max(MIN_PREDICTION_FLOOR_G2, (C_OVERALL_G2 * k_log_k_term) / (denominator if abs(denominator)>1e-9 else 1e9)) # Avoid div by zero
    return MIN_PREDICTION_FLOOR_G2 * 10 if not np.isfinite(predicted_N_min) else predicted_N_min

# --- 4. Calculate Original Predictions ---
print("\n--- Calculating Original Predictions ---")
df['predicted_min_sample_size_grouped'] = df.apply(lambda r: predict_min_sample_size_manual_group1(r) if r['group']==group1_name else predict_min_sample_size_manual_group2(r), axis=1)
print("Original predictions calculated.")

# --- 5. Calculate Original Evaluation Metrics ---
df[target] = pd.to_numeric(df[target], errors='coerce')
initial_rows = len(df); valid_df = df.dropna(subset=[target, 'predicted_min_sample_size_grouped']).copy()
if initial_rows - len(valid_df) > 0: print(f"Dropped {initial_rows - len(valid_df)} rows due to NaNs in target/prediction.")
evaluation_metrics = {}
if len(valid_df) < 2: print(f"\nError: Insufficient valid data ({len(valid_df)}) for metrics."); exit()
true_values, predicted_values = valid_df[target].astype(float), valid_df['predicted_min_sample_size_grouped'].astype(float)
evaluation_metrics.update({'num_initial_samples':initial_rows, 'num_valid_samples':len(valid_df)})
print("\n--- Evaluation Metrics (Original - Combined Groups) ---"); print(f"Based on {len(valid_df)} valid data points:")
print("\n-- Correlation Metrics --")
for corr_func, name in [(spearmanr, "Spearman"), (pearsonr, "Pearson"), (kendalltau, "Kendall's Tau")]:
    corr, p_val = corr_func(true_values, predicted_values)
    evaluation_metrics[f'{name.lower().replace(" ", "_").replace("s_tau", "tau").replace("spearman","spearman_rho").replace("pearson","pearson_r")}'] = corr
    evaluation_metrics[f'{name.lower().replace(" ", "_").replace("s_tau", "tau").replace("spearman","spearman_p").replace("pearson","pearson_p")}'] = p_val
    print(f"{name:<20} Correlation: {corr:7.4f}, p-value: {p_val:.4f}")
print("\n-- Prediction Error Metrics --")
mae, mse = mean_absolute_error(true_values, predicted_values), mean_squared_error(true_values, predicted_values)
rmse, r2 = np.sqrt(mse), r2_score(true_values, predicted_values)
non_zero_mask = true_values != 0; mape = np.nan
if np.any(non_zero_mask):
    pred_for_mape = predicted_values[non_zero_mask].copy(); pred_for_mape[pred_for_mape <= 0] = 1e-9
    mape = mean_absolute_percentage_error(true_values[non_zero_mask], pred_for_mape) * 100
evaluation_metrics.update({'mae':mae, 'rmse':rmse, 'mape':mape if not np.isnan(mape) else None, 'r2':r2})
print(f"MAE: {mae:.2f}, RMSE: {rmse:.2f}, R²: {r2:.4f}")
if not np.isnan(mape): 
    print(f"MAPE: {mape:.2f}%") 
else: print("MAPE: N/A")

print("\n-- Within-Group Spearman Correlations (Baseline) --")
valid_df_g1 = valid_df[valid_df['group'] == group1_name].copy(); valid_df_g2 = valid_df[valid_df['group'] == group2_name].copy()
evaluation_metrics.update({'num_valid_samples_g1':len(valid_df_g1), 'num_valid_samples_g2':len(valid_df_g2)})
original_spearman_rho_g1, original_spearman_p_g1 = (np.nan, np.nan) if len(valid_df_g1)<2 else spearmanr(valid_df_g1[target].astype(float), valid_df_g1['predicted_min_sample_size_grouped'].astype(float))
evaluation_metrics.update({'spearman_rho_g1':original_spearman_rho_g1, 'spearman_p_g1':original_spearman_p_g1})
print(f"{group1_name} ({len(valid_df_g1)} pts): rho={original_spearman_rho_g1:.4f}, p={original_spearman_p_g1:.4f}" if len(valid_df_g1)>=2 else f"{group1_name} insufficient data.")
original_spearman_rho_g2, original_spearman_p_g2 = (np.nan, np.nan) if len(valid_df_g2)<2 else spearmanr(valid_df_g2[target].astype(float), valid_df_g2['predicted_min_sample_size_grouped'].astype(float))
evaluation_metrics.update({'spearman_rho_g2':original_spearman_rho_g2, 'spearman_p_g2':original_spearman_p_g2})
print(f"{group2_name} ({len(valid_df_g2)} pts): rho={original_spearman_rho_g2:.4f}, p={original_spearman_p_g2:.4f}" if len(valid_df_g2)>=2 else f"{group2_name} insufficient data.")

# --- 6. Ablation Study Functions ---
def run_ablation_study(group_df, group_name_str, pred_func, orig_rho, features_list, target_col):
    print(f"\n--- Ablation for {group_name_str} ---"); results = {}
    if group_df.empty or len(group_df)<2 or (isinstance(orig_rho, float) and np.isnan(orig_rho)): print(f"Skipping: Insufficient data or NaN rho."); return None
    print(f"Original Rho ({len(group_df)} tasks): {orig_rho:.4f}"); true_vals_group = group_df[target_col].astype(float)
    for feat_ablate in features_list:
        print(f"  Ablating: {feat_ablate}"); df_abl = group_df.copy()
        if feat_ablate in df_abl.columns: df_abl[feat_ablate] = 0.0
        else: print(f"    Warn: '{feat_ablate}' not found. Skipping."); results[feat_ablate]={'ablated_rho':np.nan, 'abs_change':np.nan}; continue
        df_abl['pred_abl'] = df_abl.apply(pred_func, axis=1); df_abl.dropna(subset=['pred_abl'], inplace=True)
        aligned_true = true_vals_group.loc[df_abl.index]; rho_abl, change_abl, n_comp = np.nan, np.nan, len(df_abl)
        if n_comp<2: print(f"    Warn: Insufficient data ({n_comp}) post-ablation.")
        else:
            try: rho_abl, _ = spearmanr(aligned_true, df_abl['pred_abl'])
            except ValueError as ve: print(f"    Error Spearman: {ve}."); rho_abl = np.nan
            if not np.isfinite(rho_abl): print(f"    Warn: Spearman non-finite."); rho_abl = np.nan
            else: change_abl = abs(orig_rho - rho_abl); print(f"    Ablated Rho: {rho_abl:.4f}, Change: {change_abl:.4f} (N={n_comp})")
        results[feat_ablate] = {'ablated_rho':rho_abl, 'abs_change':change_abl}
    return results
def plot_ablation_results(ablation_data, group_name_str, out_dir_path):
    if ablation_data is None: print(f"\nNo ablation data for {group_name_str}."); return None
    ablation_df = pd.DataFrame(ablation_data).T.dropna(subset=['abs_change'])
    if ablation_df.empty: print(f"\nWarn: No valid ablation results for {group_name_str}."); return None
    ablation_df.sort_values('abs_change', ascending=False, inplace=True); plt.figure(figsize=(10,6))
    bars = plt.bar(ablation_df.index, ablation_df['abs_change'], color=NATURE_LIGHT_BLUE, edgecolor='black', linewidth=0.8)
    plt.xlabel("Ablated Feature", fontsize=LABEL_FONTSIZE); plt.ylabel("Abs Change in Spearman Rho", fontsize=LABEL_FONTSIZE)
    plt.title(f"Feature Ablation Impact ({group_name_str})", fontsize=TITLE_FONTSIZE)
    plt.xticks(rotation=45, ha='right', fontsize=TICK_FONTSIZE); plt.yticks(fontsize=TICK_FONTSIZE)
    plt.grid(axis='y', linestyle='--', alpha=0.6, linewidth=0.5); plt.tight_layout(pad=1.5)
    for bar in bars: yval=bar.get_height(); plt.text(bar.get_x()+bar.get_width()/2.0, yval, f'{yval:.3f}', va='bottom', ha='center', fontsize=ANNOTATION_FONTSIZE+3, color='black') # Bar label font
    plot_filename = f'ablation_rho_change_{group_name_str.replace(" ","_").replace("(","").replace(")","").lower()[:15]}_nature.png'
    plt.savefig(os.path.join(out_dir_path, plot_filename), dpi=300, bbox_inches='tight')
    print(f"\nAblation plot for {group_name_str} saved."); plt.close()
    print(f"\n--- Ablation Summary ({group_name_str}) ---\n{ablation_df[['abs_change','ablated_rho']].to_string(float_format='%.4f')}"); return ablation_df

# --- 7. Run Separate Ablation Studies ---
ablation_results_g1 = run_ablation_study(valid_df_g1, group1_name, predict_min_sample_size_manual_group1, original_spearman_rho_g1, features, target)
ablation_results_g2 = run_ablation_study(valid_df_g2, group2_name, predict_min_sample_size_manual_group2, original_spearman_rho_g2, features, target)

# --- 8. Visualize Ablation Results ---
ablation_df_g1 = plot_ablation_results(ablation_results_g1, group1_name, output_dir)
ablation_df_g2 = plot_ablation_results(ablation_results_g2, group2_name, output_dir)

# --- 9. Visualize Original Results (Main Scatter Plot - Nature Style) ---
output_path = os.path.join(output_dir, 'manual_prediction_vs_actual_NATURE_STYLE_with_std_shadow.png')
plt.figure(figsize=(12, 12))
colors = {group1_name: NATURE_BLUE, group2_name: NATURE_ORANGE}
markers = {group1_name: 'o', group2_name: 's'}

# Parameters for standard deviation shadow
NUM_POINTS_FOR_STD_CALC = 75  # Increased for smoother curve
WINDOW_FACTOR_STD = 2.0     # Multiplicative window factor for locality
SMOOTH_STD_DEV_SHADOW = True # Enable/disable smoothing of std dev values
STD_DEV_SMOOTHING_WINDOW = 5 # Window for moving average (must be odd if using some filters like SavGol, or just >1 for rolling mean)

if not valid_df.empty:
    plot_df = valid_df.copy()
    plot_df[target] = pd.to_numeric(plot_df[target], errors='coerce')
    plot_df['predicted_min_sample_size_grouped'] = pd.to_numeric(plot_df['predicted_min_sample_size_grouped'], errors='coerce')
    plot_df.dropna(subset=[target, 'predicted_min_sample_size_grouped'], inplace=True)
    plot_df = plot_df[(plot_df[target] > 1e-9) & (plot_df['predicted_min_sample_size_grouped'] > 1e-9)] # Ensure positive for log

    if not plot_df.empty:
        true_values_log = plot_df[target]
        predicted_values_log = plot_df['predicted_min_sample_size_grouped']
        min_val = max(1.0, min(true_values_log.min(), predicted_values_log.min()))
        max_val = max(true_values_log.max(), predicted_values_log.max())
        x_min_plot, y_min_plot = max(min_val * 0.5, 40), max(min_val * 0.5, 40)
        x_max_plot, y_max_plot = max_val * 2.0, max_val * 2.0
        plt.xlim(x_min_plot, x_max_plot); plt.ylim(y_min_plot, y_max_plot)
        line_min_plot, line_max_plot = min(x_min_plot, y_min_plot), max(x_max_plot, y_max_plot)
        line_x_coords = np.array([line_min_plot, line_max_plot])

        plt.plot(line_x_coords, line_x_coords, color='red', linestyle='--', linewidth=1.5, label='Ideal Fit (y=x)')

        # --- START: Calculate and Plot Standard Deviation Shadow ---
        if len(plot_df) > 1:
            actual_vals_std = plot_df[target].values # Renamed
            predicted_vals_std = plot_df['predicted_min_sample_size_grouped'].values # Renamed
            min_actual_std, max_actual_std = actual_vals_std.min(), actual_vals_std.max() # Renamed
            
            x_centers_for_std = []
            if max_actual_std > min_actual_std + 1e-9 : # Ensure range is valid for geomspace
                 x_centers_for_std = np.geomspace(max(1e-9, min_actual_std), max_actual_std, num=NUM_POINTS_FOR_STD_CALC)
                 x_centers_for_std = np.unique(x_centers_for_std) # Ensure unique points, sorted
            else: # Handle cases with very small range or single unique X value
                 x_centers_for_std = np.unique(actual_vals_std[actual_vals_std > 1e-9])

            if len(x_centers_for_std) > 1:
                local_stds_list = [] # Renamed
                for x_pt in x_centers_for_std: # Renamed
                    min_x_win, max_x_win = x_pt / WINDOW_FACTOR_STD, x_pt * WINDOW_FACTOR_STD # Renamed
                    idx_nearby = (actual_vals_std >= min_x_win) & (actual_vals_std <= max_x_win) # Renamed
                    nearby_actual_x, nearby_pred_y = actual_vals_std[idx_nearby], predicted_vals_std[idx_nearby] # Renamed
                    if len(nearby_actual_x) > 1: local_stds_list.append(np.std(nearby_pred_y - nearby_actual_x))
                    else: local_stds_list.append(np.nan)
                
                local_stds_arr = np.array(local_stds_list)
                valid_std_idx = ~np.isnan(local_stds_arr) # Renamed
                x_for_fill, stds_for_fill = x_centers_for_std[valid_std_idx], local_stds_arr[valid_std_idx]

                if len(x_for_fill) > 1:
                    # --- Optional Smoothing of Standard Deviations ---
                    stds_to_plot = stds_for_fill
                    if SMOOTH_STD_DEV_SHADOW and len(stds_for_fill) >= STD_DEV_SMOOTHING_WINDOW:
                        # Using a simple rolling mean (convolve)
                        # Ensure window is not larger than data
                        current_smoothing_window = min(STD_DEV_SMOOTHING_WINDOW, len(stds_for_fill))
                        if current_smoothing_window > 1: # Only smooth if window is > 1
                            stds_to_plot = np.convolve(stds_for_fill, np.ones(current_smoothing_window)/current_smoothing_window, mode='same')
                            # For 'same' mode, edge effects might make first/last few points less accurate, but maintains length
                            # To mitigate edge effects for 'same' mode, one could pad or use Savitzky-Golay for more complex cases.
                            # For this visualization, 'same' is often acceptable.
                    # --- End Smoothing ---

                    ideal_y_fill = x_for_fill # Renamed
                    upper_bnd, lower_bnd = ideal_y_fill + stds_to_plot, ideal_y_fill - stds_to_plot # Renamed
                    lower_bnd = np.maximum(lower_bnd, 1e-9) # Ensure positive for log scale (can also use y_min_plot * 0.1 or similar)
                    plt.fill_between(x_for_fill, lower_bnd, upper_bnd, color=NATURE_GREY, alpha=0.25, label='Local Std Dev (Smoothed)') # Increased alpha slightly
        # --- END: Calculate and Plot Standard Deviation Shadow ---

        plt.plot(line_x_coords, line_x_coords*2, color=NATURE_GREY, ls=':', lw=1.0, alpha=0.8, label='Factor of 2')
        plt.plot(line_x_coords, line_x_coords/2, color=NATURE_GREY, ls=':', lw=1.0, alpha=0.8)
        plt.plot(line_x_coords, line_x_coords*5, color=NATURE_GREY, ls=':', lw=0.8, alpha=0.6, label='Factor of 5')
        plt.plot(line_x_coords, line_x_coords/5, color=NATURE_GREY, ls=':', lw=0.8, alpha=0.6)

        for grp_name_key, grp_df_plot in plot_df.groupby('group'): # Renamed
            if grp_name_key in colors:
                plt.scatter(grp_df_plot[target], grp_df_plot['predicted_min_sample_size_grouped'],
                            alpha=0.75, edgecolors='k', linewidths=0.5, s=180,
                            c=colors[grp_name_key], marker=markers[grp_name_key],
                            label=f"{grp_name_key} (N={len(grp_df_plot)})")
        plt.xscale('log'); plt.yscale('log')
        plt.tick_params(axis='both', which='major', labelsize=TICK_FONTSIZE)
        plt.tick_params(axis='both', which='minor', length=3, color='grey')
        texts = []
        for i, task_name_iter in enumerate(plot_df.index):
            x_pos, y_pos = plot_df[target].iloc[i], plot_df['predicted_min_sample_size_grouped'].iloc[i]
            x_offset_factor, y_offset_factor = 1.15, 1.05; tn_l = task_name_iter.lower() # Renamed
            if tn_l=='aqua_rat': y_offset_factor=1.3; x_offset_factor=0.9
            elif tn_l=='sciq': y_offset_factor=0.8; x_offset_factor=0.9
            elif tn_l=='adult': x_offset_factor=0.85; y_offset_factor=0.9
            elif tn_l=='ag_news': y_offset_factor=0.85; x_offset_factor=1.1
            elif tn_l=='mnist': y_offset_factor=1.15; x_offset_factor=0.85
            elif tn_l=='sem_eval_2010_task_8': y_offset_factor=1.1; x_offset_factor=0.8
            elif tn_l=='fashionmnist': y_offset_factor=0.85; x_offset_factor=1.05
            elif tn_l=='spambase': x_offset_factor=1.2
            elif tn_l=='speech_commands': y_offset_factor=1.2; x_offset_factor=0.85
            elif tn_l=='cifar10': x_offset_factor=0.8
            elif tn_l=='food101': y_offset_factor=0.85; x_offset_factor=0.85
            elif tn_l=='flowers102': y_offset_factor=0.85; x_offset_factor=1.1
            elif tn_l=='svhn': x_offset_factor=1.1
            texts.append(plt.text(x_pos*x_offset_factor, y_pos*y_offset_factor, f" {task_name_iter}", fontsize=POINT_LABEL_FONTSIZE, va='center', ha='left'))
        if texts: adjust_text(texts)
        plt.xlabel("Actual Minimum Sample Size (Log Scale)", fontsize=LABEL_FONTSIZE)
        plt.ylabel("Predicted Minimum Sample Size (Log Scale)", fontsize=LABEL_FONTSIZE)
        corr_str = f"ρ = {evaluation_metrics.get('spearman_rho', np.nan):.3f}"
        p_val_disp = evaluation_metrics.get('spearman_p', np.nan)
        p_str = "p=N/A" if np.isnan(p_val_disp) else ("p < 0.001" if p_val_disp < 0.001 else f"p={p_val_disp:.3f}")
        plt.title(f"Prediction vs. Actual (N={len(plot_df)})\nOverall Spearman {corr_str}, {p_str}", fontsize=TITLE_FONTSIZE)
        plt.legend(fontsize=LEGEND_FONTSIZE, loc='best', frameon=True, framealpha=0.8, facecolor='white')
        plt.grid(True, which="major", ls="--", linewidth=0.5, alpha=0.6)
        plt.grid(True, which="minor", ls=":", linewidth=0.3, alpha=0.4)
        plt.tight_layout(pad=1.0); plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"\nGrouped visualization chart saved to {output_path}"); plt.close()
    else: print("\nWarning: No positive pairs for log scale plotting."); plt.close(plt.gcf()) # Ensure figure is closed
else: print("\nNot enough valid data for main scatter plot."); plt.close(plt.gcf()) # Ensure figure is closed

# --- 10. Save Original Predictions to CSV ---
print("\n--- Saving Original Prediction Results to CSV ---")
output_csv_path = os.path.join(output_dir, 'manual_prediction_grouped_results.csv')
if not df.empty:
    save_cols = ['group', target, 'predicted_min_sample_size_grouped'] + features
    existing_cols = [col for col in save_cols if col in df.columns] # Renamed
    if set(save_cols) - set(existing_cols): print(f"Warn: Missing cols for CSV: {set(save_cols)-set(existing_cols)}")
    if existing_cols:
        try: df[existing_cols].sort_index().to_csv(output_csv_path, index=True, index_label='task_name', float_format='%.4f'); print(f"Results saved to {output_csv_path}")
        except Exception as e: print(f"Error saving CSV: {e}")
    else: print("Warn: No valid columns to save to CSV.")
else: print("DataFrame empty, no results to save.")

# --- 10b. Display the DataFrame with original predictions ---
print("\n--- True Value vs. Original Predicted Value Comparison ---")
pd.set_option('display.float_format', lambda x_val: '%.2f' % x_val)
if not valid_df.empty:
    disp_cols = [target, 'predicted_min_sample_size_grouped', 'group'] # Renamed
    if all(col in valid_df.columns for col in disp_cols):
        with pd.option_context('display.max_rows', None, 'display.max_columns', None): print(valid_df.sort_index()[disp_cols])
    else: print(f"Warn: Missing display columns in valid_df: {set(disp_cols) - set(valid_df.columns)}")
else: print("valid_df empty, cannot display comparison.")
pd.reset_option('display.float_format')

# --- 11. Interpretation ---
print("\n--- Results Interpretation ---")
print(f"Analysis for {evaluation_metrics.get('num_initial_samples',0)} tasks, split: '{group1_name}' ({evaluation_metrics.get('num_valid_samples_g1',0)} valid), '{group2_name}' ({evaluation_metrics.get('num_valid_samples_g2',0)} valid). Eval on {evaluation_metrics.get('num_valid_samples',0)} tasks.")
print("\nKey Original Eval Findings (Combined):")
rho_d, p_d = evaluation_metrics.get('spearman_rho',np.nan), evaluation_metrics.get('spearman_p',np.nan) # Renamed
sig_d = "p=N/A" if np.isnan(p_d) else ("sig (p<0.05)" if p_d<0.05 else "not sig (p>=0.05)") # Renamed
print(f"- Combined Spearman Rho: ρ={rho_d:.3f}, {sig_d}")
print(f"- MAE: {evaluation_metrics.get('mae',np.nan):.2f}, RMSE: {evaluation_metrics.get('rmse',np.nan):.2f}, MAPE: {evaluation_metrics.get('mape', 'N/A')}{'%' if evaluation_metrics.get('mape') is not None else ''}")
print("\nGroup-Specific Baseline Performance:")
for i, (g_name, rho_g, p_g, n_g) in enumerate([(group1_name, evaluation_metrics.get('spearman_rho_g1',np.nan), evaluation_metrics.get('spearman_p_g1',np.nan), evaluation_metrics.get('num_valid_samples_g1',0)),
                                       (group2_name, evaluation_metrics.get('spearman_rho_g2',np.nan), evaluation_metrics.get('spearman_p_g2',np.nan), evaluation_metrics.get('num_valid_samples_g2',0))]):
    sig_g = "p=N/A" if np.isnan(p_g) else ("sig (p<0.05)" if p_g<0.05 else "not sig (p>=0.05)")
    print(f"- {g_name} Spearman: ρ={rho_g:.3f} ({sig_g}, N={n_g})")
print("\nAblation Study Insights:")
for i, (g_name, df_abl, res_abl, orig_rho_g) in enumerate([(group1_name, ablation_df_g1, ablation_results_g1, original_spearman_rho_g1),
                                               (group2_name, ablation_df_g2, ablation_results_g2, original_spearman_rho_g2)]):
    if df_abl is not None and not df_abl.empty: print(f"- For {g_name}, '{df_abl.index[0]}' largest impact (rho change: {df_abl['abs_change'].iloc[0]:.3f}). See plot.")
    elif res_abl is None or (isinstance(orig_rho_g, float) and np.isnan(orig_rho_g)): print(f"- Ablation skipped/invalid for {g_name}.")
    else: print(f"- Ablation for {g_name} no valid importance results.")
print("\nOverall Conclusion: Strong rank correlation. Ablation highlights key metrics per group.")

# --- 12. Save Evaluation Metrics to JSON ---
print("\n--- Saving Evaluation Metrics to JSON ---")
metrics_output_path = os.path.join(output_dir, 'evaluation_metrics_full.json')
def make_serializable(item): # Renamed
    if isinstance(item, (np.integer, np.int_)): return int(item)
    if isinstance(item, (np.floating, float)): return None if np.isnan(item) or np.isinf(item) else float(item)
    if isinstance(item, np.ndarray): return [make_serializable(i) for i in item.tolist()]
    if isinstance(item, dict): return {k: make_serializable(v) for k, v in item.items()}
    if isinstance(item, (list, tuple)): return [make_serializable(i) for i in item]
    if pd.isna(item) or item is None: return None
    if isinstance(item, np.bool_): return bool(item)
    try: json.dumps(item); return item
    except TypeError: return str(item)
try:
    serializable_metrics = make_serializable(evaluation_metrics)
    serializable_metrics['ablation_study_group1'] = make_serializable(ablation_results_g1) if ablation_results_g1 else None
    serializable_metrics['ablation_study_group2'] = make_serializable(ablation_results_g2) if ablation_results_g2 else None
    final_serializable_metrics = make_serializable(serializable_metrics) # Final pass
    with open(metrics_output_path, 'w') as f_json: json.dump(final_serializable_metrics, f_json, indent=4, allow_nan=False)
    print(f"Evaluation metrics saved to {metrics_output_path}")
except Exception as e: print(f"Error saving metrics JSON: {e}")
print("\n--- Analysis Complete ---")