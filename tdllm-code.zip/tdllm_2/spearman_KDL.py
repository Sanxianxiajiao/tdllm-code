import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from scipy.stats import spearmanr, pearsonr, kendalltau # Import pearsonr and kendalltau
import os
# No need for re if not used

# --- 0. Configuration and Constants ---
INPUT_CSV_FILE = '/home/mqc/tdllm_2/pic/manual_prediction_grouped_mixedG1_results.csv'
OUTPUT_DIR = './pic_clutter/'
OUTPUT_CSV_FILE = os.path.join(OUTPUT_DIR, 'KDL_correlations.csv') # Changed filename for clarity

# Define feature columns based on your CSV header
FEATURES_RAW_NAMES = [
    'num_classes',
    'label_entropy',
    'effective_dim',
    'intra_class_var',
    'local_consistency',
    'separability_score'
]
TARGET_COLUMN = 'min_sample_size'
KDL_FEATURES = ['K', 'D', 'L'] # These will be the calculated K, D, L scores

# --- 1. Create Output Directory ---
os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"Output directory '{OUTPUT_DIR}' ensured.")

# --- 2. Load Data from CSV ---
print(f"Loading data from {INPUT_CSV_FILE}...")
try:
    df = pd.read_csv(INPUT_CSV_FILE)
    print(f"Successfully loaded {len(df)} rows from the CSV.")
except FileNotFoundError:
    print(f"Error: Input CSV file not found at '{INPUT_CSV_FILE}'. Please check the path and filename.")
    exit()
except Exception as e:
    print(f"Error loading CSV file: {e}")
    exit()

# --- 3. Validate and Prepare Data ---
# Check for essential columns
required_columns = FEATURES_RAW_NAMES + [TARGET_COLUMN, 'task_name']
missing_cols = [col for col in required_columns if col not in df.columns]
if missing_cols:
    print(f"Error: The following required columns are missing from the CSV: {', '.join(missing_cols)}")
    exit()

# Convert relevant columns to numeric, coercing errors
for col in FEATURES_RAW_NAMES + [TARGET_COLUMN]:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Handle potential missing values after coercion
df_cleaned = df.dropna(subset=FEATURES_RAW_NAMES + [TARGET_COLUMN])
if len(df_cleaned) < len(df):
    print(f"Warning: Dropped {len(df) - len(df_cleaned)} rows due to missing/non-numeric values in essential columns.")
if df_cleaned.empty:
    print("Error: No valid data remains after cleaning. Cannot proceed.")
    exit()

print(f"Data prepared. Using {len(df_cleaned)} rows for analysis.")
df_scaled = df_cleaned.copy()

# --- 4. Standardize Proxy Metrics and Target ---
print("Standardizing proxy metrics and target variable (min_sample_size)...")
scaler_proxies = MinMaxScaler()
df_scaled[FEATURES_RAW_NAMES] = scaler_proxies.fit_transform(df_cleaned[FEATURES_RAW_NAMES])

scaler_target = MinMaxScaler()
df_scaled[TARGET_COLUMN + '_scaled'] = scaler_target.fit_transform(df_cleaned[[TARGET_COLUMN]])

rename_map_proxies = {
    'effective_dim': 'e_d_scaled',
    'num_classes': 'n_d_scaled',
    'label_entropy': 'H_Y_scaled',
    'intra_class_var': 'v_d_scaled',
    'local_consistency': 'l_d_scaled',
    'separability_score': 's_d_scaled'
}
df_scaled.rename(columns=rename_map_proxies, inplace=True)

SCALED_PROXY_NAMES = list(rename_map_proxies.values()) # Get scaled names from the map
print("Standardization complete.")
print("Scaled proxy columns available:", SCALED_PROXY_NAMES)
print("Scaled target column:", TARGET_COLUMN + '_scaled')

# --- 5. Calculate K, D, L Scores ---
print("Calculating K, D, L scores...")
# K = ( (1 - local_consistency_scaled) + (1 - separability_score_scaled) ) / 2
df_scaled['K'] = ( (1 - df_scaled['l_d_scaled']) + \
                   (1 - df_scaled['s_d_scaled']) ) / 2

# D = mean(effective_dim_scaled, num_classes_scaled, label_entropy_scaled, intra_class_var_scaled)
df_scaled['D'] = df_scaled[['e_d_scaled', 'n_d_scaled', 'H_Y_scaled', 'v_d_scaled']].mean(axis=1)

# L = ( (1 - label_entropy_scaled) + (1 - intra_class_var_scaled) + local_consistency_scaled + separability_score_scaled ) / 4
df_scaled['L'] = ( (1 - df_scaled['H_Y_scaled']) + \
                   (1 - df_scaled['v_d_scaled']) + \
                   df_scaled['l_d_scaled'] + \
                   df_scaled['s_d_scaled'] ) / 4
print("K, D, L scores calculated.")
print("Sample KDL scores (first 5 rows):")
print(df_scaled[['task_name'] + KDL_FEATURES].head())


# --- 6. Calculate Spearman, Pearson, and Kendall Correlations ---
print(f"\nCalculating correlations between K, D, L and '{TARGET_COLUMN}_scaled'...")
correlation_results_list = [] # Use a list to store dicts for the DataFrame

target_series = df_scaled[TARGET_COLUMN + '_scaled']

for kdl_feature in KDL_FEATURES:
    print(f"\n--- Correlations for {kdl_feature} ---")
    feature_series = df_scaled[kdl_feature]
    result_row = {'KDL_Factor': kdl_feature}

    # Basic checks for valid correlation calculation
    if feature_series.isnull().all() or target_series.isnull().all():
        print(f"Warning: All null values for '{kdl_feature}' or target. Correlations will be NaN.")
        result_row.update({
            'Spearman_Rho': np.nan, 'Spearman_P_Value': np.nan,
            'Pearson_R': np.nan, 'Pearson_P_Value': np.nan,
            'Kendall_Tau': np.nan, 'Kendall_P_Value': np.nan
        })
    elif feature_series.nunique() < 2 or target_series.nunique() < 2:
        print(f"Warning: Not enough unique values in '{kdl_feature}' or target. Correlations will be NaN.")
        result_row.update({
            'Spearman_Rho': np.nan, 'Spearman_P_Value': np.nan,
            'Pearson_R': np.nan, 'Pearson_P_Value': np.nan,
            'Kendall_Tau': np.nan, 'Kendall_P_Value': np.nan
        })
    else:
        # Spearman Correlation
        rho_s, p_s = spearmanr(feature_series, target_series, nan_policy='omit')
        result_row['Spearman_Rho'] = rho_s
        result_row['Spearman_P_Value'] = p_s
        print(f"  Spearman Rho: {rho_s:.4f} (p-value: {p_s:.4g})")

        # Pearson Correlation
        # pearsonr returns a tuple (correlation, p-value)
        # For older scipy versions, it might raise an error if input contains NaNs,
        # but nan_policy='omit' is not an arg. We've already dropped NaNs in df_cleaned.
        try:
            # Pearson correlation assumes continuous data and can be sensitive to outliers.
            # Our KDL scores are derived from scaled proxies, which is fine.
            rho_p, p_p = pearsonr(feature_series.dropna(), target_series.dropna()) # Ensure no NaNs for pearsonr
            result_row['Pearson_R'] = rho_p
            result_row['Pearson_P_Value'] = p_p
            print(f"  Pearson R:  {rho_p:.4f} (p-value: {p_p:.4g})")
        except Exception as e:
            print(f"  Could not calculate Pearson correlation for {kdl_feature}: {e}")
            result_row['Pearson_R'] = np.nan
            result_row['Pearson_P_Value'] = np.nan


        # Kendall Tau Correlation
        # kendalltau also returns a tuple (correlation, p-value)
        tau_k, p_k = kendalltau(feature_series, target_series, nan_policy='omit')
        result_row['Kendall_Tau'] = tau_k
        result_row['Kendall_P_Value'] = p_k
        print(f"  Kendall Tau:  {tau_k:.4f} (p-value: {p_k:.4g})")

    correlation_results_list.append(result_row)

df_correlations = pd.DataFrame(correlation_results_list)

# --- 7. Save Results ---
try:
    # Define the order of columns for the output CSV
    column_order = [
        'KDL_Factor',
        'Spearman_Rho', 'Spearman_P_Value',
        'Pearson_R', 'Pearson_P_Value',
        'Kendall_Tau', 'Kendall_P_Value'
    ]
    df_correlations = df_correlations[column_order] # Reorder columns
    df_correlations.to_csv(OUTPUT_CSV_FILE, index=False, float_format='%.4f') # Increased precision
    print(f"\nCorrelation results saved to {OUTPUT_CSV_FILE}")
    print("\nFinal Correlation Table:")
    print(df_correlations)
except Exception as e:
    print(f"Error saving results to CSV: {e}")

print("\nScript finished.")