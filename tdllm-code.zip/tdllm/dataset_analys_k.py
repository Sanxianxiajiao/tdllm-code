import torch
import transformers
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    pipeline # Potentially useful for easier embedding later if needed
)

from typing import Dict, Optional, Any
from datasets import load_dataset, DatasetDict, Dataset
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split as sklearn_train_test_split # Rename to avoid clash
from scipy.stats import entropy
from scipy.spatial.distance import euclidean
import pandas as pd
import os
import json
import argparse
from tqdm import tqdm
import gc # Garbage collector
import hashlib
import random
from collections import Counter, defaultdict
import ast # For CLUTRR parsing

# --- Configuration ---
# Important: Set DATA_ROOT to where your datasets are/will be downloaded
DATA_ROOT = './datasets'
# Important: Set OUTPUT_DIR for saving results
OUTPUT_DIR = './data_analys_nlp' # Corrected from your example to match script var name
# Select the embedding model
EMBEDDING_MODEL_NAME = "meta-llama/Llama-3.1-8B-Instruct" # Make sure you have access
# Metric calculation parameters
PCA_VARIANCE_THRESHOLD = 0.95
K_NEIGHBORS = 15
# Subsampling limits (adjust based on your compute resources)
MAX_SAMPLES_FOR_EMBEDDING = 1000000 # Max samples to generate embeddings for (uses stratified sampling if exceeded)
SILHOUETTE_SAMPLE_SIZE = 10000   # Max samples for Silhouette score calculation
# Embedding generation parameters
EMBEDDING_BATCH_SIZE = 4        # Adjust based on GPU memory (8B model needs small batches)
MAX_TOKEN_LENGTH = 1024          # Max sequence length for tokenizer/model
# CLUTRR specific configuration
CLUTRR_LOADER_SCRIPT_PATH = "./clutrr_loader.py"
CLUTRR_GENERAL_CONFIG_NAME = 'gen_train234_test2to10' # Assumed general config in clutrr_loader.py

# --- Device Setup ---
if torch.cuda.is_available():
    device = torch.device("cuda")
    print(f"Using CUDA device: {torch.cuda.get_device_name(0)}")
else:
    device = torch.device("cpu")
    print("Warning: CUDA not available. Using CPU. Embedding generation will be VERY slow.")

# === Dataset Loading and Preprocessing Hub ===

def load_and_preprocess_nlp_dataset(dataset_name, data_root, seed=42, k_filter_value: Optional[int] = None):
    """
    Loads, preprocesses, and formats various NLP datasets for complexity analysis.
    For CLUTRR, k_filter_value can be used to filter by a specific K.

    Returns:
        tuple: (processed_train_dataset, id_to_label_map)
               - processed_train_dataset: Dataset object with 'input_text_for_embedding' and 'label' columns.
               - id_to_label_map: Dictionary mapping integer labels back to original label names/representations.
    """
    print(f"\n--- Loading and Preprocessing: {dataset_name} ---")
    if dataset_name == 'clutrr' and k_filter_value is not None:
        print(f"--- Applying K-filter for CLUTRR: K = {k_filter_value} ---")

    raw_dataset_dict: Optional[DatasetDict] = None # Will hold the loaded DatasetDict
    # This will be the single Dataset split (e.g., 'train') that gets processed and returned
    processed_train_dataset: Optional[Dataset] = None
    id_to_label_map: Dict[int, str] = {}
    label_to_id_map: Dict[str, int] = {} # Used internally for mapping

    input_text_col = "input_text_for_embedding"
    label_col = "label"
    original_label_col = "original_label" # Temporary column for mapping

    # --- Dataset Specific Loading and Formatting ---

    if dataset_name == 'ag_news':
        raw_dataset_dict = load_dataset("ag_news", cache_dir=data_root)
        label_names = raw_dataset_dict["train"].features["label"].names
        id_to_label_map = {i: name for i, name in enumerate(label_names)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}

        def format_ag_news(example):
            return {
                input_text_col: example['text'],
                original_label_col: label_names[example['label']]
            }
        processed_dataset = raw_dataset_dict.map(format_ag_news, remove_columns=['text', 'label'])

    elif dataset_name == 'aqua_rat':
        raw_dataset_dict = load_dataset("aqua_rat", "raw", cache_dir=data_root)
        label_names = ["A", "B", "C", "D", "E"]
        id_to_label_map = {i: name for i, name in enumerate(label_names)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}

        def format_aqua(sample):
            input_prompt = (
                f"Answer the question. Your final answer must be a single uppercase letter (A-E) formatted as: \n"
                "#### Final Answer: your answer.\n"
                "Non-compliant responses will be invalid.\n"
                f"Question: {sample['question']}\n"
                f"Options:\n{sample['options']}\n"
                f"Let's reason step by step."
            )
            return {
                input_text_col: input_prompt,
                original_label_col: sample['correct']
            }
        processed_dataset = raw_dataset_dict.map(format_aqua, remove_columns=raw_dataset_dict["train"].column_names)

    elif dataset_name == 'conll2003':
        try:
             raw_dataset_dict = load_dataset("./conll2003_dataprocess.py", name="conll2003", cache_dir=data_root)
        except FileNotFoundError:
             print("Error: conll2003_dataprocess.py script not found. Please place it in the current directory.")
             exit(1)
        label_list = raw_dataset_dict["train"].features["ner_tags"].feature.names
        print("Building label map for CoNLL-2003 (using frozenset of non-'O' tags)...")
        frozenset_to_id = {}
        current_id = 0
        unique_tag_sets = set()
        for example in tqdm(raw_dataset_dict['train'], desc="Finding unique tag sets"):
            tags = [label_list[tag_idx] for tag_idx in example['ner_tags']]
            non_o_tags = frozenset(tag for tag in tags if tag != 'O')
            if non_o_tags: unique_tag_sets.add(non_o_tags)
        only_o_tag_set = frozenset(['__ONLY_O__'])
        unique_tag_sets.add(only_o_tag_set)
        for tag_set in sorted(list(unique_tag_sets), key=lambda fs: str(fs)):
            if tag_set not in frozenset_to_id:
                frozenset_to_id[tag_set] = current_id
                current_id += 1
        id_to_label_map = {v: str(k) for k, v in frozenset_to_id.items()}
        # label_to_id_map is frozenset_to_id for this case for direct use in map

        def format_conll(example):
            input_text = " ".join(example['tokens'])
            tags = [label_list[tag_idx] for tag_idx in example['ner_tags']]
            non_o_tags = frozenset(tag for tag in tags if tag != 'O')
            label_key = only_o_tag_set if not non_o_tags else non_o_tags
            label_id = frozenset_to_id.get(label_key, -1)
            if label_id == -1: print(f"Warning: CoNLL Tag set {label_key} not found in map!")
            return {input_text_col: input_text, label_col: label_id}
        processed_dataset = raw_dataset_dict.map(format_conll, remove_columns=raw_dataset_dict["train"].column_names)
        processed_dataset = processed_dataset.map(
            lambda ex: {original_label_col: id_to_label_map.get(ex.get(label_col, -1), "Unseen Tag Set")}
        )

    elif dataset_name == 'piqa':
        raw_dataset_dict = load_dataset("piqa", cache_dir=data_root)
        id_to_label_map = {0: "A", 1: "B"}
        label_to_id_map = {"A": 0, "B": 1}
        def format_piqa(sample):
            content_hash = hashlib.sha256(f"{sample['goal']}{sample['sol1']}{sample['sol2']}".encode()).hexdigest()
            hash_int = int(content_hash, 16) % (2**32)
            deterministic_rng = random.Random(seed + hash_int) # Use passed seed
            swap = deterministic_rng.random() < 0.5
            options = [sample["sol2"], sample["sol1"]] if swap else [sample["sol1"], sample["sol2"]]
            correct_label_name = ["A", "B"][(sample["label"] + 1) % 2] if swap else ["A", "B"][sample["label"]]
            input_prompt = (
                 "Choose the correct physical interaction. Answer must be 'A' or 'B'.\n"
                 f"Question: {sample['goal']}\nOptions:\nA. {options[0]}\nB. {options[1]}\nAnswer:"
             )
            return {input_text_col: input_prompt, original_label_col: correct_label_name}
        processed_dataset = raw_dataset_dict.map(format_piqa, remove_columns=raw_dataset_dict["train"].column_names)

    elif dataset_name == 'sciq':
        raw_dataset_dict = load_dataset("allenai/sciq", cache_dir=data_root)
        label_names = ["A", "B", "C", "D"]
        id_to_label_map = {i: name for i, name in enumerate(label_names)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}
        def format_sciq(sample):
            question = sample["question"]
            options = [sample["correct_answer"], sample["distractor1"], sample["distractor2"], sample["distractor3"]]
            content_hash = hashlib.sha256(question.encode()).hexdigest()
            hash_int = int(content_hash, 16) % (2**32)
            deterministic_rng = random.Random(seed + hash_int) # Use passed seed
            deterministic_rng.shuffle(options)
            correct_idx = options.index(sample["correct_answer"])
            correct_label_name = label_names[correct_idx]
            formatted_options = "\n".join([f"{label_names[i]}. {opt}" for i, opt in enumerate(options)])
            input_prompt = (
                "Answer this science question. The answer must be a single uppercase letter (A-D).\n"
                f"Question: {question}\nOptions:\n{formatted_options}\nAnswer:"
            )
            return {input_text_col: input_prompt, original_label_col: correct_label_name}
        processed_dataset = raw_dataset_dict.map(format_sciq, remove_columns=raw_dataset_dict["train"].column_names)

    elif dataset_name == 'sem_eval_2010_task_8':
        raw_dataset_dict = load_dataset("sem_eval_2010_task_8", cache_dir=data_root)
        relation_labels = ["Cause-Effect(e1,e2)", "Cause-Effect(e2,e1)", "Component-Whole(e1,e2)",
                           "Component-Whole(e2,e1)", "Content-Container(e1,e2)", "Content-Container(e2,e1)",
                           "Entity-Destination(e1,e2)", "Entity-Destination(e2,e1)", "Entity-Origin(e1,e2)",
                           "Entity-Origin(e2,e1)", "Instrument-Agency(e1,e2)", "Instrument-Agency(e2,e1)",
                           "Member-Collection(e1,e2)", "Member-Collection(e2,e1)", "Message-Topic(e1,e2)",
                           "Message-Topic(e2,e1)", "Product-Producer(e1,e2)", "Product-Producer(e2,e1)", "Other"]
        id_to_label_map = {i: name for i, name in enumerate(relation_labels)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}
        def format_semeval(sample):
            raw_sentence = sample["sentence"]
            relation_idx = sample["relation"]
            label_name = relation_labels[relation_idx] if relation_idx < len(relation_labels) else "Other"
            clean_sentence = raw_sentence.replace("<e1>", "").replace("</e1>", "").replace("<e2>", "").replace("</e2>", "").strip()
            return {input_text_col: clean_sentence, original_label_col: label_name}
        processed_dataset = raw_dataset_dict.map(format_semeval, remove_columns=["sentence", "relation"])

    elif dataset_name == 'clutrr':
        if not os.path.exists(CLUTRR_LOADER_SCRIPT_PATH):
            print(f"Error: CLUTRR loading script not found at: {CLUTRR_LOADER_SCRIPT_PATH}")
            exit(1)
        try:
            # Load the general CLUTRR config
            raw_clutrr_dict = load_dataset(CLUTRR_LOADER_SCRIPT_PATH, name=CLUTRR_GENERAL_CONFIG_NAME, trust_remote_code=True, cache_dir=data_root)
            if 'train' not in raw_clutrr_dict or len(raw_clutrr_dict['train']) == 0:
                print(f"Error: 'train' split not found or empty in CLUTRR config '{CLUTRR_GENERAL_CONFIG_NAME}'. Cannot perform K-filtering.")
                exit(1)
            current_split_data = raw_clutrr_dict['train'] # Work on the 'train' split
        except Exception as e:
            print(f"Error loading CLUTRR dataset using script '{CLUTRR_LOADER_SCRIPT_PATH}' and config '{CLUTRR_GENERAL_CONFIG_NAME}'.")
            raise e

        # 1. Add 'k_value' to each example
        def _clutrr_add_k_value(example: Dict[str, Any]) -> Dict[str, Any]:
            edge_types_str = example.get('edge_types')
            k = -1
            if isinstance(edge_types_str, str) and edge_types_str.strip():
                try:
                    edge_list = ast.literal_eval(edge_types_str)
                    k = len(edge_list) if isinstance(edge_list, list) else -1
                except (ValueError, SyntaxError, TypeError): k = -1
            example['k_value'] = k
            return example
        
        print(f"Calculating K values for CLUTRR '{CLUTRR_GENERAL_CONFIG_NAME}' train split...")
        dataset_with_k = current_split_data.map(_clutrr_add_k_value, num_proc=min(4, os.cpu_count() or 1))

        # 2. Filter by K if k_filter_value is provided
        dataset_to_process = dataset_with_k
        if k_filter_value is not None:
            print(f"Filtering CLUTRR train split for K = {k_filter_value}...")
            original_count = len(dataset_with_k)
            dataset_filtered_by_k = dataset_with_k.filter(
                lambda example: example['k_value'] == k_filter_value,
                num_proc=min(4, os.cpu_count() or 1)
            )
            print(f"  Filtered from {original_count} to {len(dataset_filtered_by_k)} examples for K={k_filter_value}.")
            if len(dataset_filtered_by_k) == 0:
                print(f"FATAL: No examples found for K={k_filter_value} in CLUTRR config '{CLUTRR_GENERAL_CONFIG_NAME}' train split. Exiting.")
                exit(1)
            dataset_to_process = dataset_filtered_by_k
        else:
            print("No K-filter applied for CLUTRR. Using all valid K examples from train split (K != -1).")
            dataset_to_process = dataset_with_k.filter(
                lambda ex: ex['k_value'] != -1, 
                num_proc=min(4, os.cpu_count() or 1)
            )
            if len(dataset_to_process) == 0:
                print(f"FATAL: No valid K examples (K != -1) found in CLUTRR train split. Exiting.")
                exit(1)
        
        print(f"--- K Value Distribution for CLUTRR data being processed (Target K: {k_filter_value if k_filter_value is not None else 'All Valid'}) ---")
        if 'k_value' in dataset_to_process.column_names and len(dataset_to_process) > 0:
            k_counts = Counter(dataset_to_process['k_value'])
            for k_val, count in sorted(k_counts.items()): print(f"  K = {k_val}: {count} samples")
        else: print("  Could not calculate K value distribution.")
        print("-" * 30)

        # 3. Build label map using 'target_text' from the (filtered) data
        print("Building label map for CLUTRR (using target_text) on (filtered) data...")
        _target_text_to_id_clutrr = {} # Use local var to avoid conflict with outer scope
        current_id = 0
        unique_targets = set(dataset_to_process['target_text'])
        for target in sorted(list(unique_targets)):
            if target not in _target_text_to_id_clutrr:
                _target_text_to_id_clutrr[target] = current_id
                current_id += 1
        
        id_to_label_map = {v: k for k, v in _target_text_to_id_clutrr.items()}
        # label_to_id_map captured for use in format_clutrr_for_embedding
        captured_label_to_id_map_clutrr = _target_text_to_id_clutrr 
        print(f"Built map with {len(id_to_label_map)} unique target relations for current CLUTRR data.")

        # 4. Format for embedding input and labels
        def format_clutrr_for_embedding(example):
            input_prompt = f"Context: {example['story']}\nQuestion: {example['query']}\nAnswer:"
            label_name = example['target_text']
            label_id = captured_label_to_id_map_clutrr.get(label_name, -1)
            if label_id == -1: print(f"Warning: CLUTRR target '{label_name}' not found in map!")
            return {input_text_col: input_prompt, label_col: label_id, original_label_col: label_name}

        final_processed_split = dataset_to_process.map(
            format_clutrr_for_embedding,
            remove_columns=dataset_to_process.column_names, # Remove all original columns
            num_proc=min(4, os.cpu_count() or 1)
        )
        # This special handling for CLUTRR prepares `final_processed_split` and `id_to_label_map`
        # The generic processing at the end needs to be aware of this.
        processed_train_dataset = final_processed_split
        # `processed_dataset` (DatasetDict) will not be used for CLUTRR from here.
        # The common label mapping step at the end is skipped because `label_col` is already present.

    else: # For datasets other than CLUTRR
        # `processed_dataset` is a DatasetDict here
        pass


    # --- Final Common Processing Steps (for non-CLUTRR, or if CLUTRR needs it) ---
    if dataset_name != 'clutrr': # CLUTRR handled its label mapping internally
        if 'train' not in processed_dataset:
            raise KeyError(f"FATAL: 'train' split missing for {dataset_name} before final processing.")
        
        # Apply label mapping if not done (e.g. for AGNews, PIQA etc.)
        # CoNLL and CLUTRR already created 'label_col'.
        if label_col not in processed_dataset['train'].column_names:
            if not label_to_id_map: # Ensure label_to_id_map was populated
                 raise RuntimeError(f"Label map (label_to_id_map) not created for dataset {dataset_name}")
            print(f"Applying primary label mapping for {dataset_name}...")
            # This map adds 'label_col' and keeps 'original_label_col' and 'input_text_col'
            def apply_label_map_generic(example):
                return {label_col: label_to_id_map.get(example[original_label_col], -1)}

            processed_dataset = processed_dataset.map(
                apply_label_map_generic,
                #batched=True # Consider if helpful
            )
        processed_train_dataset = processed_dataset['train']


    # Ensure the processed_train_dataset is set and has the required columns
    if processed_train_dataset is None:
        raise ValueError(f"processed_train_dataset was not set for {dataset_name}")

    # Final check for required columns in the processed_train_dataset
    required_cols = [input_text_col, label_col, original_label_col]
    if not all(col in processed_train_dataset.column_names for col in required_cols):
        missing_cols = [col for col in required_cols if col not in processed_train_dataset.column_names]
        raise ValueError(
            f"Dataset {dataset_name} final processing failed. Missing columns: {missing_cols}. "
            f"Found: {processed_train_dataset.column_names}"
        )
    
    # Check for -1 labels (mapping errors)
    if any(ex[label_col] == -1 for ex in processed_train_dataset):
            error_samples = sum(1 for ex in processed_train_dataset if ex[label_col] == -1)
            print(f"Warning: {error_samples}/{len(processed_train_dataset)} examples in {dataset_name} have label -1 (mapping error or original).")

    return processed_train_dataset, id_to_label_map


# === Embedding Generation === ( 그대로 )
# Global cache for model and tokenizer
loaded_model = None
loaded_tokenizer = None

def get_llama_model_and_tokenizer(model_name, device_param): # Renamed device to device_param
    global loaded_model, loaded_tokenizer
    if loaded_model is None or loaded_tokenizer is None:
        print(f"Loading Tokenizer: {model_name}")
        loaded_tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side='left')
        if loaded_tokenizer.pad_token is None:
            loaded_tokenizer.pad_token = loaded_tokenizer.eos_token
            print("Set pad_token to eos_token")

        print(f"Loading Model: {model_name} (fp16, device_map='auto')")
        loaded_model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,
            device_map="auto",
            low_cpu_mem_usage=True,
            trust_remote_code=True
        )
        print("Model loaded successfully onto devices.")
        loaded_model.eval()
    return loaded_model, loaded_tokenizer

def get_nlp_embeddings(model, tokenizer, texts, device_param, batch_size, max_length): # Renamed device
    all_embeddings = []
    model.eval()
    print(f"Generating embeddings for {len(texts)} texts (batch size: {batch_size}, max_length: {max_length})...")
    for i in tqdm(range(0, len(texts), batch_size), desc="Embedding Batches"):
        batch_texts = texts[i : i + batch_size]
        if not batch_texts: continue
        inputs = tokenizer(batch_texts, return_tensors='pt', padding='max_length',
                           truncation=True, max_length=max_length, add_special_tokens=True)
        model_device = next(model.parameters()).device
        inputs = {k: v.to(model_device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
            last_hidden_state = outputs.hidden_states[-1]
        attention_mask = inputs['attention_mask']
        mask_expanded = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
        sum_hidden_state = torch.sum(last_hidden_state * mask_expanded, dim=1)
        seq_lengths = torch.sum(mask_expanded, dim=1)
        seq_lengths = torch.clamp(seq_lengths, min=1e-9)
        pooled_embeddings = sum_hidden_state / seq_lengths
        all_embeddings.append(pooled_embeddings.cpu().numpy())
        del inputs, outputs, last_hidden_state, mask_expanded, sum_hidden_state, seq_lengths, pooled_embeddings
        if device_param.type == 'cuda': torch.cuda.empty_cache() # Use device_param
    if not all_embeddings: return np.array([])
    return np.concatenate(all_embeddings, axis=0)


# === Complexity Metrics Calculation === ( 그대로 )
def calculate_metrics(X_embed, Y_labels, pca_threshold, k_neighbors, silhouette_sample_size):
    print("\nCalculating complexity metrics...")
    results = {}
    n_samples, n_features = X_embed.shape[0], X_embed.shape[1]
    if n_samples == 0 or n_features == 0: return None
    if len(X_embed) != len(Y_labels): return None

    unique_labels, counts = np.unique(Y_labels, return_counts=True)
    results['num_classes'] = len(unique_labels)
    print(f"  num_classes: {results['num_classes']}")
    if results['num_classes'] < 2: print("Warning: Only 1 class. Some metrics might not be meaningful.")
    
    results['label_entropy'] = entropy(counts, base=2) if len(counts) > 0 else 0.0
    print(f"  label_entropy: {results['label_entropy']:.4f}")

    print("Calculating effective_dim...")
    try:
        scaler = StandardScaler(); X_scaled = scaler.fit_transform(X_embed.astype(np.float32))
        pca_n_components = min(n_samples, X_scaled.shape[1])
        if pca_n_components < 2: results['effective_dim'] = None
        else:
            pca = PCA(n_components=pca_n_components); pca.fit(X_scaled)
            cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
            eff_dim_indices = np.where(cumulative_variance >= pca_threshold)[0]
            results['effective_dim'] = int(eff_dim_indices[0] + 1) if len(eff_dim_indices) > 0 else pca.n_components_
        print(f"  effective_dim (at {pca_threshold*100}% variance): {results.get('effective_dim', 'N/A')}")
        del X_scaled; gc.collect()
    except Exception as e: print(f"  Error calculating effective_dim: {e}"); results['effective_dim'] = None

    print("Calculating intra_class_var...")
    try:
        avg_intra_distances = []
        if results['num_classes'] < 1: results['intra_class_var'] = None
        else:
            for label in unique_labels:
                class_embeddings = X_embed[Y_labels == label]
                if len(class_embeddings) > 1:
                    centroid = np.mean(class_embeddings.astype(np.float64), axis=0)
                    distances = [euclidean(emb.astype(np.float64), centroid) for emb in class_embeddings]
                    avg_intra_distances.append(np.mean(distances))
                elif len(class_embeddings) == 1: avg_intra_distances.append(0.0)
            results['intra_class_var'] = np.mean(avg_intra_distances) if avg_intra_distances else None
        print(f"  intra_class_var: {results.get('intra_class_var', 'N/A'):.4f}")
    except Exception as e: print(f"  Error calculating intra_class_var: {e}"); results['intra_class_var'] = None

    print(f"Calculating local_consistency (k={k_neighbors})...")
    try:
        actual_k = min(k_neighbors, n_samples - 1)
        if actual_k < 1: results['local_consistency'] = None
        else:
            nn = NearestNeighbors(n_neighbors=actual_k + 1, metric='euclidean', n_jobs=-1); nn.fit(X_embed.astype(np.float32))
            indices = nn.kneighbors(X_embed.astype(np.float32), return_distance=False)[:, 1:]
            consistent_neighbor_ratios = [np.mean(Y_labels[indices[i]] == Y_labels[i]) for i in range(n_samples)]
            results['local_consistency'] = np.mean(consistent_neighbor_ratios)
        print(f"  local_consistency: {results.get('local_consistency', 'N/A'):.4f}")
    except Exception as e: print(f"  Error calculating local_consistency: {e}"); results['local_consistency'] = None

    print("Calculating separability_score (Silhouette Score)...")
    if results['num_classes'] < 2 or n_samples < results['num_classes'] * 2:
        results['separability_score'] = None
        print(f"  Skipping separability_score (classes: {results['num_classes']}, samples: {n_samples}).")
    else:
        X_work, Y_work = X_embed, Y_labels
        if n_samples > silhouette_sample_size:
            print(f"  Subsampling to {silhouette_sample_size} for silhouette.")
            try:
                indices_subset, _ = sklearn_train_test_split(np.arange(n_samples), train_size=silhouette_sample_size/n_samples, stratify=Y_labels, random_state=42)
                X_work, Y_work = X_embed[indices_subset], Y_labels[indices_subset]
                if len(np.unique(Y_work)) < 2: X_work = None; print("  Subsample has < 2 classes. Skipping.")
            except: # Fallback for stratification issues
                indices_subset = np.random.choice(n_samples, silhouette_sample_size, replace=False)
                X_work, Y_work = X_embed[indices_subset], Y_labels[indices_subset]
                if len(np.unique(Y_work)) < 2: X_work = None; print("  Random subsample has < 2 classes. Skipping.")
        if X_work is not None:
            try:
                results['separability_score'] = silhouette_score(X_work.astype(np.float32), Y_work, metric='euclidean')
                print(f"  separability_score: {results['separability_score']:.4f}")
            except Exception as e: print(f"  Error calculating silhouette: {e}"); results['separability_score'] = None
        else: results['separability_score'] = None
    return results


# === Main Execution Logic ===
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculate complexity metrics for NLP datasets using LLM embeddings.")
    parser.add_argument('-dataset', type=str, required=True,
                        choices=['ag_news', 'aqua_rat', 'conll2003', 'piqa',
                                 'sciq', 'sem_eval_2010_task_8', 'clutrr'],
                        help='Name of the NLP dataset to process.')
    parser.add_argument('-k', '--k_filter_clutrr', type=int, default=None,
                        help='(For CLUTRR only) Specific K value to filter the dataset (e.g., 2, 3, 4).')
    parser.add_argument('--seed', type=int, default=42, help='Random seed for operations like shuffling.')

    args = parser.parse_args()
    dataset_name = args.dataset
    k_filter_for_clutrr = args.k_filter_clutrr if dataset_name == 'clutrr' else None
    
    # Set seed for reproducibility (affects PIQA/SciQ shuffling, and any other random ops)
    random.seed(args.seed)
    np.random.seed(args.seed)
    # Torch seed is not strictly needed here as this script doesn't train a new model from scratch
    # but set it for completeness if any torch ops involve randomness.
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    print(f"--- Starting Complexity Analysis for: {dataset_name} ---")
    if dataset_name == 'clutrr' and k_filter_for_clutrr is not None:
        print(f"--- CLUTRR K-filter active: K = {k_filter_for_clutrr} ---")
    print(f"Using Embedding Model: {EMBEDDING_MODEL_NAME}")
    print(f"Global seed: {args.seed}")


    output_filename_base = dataset_name
    if dataset_name == 'clutrr' and k_filter_for_clutrr is not None:
        output_filename_base += f"_k{k_filter_for_clutrr}"
    output_filename = f"{output_filename_base}_complexity_metrics.json"
    output_path = os.path.join(OUTPUT_DIR, output_filename)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    if os.path.exists(output_path):
        print(f"Results file already exists at {output_path}. Skipping calculation.")
        try:
            with open(output_path, 'r') as f: print("\n--- Existing Results ---\n", json.dumps(json.load(f), indent=4))
        except: print("Could not load existing results.")
        exit()

    # --- Step 1: Load and Preprocess Data ---
    train_dataset, id_to_label_map = load_and_preprocess_nlp_dataset(
        dataset_name,
        DATA_ROOT,
        seed=args.seed, # Pass the seed for deterministic dataset operations
        k_filter_value=k_filter_for_clutrr
    )
    print(f"Initial samples loaded (after dataset-specific processing/filtering): {len(train_dataset)}")
    num_samples_after_load = len(train_dataset) # Capture count after K-filtering (if any)

    # --- Step 2: Subsampling (if needed, based on MAX_SAMPLES_FOR_EMBEDDING) ---
    if len(train_dataset) > MAX_SAMPLES_FOR_EMBEDDING:
        print(f"Dataset size ({len(train_dataset)}) exceeds limit ({MAX_SAMPLES_FOR_EMBEDDING}). Stratified subsampling...")
        try:
            train_dataset_split = train_dataset.train_test_split(
                train_size=MAX_SAMPLES_FOR_EMBEDDING / len(train_dataset),
                stratify_by_column="label", seed=args.seed
            )
            train_dataset = train_dataset_split['train']
        except ValueError as ve: # Fallback for stratification issues (e.g. too few samples in some classes)
            print(f"Warning: Stratified subsampling failed ({ve}). Trying random subsampling.")
            train_dataset = train_dataset.shuffle(seed=args.seed).select(range(MAX_SAMPLES_FOR_EMBEDDING))
        print(f"Subsampled to {len(train_dataset)} training samples.")
    
    num_samples_for_embedding = len(train_dataset)

    if num_samples_for_embedding == 0:
        print("FATAL: No samples remaining after loading and subsampling. Exiting.")
        exit(1)

    # --- Step 3: Prepare Data for Embedding ---
    texts_to_embed = train_dataset['input_text_for_embedding']
    Y_labels = np.array(train_dataset['label'])
    print(f"Prepared {len(texts_to_embed)} texts and {len(Y_labels)} labels for embedding.")

    # --- Step 4: Load Model and Tokenizer ---
    model, tokenizer = None, None # Define for finally clause
    try:
        model, tokenizer = get_llama_model_and_tokenizer(EMBEDDING_MODEL_NAME, device)
    except Exception as e:
        print(f"FATAL: Failed to load model or tokenizer. Error: {e}")
        if model is not None: del model
        if tokenizer is not None: del tokenizer
        gc.collect(); torch.cuda.empty_cache()
        exit(1)

    # --- Step 5: Generate Embeddings ---
    X_embed = None
    try:
        X_embed = get_nlp_embeddings(model, tokenizer, texts_to_embed, device, EMBEDDING_BATCH_SIZE, MAX_TOKEN_LENGTH)
        print(f"Generated embeddings shape: {X_embed.shape if X_embed is not None and X_embed.size > 0 else 'None or Empty'}")
    except Exception as e:
        print(f"FATAL: Failed during embedding generation. Error: {e}")
        if X_embed is not None: del X_embed
        # Model and tokenizer will be cleaned up in finally
        exit(1) # exit() doesn't trigger finally if not in try..finally block. Ensure cleanup.
    finally: # Ensure model/tokenizer are cleaned up even on embedding error
        if model is not None: del model; model = None
        if tokenizer is not None: del tokenizer; tokenizer = None
        gc.collect()
        if device.type == 'cuda': torch.cuda.empty_cache()


    # --- Step 6: Calculate Metrics ---
    final_results = {}
    if X_embed is not None and Y_labels is not None and X_embed.shape[0] == len(Y_labels) and X_embed.size > 0:
        metrics = calculate_metrics(X_embed, Y_labels, PCA_VARIANCE_THRESHOLD, K_NEIGHBORS, SILHOUETTE_SAMPLE_SIZE)
        if metrics:
            dataset_info_dict = {
                'name': dataset_name,
                'embedding_model': EMBEDDING_MODEL_NAME,
                'embedding_dimension': X_embed.shape[1],
                'samples_after_load_and_filtering': num_samples_after_load,
                'samples_used_for_embedding_and_metrics': num_samples_for_embedding,
                'max_samples_for_embedding_limit': MAX_SAMPLES_FOR_EMBEDDING,
                'id_to_label_map': {str(k): v for k,v in id_to_label_map.items()} # Ensure keys are str for JSON
            }
            if dataset_name == 'clutrr' and k_filter_for_clutrr is not None:
                dataset_info_dict['clutrr_k_filter_applied'] = k_filter_for_clutrr
            
            final_results['dataset_info'] = dataset_info_dict
            final_results['metrics'] = {
                k: (v.item() if isinstance(v, np.generic) else (v.tolist() if isinstance(v, np.ndarray) else v))
                for k, v in metrics.items() if v is not None # Store only non-None metrics
            }
        else: print("Metrics calculation failed or returned no results.")
    else: print("Embeddings or labels are invalid. Cannot calculate metrics.")

    # --- Step 7: Save Results ---
    if final_results:
        print("\nSaving final results...")
        try:
            with open(output_path, 'w') as f: json.dump(final_results, f, indent=4)
            print(f"Results successfully saved to {output_path}")
            print("\n--- Final Results ---\n", json.dumps(final_results, indent=4))
        except Exception as e: print(f"Error saving results: {e}\nProblematic data: {final_results}")
    else: print("No results generated to save.")

    # --- Step 8: Cleanup (already partially done in finally block for model/tokenizer) ---
    print("Cleaning up remaining resources...")
    if X_embed is not None: del X_embed
    if Y_labels is not None: del Y_labels
    if 'train_dataset' in locals() and train_dataset is not None: del train_dataset
    gc.collect()
    if device.type == 'cuda': torch.cuda.empty_cache(); print("CUDA cache cleared.")
    print(f"\n--- Finished processing {dataset_name} ---")