# ner_llama_conll2003.py
from conll2003_dataprocess import Conll2003
import datasets
from transformers import (
    AutoTokenizer,
    AutoModelForTokenClassification,
    TrainingArguments,
    Trainer,
    DataCollatorForTokenClassification,
)
from peft import get_peft_model, LoraConfig, TaskType
import numpy as np
from seqeval.metrics import classification_report
import argparse
import os
import json
from transformers import TrainerCallback
import torch
from torch.distributed import all_reduce, ReduceOp


def set_all_seeds(seed=42):
    """固定所有随机种子保证可复现性（兼容旧版 datasets 库）"""
    import random
    import numpy as np
    import torch
    import os
    
    # 设置Python随机种子
    random.seed(seed)
    
    # 设置Numpy随机种子
    np.random.seed(seed)
    
    # 设置PyTorch随机种子
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    
    # 设置cuDNN确定性模式
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    # 设置环境变量
    os.environ["PYTHONHASHSEED"] = str(seed)
    
    # 设置HuggingFace Transformers的随机种子
    from transformers import set_seed as hf_set_seed
    hf_set_seed(seed)
    
    # 设置datasets库缓存（兼容不同版本）
    try:
        from datasets import set_caching_enabled  # 新版库 (>1.14.0)
        set_caching_enabled(True)
    except ImportError:
        os.environ["DISABLE_DATASETS_CACHING"] = "0"  # 旧版库设置环境变量
    
# 使用示例
set_all_seeds(42)



# 1. 数据集加载和预处理（保持原有逻辑）
dataset = datasets.load_dataset("conll2003_dataprocess.py", name="conll2003")
label_list = dataset["train"].features["ner_tags"].feature.names
label2id = {l:i for i,l in enumerate(label_list)}
id2label = {i:l for i,l in enumerate(label_list)}
print(dataset)

# 2. 命令行参数解析
parser = argparse.ArgumentParser(description="Fine-tune Llama-3 for NER")
parser.add_argument("--num_train_samples", type=float, default=-1, help="训练样本数量 (-1表示全部)")
parser.add_argument("--dataset_name", type=str, default="conll2003", help="数据集名称")
args = parser.parse_args()
num_train_samples_full = len(dataset["train"])
num_train_samples = args.num_train_samples
if  num_train_samples > 0 and num_train_samples <= 1:
    num_train_samples = int(num_train_samples_full * num_train_samples)
else:
    num_train_samples = int(num_train_samples)

# 3. 路径配置
base_dir = f"./results/{args.dataset_name}/result_{num_train_samples}"
os.makedirs(f"{base_dir}/best_model", exist_ok=True)
os.makedirs(f"{base_dir}/ckp", exist_ok=True)
os.makedirs(f"{base_dir}/result", exist_ok=True)

# 4. 状态保存文件
state_file = f"{base_dir}/result/training_state.json"

# 5. 自定义回调（添加状态保存）
class NerCallback(TrainerCallback):
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        self.best_f1 = 0.0
        self.best_epoch = 0
        self.epoch_f1 = {}
        
        # 加载之前的状态
        if os.path.exists(state_file):
            with open(state_file, 'r') as f:
                state = json.load(f)
                self.best_f1 = state.get("best_f1", 0.0)
                self.best_epoch = state.get("best_epoch", 0)
                self.epoch_f1 = {int(k):v for k,v in state.get("epoch_f1", {}).items()}

    def on_evaluate(self, args, state, control, **kwargs):
        # 跨进程聚合指标
        metrics = kwargs.get("metrics", {})
        if "eval_f1" in metrics:
            current_f1 = metrics["eval_f1"]
            current_epoch = int(state.epoch)
            
            # 更新最佳模型
            if current_f1 > self.best_f1 and state.is_local_process_zero:
                self.best_f1 = current_f1
                self.best_epoch = current_epoch
                # kwargs['model'].save_pretrained(f"{base_dir}/best_model")
                # self.tokenizer.save_pretrained(f"{base_dir}/best_model")
                # print(f"\nNew best model saved (F1: {self.best_f1:.4f})")
            
            # 记录当前epoch分数
            self.epoch_f1[current_epoch] = current_f1
            
            # 保存状态
            if state.is_local_process_zero:
                with open(state_file, 'w') as f:
                    json.dump({
                        "best_f1": self.best_f1,
                        "best_epoch": self.best_epoch,
                        "epoch_f1": self.epoch_f1
                    }, f, indent=2)

# 处理训练样本数量
dataset["train"] = dataset["train"].select(range(num_train_samples))

dataset["test"] = dataset["test"]
dataset["validation"] = dataset["test"]
print('train: ',len(dataset["train"]))
print('test: ',len(dataset["test"]))

# 6. 模型和分词器初始化
model_name = "meta-llama/Llama-3.1-8B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name, add_prefix_space=True)
tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForTokenClassification.from_pretrained(
    model_name,
    num_labels=len(label_list),
    id2label=id2label,
    label2id=label2id,
    # device_map="auto",
    torch_dtype=torch.float16
)

# 7. LoRA配置
model = get_peft_model(model, LoraConfig(
    task_type=TaskType.TOKEN_CLS,
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="lora_only"
))

for param in model.parameters():
    if param.requires_grad:
        param.data = param.data.float()

# 8. 检查点恢复逻辑
last_checkpoint = None
if os.path.exists(f"{base_dir}/ckp"):
    checkpoints = [d for d in os.listdir(f"{base_dir}/ckp") if d.startswith("checkpoint")]
    if checkpoints:
        last_checkpoint = sorted(checkpoints, key=lambda x: int(x.split("-")[1]))[-1]
        last_checkpoint = os.path.join(f"{base_dir}/ckp", last_checkpoint)
        print(f"恢复检查点: {last_checkpoint}")

# 9. 训练参数配置
training_args = TrainingArguments(
    output_dir=f"{base_dir}/ckp",
    evaluation_strategy="epoch",
    save_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=2,
    per_device_eval_batch_size=2,
    gradient_accumulation_steps=4,
    num_train_epochs=30,
    metric_for_best_model="f1",
    greater_is_better=True,
    load_best_model_at_end=True,
    fp16=True,
    logging_steps=10,
    save_total_limit=1,  # 改为保留1个检查点
    report_to="none",
    optim="adamw_torch",
    ddp_find_unused_parameters=False,
    dataloader_num_workers=8,
    resume_from_checkpoint=last_checkpoint,  # 自动恢复
    remove_unused_columns=False,
)

# 10. 数据预处理（保持原有逻辑）
def tokenize_and_align_labels(examples):
    tokenized_inputs = tokenizer(
        examples["tokens"],
        truncation=True,
        is_split_into_words=True,
        max_length=512,
    )
    labels = []
    for i, (ner_tags, tokens) in enumerate(zip(examples["ner_tags"], examples["tokens"])):
        word_ids = tokenized_inputs.word_ids(batch_index=i)
        previous_word_idx = None
        label_ids = []
        valid_word_indices = [wid for wid in word_ids if wid is not None]
        max_word_idx = max(valid_word_indices) if valid_word_indices else -1
        truncated_tags = ner_tags[:max_word_idx + 1] if max_word_idx != -1 else []
        
        for word_idx in word_ids:
            if word_idx is None:
                label_ids.append(-100)
            else:
                if word_idx >= len(truncated_tags):
                    label_ids.append(-100)
                else:
                    label_ids.append(truncated_tags[word_idx] if word_idx != previous_word_idx else -100)
                previous_word_idx = word_idx
        labels.append(label_ids)
    
    tokenized_inputs["labels"] = labels
    return tokenized_inputs

tokenized_dataset = dataset.map(
    tokenize_and_align_labels,
    batched=True,
    remove_columns=dataset["train"].column_names,
)

# 11. 评估指标计算
def compute_metrics(p):
    predictions, labels = p
    predictions = np.argmax(predictions, axis=2)

    true_preds = [
        [id2label[p] for (p, l) in zip(pred, label) if l != -100]
        for pred, label in zip(predictions, labels)
    ]
    true_labels = [
        [id2label[l] for (p, l) in zip(pred, label) if l != -100]
        for pred, label in zip(predictions, labels)
    ]

    report = classification_report(true_labels, true_preds, output_dict=True)
    return {
        "f1": report["micro avg"]["f1-score"],
        "precision": report["micro avg"]["precision"],
        "recall": report["micro avg"]["recall"]
    }

# 12. 创建训练器
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset["train"],
    eval_dataset=tokenized_dataset["validation"],
    data_collator=DataCollatorForTokenClassification(tokenizer=tokenizer),
    compute_metrics=compute_metrics,
    callbacks=[NerCallback(tokenizer)]
)

# 13. 训练执行
print("开始训练...")
train_result = trainer.train(resume_from_checkpoint=last_checkpoint)

# 14. 最终结果保存
# 查找NerCallback实例
ner_callback = None
for callback in trainer.callback_handler.callbacks:
    if isinstance(callback, NerCallback):
        ner_callback = callback
        break

if ner_callback is None:
    raise ValueError("NerCallback instance not found in callbacks")

final_metrics = {
    "best_f1": ner_callback.best_f1,
    "best_epoch": ner_callback.best_epoch,
    "epoch_f1": ner_callback.epoch_f1
}

with open(f"{base_dir}/result/result.json", "w") as f:
    json.dump(final_metrics, f, indent=2)

print(f"\n训练完成！最佳模型保存在: {base_dir}/best_model")
print(f"最佳F1分数: {final_metrics['best_f1']:.4f} (Epoch {final_metrics['best_epoch']})")