import torch
import os  # 新增导入
import json  # 导入 json 库
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    trainer_utils  # 新增导入
)

from peft import LoraConfig, get_peft_model
from transformers import TrainerCallback
from typing import Dict, List, Union
import argparse  # 导入 argparse
from torch.distributed import all_reduce, ReduceOp  # 新增导入


def set_all_seeds(seed=42):
    """固定所有随机种子保证可复现性（兼容旧版 datasets 库）"""
    import random
    import numpy as np
    import torch
    import os
    
    # 设置Python随机种子
    random.seed(seed)
    
    # 设置Numpy随机种子
    np.random.seed(seed)
    
    # 设置PyTorch随机种子
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    
    # 设置cuDNN确定性模式
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    # 设置环境变量
    os.environ["PYTHONHASHSEED"] = str(seed)
    
    # 设置HuggingFace Transformers的随机种子
    from transformers import set_seed as hf_set_seed
    hf_set_seed(seed)
    
    # 设置datasets库缓存（兼容不同版本）
    try:
        from datasets import set_caching_enabled  # 新版库 (>1.14.0)
        set_caching_enabled(True)
    except ImportError:
        os.environ["DISABLE_DATASETS_CACHING"] = "0"  # 旧版库设置环境变量
    
# 使用示例
set_all_seeds(42)


# 自定义数据整理器
class CustomDataCollator(DataCollatorForLanguageModeling):
    def __call__(self, features: List[Dict[str, Union[List[int], str]]]) -> Dict[str, torch.Tensor]:
        input_texts = [feature.pop("input_text") for feature in features]
        output_texts = [feature.pop("output_text") for feature in features]

        batch = super().__call__(features)

        batch["input_text"] = input_texts
        batch["output_text"] = output_texts
        return batch

# 1. 数据准备（添加数据切片）
label_names = ["World", "Sports", "Business", "Sci/Tech"]
dataset = load_dataset("ag_news")

def format_instruction(sample):
    return {
        "input": f"Classify: {sample['text']}\nOptions: {', '.join(label_names)}\nAnswer:",
        "output": label_names[sample["label"]]
    }

formatted_dataset = dataset.map(format_instruction, remove_columns=["text", "label"])

dataset_name = "ag_news"
num_train_samples_full = len(formatted_dataset["train"])
print(f"完整训练样本数量: {num_train_samples_full}")

# 添加命令行参数解析
parser = argparse.ArgumentParser(description="Fine-tune Llama-3 model for text classification.")
parser.add_argument(
    "--num_train_samples",
    type=float,
    default=-1,  # 默认值 -1 表示使用全部训练集
    help="Number of training samples to use (default: -1, use all)",
)
args = parser.parse_args()

num_train_samples = args.num_train_samples
if  num_train_samples > 0 and num_train_samples <= 1:
    num_train_samples = int(num_train_samples_full * num_train_samples)
else:
    num_train_samples = int(num_train_samples)
formatted_dataset['train'] = formatted_dataset['train'].select(range(num_train_samples))
formatted_dataset["test"] = formatted_dataset["test"] # 确保测试集没有被切片
print(f"实际训练样本数量: {len(formatted_dataset['train'])}")
print(f"实际测试样本数量: {len(formatted_dataset['test'])}")
# print(formatted_dataset)

# 2. 模型加载
model_name = "meta-llama/Llama-3.1-8B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    padding_side='left'
)
tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    # device_map="auto"
)

# 3. LoRA配置
peft_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, peft_config)

# 4. 数据预处理
def preprocess_function(sample):
    full_prompt = f"{sample['input']} {sample['output']}{tokenizer.eos_token}"
    tokenized = tokenizer(
        full_prompt,
        truncation=True,
        max_length=512,
        padding="max_length",
        add_special_tokens=False
    )

    input_ids = tokenizer.encode(sample["input"], add_special_tokens=False)
    input_len = len(input_ids)

    labels = [-100]*input_len + tokenized["input_ids"][input_len:]

    return {
        "input_ids": tokenized["input_ids"],
        "attention_mask": tokenized["attention_mask"],
        "labels": labels,
        "input_text": sample["input"],
        "output_text": sample["output"]
    }

train_dataset = formatted_dataset["train"].map(
    preprocess_function,
    remove_columns=["input", "output"],
    desc="Processing train set"
)
eval_dataset = formatted_dataset["test"].map(
    preprocess_function,
    remove_columns=["input", "output"],
    desc="Processing test set"
)

# 5. 评估回调（修复进程判断）
class AccuracyCallback(TrainerCallback):
    def __init__(self, tokenizer, output_dir_base, eval_steps=500):
        self.tokenizer = tokenizer
        self.output_dir_base = output_dir_base
        self.state_file = os.path.join(output_dir_base, "callback_state.json")
        
        # 加载之前保存的状态（兼容新旧格式）
        if os.path.exists(self.state_file):
            with open(self.state_file, 'r') as f:
                state = json.load(f)
                
                # 处理旧版列表格式的准确率数据
                if isinstance(state.get('epoch_accuracies', []), list):
                    old_list = state['epoch_accuracies']
                    self.epoch_accuracies = {i: acc for i, acc in enumerate(old_list)}
                else:
                    self.epoch_accuracies = {int(k): v for k, v in state.get('epoch_accuracies', {}).items()}
                
                self.best_accuracy = state.get('best_accuracy', 0.0)
                self.best_epoch = state.get('best_epoch', 0)
        else:
            self.epoch_accuracies = {}  # 改为字典存储
            self.best_accuracy = 0.0
            self.best_epoch = 0

    def on_evaluate(self, args, state, control, **kwargs):
        model = kwargs["model"]
        eval_dataloader = kwargs["eval_dataloader"]

        total = 0
        correct = 0
        
        model.eval()
        for batch in eval_dataloader:
            inputs = self.tokenizer(
                batch["input_text"],
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="pt",
                add_special_tokens=False
            ).to(model.device)

            with torch.no_grad():
                outputs = model.generate(
                    inputs.input_ids,
                    attention_mask=inputs.attention_mask,
                    max_new_tokens=20,
                    pad_token_id=tokenizer.eos_token_id
                )

            preds = self.tokenizer.batch_decode(
                outputs[:, inputs.input_ids.shape[1]:],
                skip_special_tokens=True
            )

            for pred, true in zip(preds, batch["output_text"]):
                clean_pred = pred.split("\n")[0].strip()
                total += 1
                # print('-'*30)
                # print('true: ', true)
                # print('pred: ', pred)
                # print('clean_pred:', clean_pred)
                correct += int(clean_pred == true)
        # 跨进程聚合结果
        total_tensor = torch.tensor(total, device=model.device)
        correct_tensor = torch.tensor(correct, device=model.device)
        all_reduce(total_tensor, op=ReduceOp.SUM)
        all_reduce(correct_tensor, op=ReduceOp.SUM)
        
        total = total_tensor.item()
        correct = correct_tensor.item()
        accuracy = correct / total

        # 记录当前epoch的准确率
        current_epoch = int(state.epoch)
        self.epoch_accuracies[current_epoch] = accuracy  # 使用字典存储
        
        # 更新最佳准确率
        if state.is_local_process_zero and accuracy > self.best_accuracy:
            self.best_accuracy = accuracy
            self.best_epoch = current_epoch
            best_model_dir = os.path.join(self.output_dir_base, "best_model")
            # model.save_pretrained(best_model_dir)
            # tokenizer.save_pretrained(best_model_dir)
            # print(f"New best model saved to {best_model_dir}")

        if state.is_local_process_zero:
            print(f"\nValidation Accuracy at Epoch {current_epoch}: {accuracy:.4f}")
            print(f"Best Accuracy: {self.best_accuracy:.4f} at Epoch {self.best_epoch}")
            # 保存时转换字典的key为字符串（JSON要求）
            with open(self.state_file, 'w') as f:
                json.dump({
                    'epoch_accuracies': {str(k): v for k, v in self.epoch_accuracies.items()},
                    'best_accuracy': self.best_accuracy,
                    'best_epoch': self.best_epoch
                }, f)

# 6. 训练配置（调整批次大小和输出路径）

output_dir_base = f"./results/{dataset_name}/result_{num_train_samples}" # 修改为新的基础路径
output_dir_ckp = os.path.join(output_dir_base, "ckp") # ckp 保存路径
output_dir_result = os.path.join(output_dir_base, "result") # result json 保存路径
os.makedirs(output_dir_result, exist_ok=True) 
last_checkpoint = None
if os.path.exists(output_dir_ckp): # 检查 ckp 路径
    try:
        last_checkpoint = trainer_utils.get_last_checkpoint(output_dir_ckp)
    except FileNotFoundError:
        last_checkpoint = None
else:
    # 确保输出目录存在（首次运行时会自动创建）
    os.makedirs(output_dir_ckp, exist_ok=True) # 创建 ckp 路径

print(f"检测到最新检查点: {last_checkpoint or '无'}")
training_args = TrainingArguments(
    output_dir=output_dir_ckp,  # 修改为动态 ckp 路径
    per_device_train_batch_size=2,
    per_device_eval_batch_size=2,
    gradient_accumulation_steps=4,
    num_train_epochs=20,
    learning_rate=2e-5,
    fp16=True,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    save_steps=50,
    save_total_limit=1,  # 改为保留2个检查点
    logging_steps=10,
    report_to="none",
    optim="adamw_torch",
    remove_unused_columns=False,
    ddp_find_unused_parameters=False,  # 添加此行防止LoRA参数问题
    dataloader_num_workers=8,         # 根据CPU核心数调整
)

# 7. 创建训练器
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=CustomDataCollator(tokenizer=tokenizer, mlm=False),
    callbacks=[AccuracyCallback(
    tokenizer=tokenizer,
    output_dir_base=output_dir_base  # 添加这个参数
)]
)

# 8. 开始训练
print(f"是否存在可用检查点: {last_checkpoint is not None}")
trainer.train(resume_from_checkpoint=last_checkpoint)  # 修改训练启动方式

# 9. 最终测试和保存结果
print("\nFinal Evaluation:")
eval_results = trainer.evaluate()

# 从回调中提取历史准确率和最佳值
accuracy_callback = None
for callback in trainer.callback_handler.callbacks:
    if isinstance(callback, AccuracyCallback):
        accuracy_callback = callback
        break

if accuracy_callback:
    # 将字典转换为按epoch排序的列表
    sorted_epochs = sorted(accuracy_callback.epoch_accuracies.keys())
    epoch_accuracies_list = [accuracy_callback.epoch_accuracies[epoch] for epoch in sorted_epochs]
    
    eval_results["epoch_accuracies"] = epoch_accuracies_list
    eval_results["best_accuracy"] = accuracy_callback.best_accuracy
    eval_results["best_epoch"] = accuracy_callback.best_epoch
    print(f"\nBest Validation Accuracy: {accuracy_callback.best_accuracy:.4f} at Epoch {accuracy_callback.best_epoch}")
else:
    print("Warning: AccuracyCallback not found, accuracy history not saved.")

result_file_path = os.path.join(output_dir_result, "results.json")
existing_data = {}
if os.path.exists(result_file_path):
    with open(result_file_path, 'r') as f:
        existing_data = json.load(f)

merged_results = {
    "all_epochs": existing_data.get("all_epochs", []) + eval_results["epoch_accuracies"],
    "best_accuracy": max(existing_data.get("best_accuracy", 0.0), eval_results["best_accuracy"]),
    "best_epoch": eval_results["best_epoch"] if eval_results["best_accuracy"] > existing_data.get("best_accuracy", 0.0) 
                  else existing_data.get("best_epoch", 0)
}

with open(result_file_path, 'w') as f:
    json.dump(merged_results, f, indent=4)