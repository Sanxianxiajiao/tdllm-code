import torch
import os
import json
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    BitsAndBytesConfig,
    GenerationConfig
)
from peft import LoraConfig, get_peft_model
from sklearn.metrics import f1_score
import argparse
from torch.distributed import all_reduce, ReduceOp
from transformers import TrainerCallback
from transformers import trainer_utils
import random
import numpy as np
import torch
import os


def set_all_seeds(seed=42):
    # 在分布式环境中同步种子
    if torch.distributed.is_initialized():
        # 确保所有进程使用相同种子
        seed_tensor = torch.tensor(seed, dtype=torch.int32, device='cuda')
        torch.distributed.broadcast(seed_tensor, src=0)
        seed = seed_tensor.item()
    # 设置Python随机种子
    random.seed(seed)
    
    # 设置Numpy随机种子
    np.random.seed(seed)
    
    # 设置PyTorch随机种子
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    
    # 设置cuDNN确定性模式
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    # 设置环境变量
    os.environ["PYTHONHASHSEED"] = str(seed)
    
    # 设置HuggingFace Transformers的随机种子
    from transformers import set_seed as hf_set_seed
    hf_set_seed(seed)
    
    # 设置datasets库缓存（兼容不同版本）
    try:
        from datasets import set_caching_enabled  # 新版库 (>1.14.0)
        set_caching_enabled(True)
    except ImportError:
        os.environ["DISABLE_DATASETS_CACHING"] = "0"  # 旧版库设置环境变量
    
# 使用示例
set_all_seeds(42)


# 自定义数据整理器
from typing import Union, List, Dict

# 修正后的数据整理器类定义
class CustomDataCollator(DataCollatorForLanguageModeling):
    def __call__(self, features):
        # 确保访问正确的字段名
        prompt_texts = [f.pop("input") for f in features]
        answer_texts = [f.pop("output") for f in features]
        
        batch = super().__call__(features)
        batch["input_text"] = prompt_texts
        batch["output_text"] = answer_texts
        return batch

from datasets import load_dataset
from typing import Union, List, Dict
import torch

# 定义关系标签列表（顺序必须与数据集一致）
RELATION_LABELS = [
                    "Cause-Effect(e1,e2)",
                    "Cause-Effect(e2,e1)",
                    "Component-Whole(e1,e2)",
                    "Component-Whole(e2,e1)",
                    "Content-Container(e1,e2)",
                    "Content-Container(e2,e1)",
                    "Entity-Destination(e1,e2)",
                    "Entity-Destination(e2,e1)",
                    "Entity-Origin(e1,e2)",
                    "Entity-Origin(e2,e1)",
                    "Instrument-Agency(e1,e2)",
                    "Instrument-Agency(e2,e1)",
                    "Member-Collection(e1,e2)",
                    "Member-Collection(e2,e1)",
                    "Message-Topic(e1,e2)",
                    "Message-Topic(e2,e1)",
                    "Product-Producer(e1,e2)",
                    "Product-Producer(e2,e1)",
                    "Other",
                ]


# 加载数据集
dataset = load_dataset("sem_eval_2010_task_8")

# 验证标签范围
print(f"最大关系索引: {max(dataset['train']['relation'])}")  # 应为18
print(dataset)

def format_instruction(sample):
    raw_sentence = sample["sentence"]
    relation_idx = sample["relation"]

    if relation_idx >= len(RELATION_LABELS):
        raise ValueError(f"Invalid relation index {relation_idx}")
    base_relation = RELATION_LABELS[relation_idx]
    
    # Extract entities
    e1_start = raw_sentence.find("<e1>") + 4
    e1_end = raw_sentence.find("</e1>")
    e1 = raw_sentence[e1_start:e1_end]
    
    e2_start = raw_sentence.find("<e2>") + 4
    e2_end = raw_sentence.find("</e2>")
    e2 = raw_sentence[e2_start:e2_end]
    
    # Clean text
    clean_sentence = raw_sentence.replace("<e1>", "").replace("</e1>", "") \
                                 .replace("<e2>", "").replace("</e2>", "")
    
    # Create enhanced instruction
    relations = set(RELATION_LABELS)  # Deduplicate while preserving order
    relations_list = '\n'.join([f'{i+1}. {rel}' for i, rel in enumerate(relations)])
    
    instruction = (
        f"Please classify the relationship between the two entities in the given text into one of the following categories:\n\n"
        f"Available relationship types:\n"
        f"{relations_list}\n\n"
        f"Task requirements:\n"
        f"- Output only the relationship type from the list above, using the exact same spelling and casing\n"
        f"- Do not include any explanations or additional text\n\n"
        f"Input text:\n"
        f"{clean_sentence}\n"
        f"Entity 1: {e1}\n"
        f"Entity 2: {e2}\n"
        f"Relationship:"
    )
    
    return {
        "input": instruction,
        "output": base_relation
    }


# 应用预处理
formatted_dataset = dataset.map(
    format_instruction,
    remove_columns=["sentence", "relation"],
    desc="Formatting instructions"
)
# 验证输出
print("\n预处理后的样本示例：")
print(formatted_dataset["train"][0]["input"])
print("Output:", formatted_dataset["train"][0])

# 2. 模型加载
model_name = "meta-llama/Llama-3.1-8B-Instruct"


tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    padding_side='left'
)
tokenizer.pad_token = tokenizer.eos_token

# 添加特殊标记（处理实体定位）
entity_markers = ['<e1>', '</e1>', '<e2>', '</e2>']
tokenizer.add_special_tokens({'additional_special_tokens': entity_markers})

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    # device_map="auto",
    torch_dtype=torch.float16
)
model.resize_token_embeddings(len(tokenizer))  # 调整嵌入层大小

# 3. LoRA配置（保持结构）
peft_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, peft_config)

# 4. 数据预处理函数（调整标签处理）
def preprocess_function(sample):
    full_prompt = f"{sample['input']} {sample['output']}{tokenizer.eos_token}"
    
    tokenized = tokenizer(
        full_prompt,
        truncation=True,
        max_length=512,
        padding="max_length",
        add_special_tokens=False
    )

    input_ids = tokenizer.encode(sample["input"], add_special_tokens=False)
    input_len = len(input_ids)

    labels = [-100]*input_len + tokenized["input_ids"][input_len:]

    return {
        "input_ids": tokenized["input_ids"],
        "attention_mask": tokenized["attention_mask"],
        "labels": labels,
        "input": sample["input"],   # 保留原始输入字段名
        "output": sample["output"]  # 保留原始输出字段名
    }

# 5. 训练参数配置（保持超参数一致）
parser = argparse.ArgumentParser()
parser.add_argument("--num_train_samples", type=float, default=-1)
args = parser.parse_args()

# 数据集切片（与原始代码相同逻辑）
num_train_samples_full = len(formatted_dataset["train"])
num_train_samples = args.num_train_samples if args.num_train_samples > 0 else num_train_samples_full
if  num_train_samples > 0 and num_train_samples <= 1:
    num_train_samples = int(num_train_samples_full * num_train_samples)
else:
    num_train_samples = int(num_train_samples)

formatted_dataset["train"] = formatted_dataset["train"].select(range(num_train_samples))
formatted_dataset["test"] = formatted_dataset["test"]
print(formatted_dataset)

output_dir_base = f"./results/semeval2010_task8/result_{num_train_samples}"
output_dir_ckp = os.path.join(output_dir_base, "ckp")
os.makedirs(output_dir_ckp, exist_ok=True)

# 应用预处理
train_dataset = formatted_dataset["train"].map(
    preprocess_function,
    remove_columns=formatted_dataset["train"].column_names,  # 仅移除原始列
    desc="Processing train set"
)

eval_dataset = formatted_dataset["test"].map(
    preprocess_function,
    remove_columns=formatted_dataset["test"].column_names,  # 仅移除原始列
    desc="Processing test set"
)
print(dataset)
print('train_samples: ', len(train_dataset))
print('test_samples: ', len(eval_dataset))



# 6. 评估回调（修改为F1计算）
class F1Callback(TrainerCallback):
    def __init__(self, tokenizer, output_dir_base, label_list):
        self.tokenizer = tokenizer
        self.output_dir_base = output_dir_base
        self.label_list = label_list
        self.state_file = os.path.join(output_dir_base, "callback_state.json")
        self.label2id = {l: i for i, l in enumerate(label_list)}
        
        # 获取分布式训练参数
        self.local_rank = int(os.environ.get("LOCAL_RANK", -1))
        self.world_size = int(os.environ.get("WORLD_SIZE", 1))
        self.is_main_process = self.local_rank in {-1, 0}  # 兼容单机多卡和多机训练
        
        # 恢复状态
        if os.path.exists(self.state_file):
            with open(self.state_file, 'r') as f:
                state = json.load(f)
                self.epoch_f1_scores = {int(k): v for k, v in state.get('epoch_f1_scores', {}).items()}
                self.best_f1 = state.get('best_f1', 0.0)
                self.best_epoch = state.get('best_epoch', 0)
        else:
            self.epoch_f1_scores = {}
            self.best_f1 = 0.0
            self.best_epoch = 0

    def on_evaluate(self, args, state, control, **kwargs):
    # 确保所有进程同步
        if torch.distributed.is_initialized():
            torch.distributed.barrier()

        model = kwargs["model"]
        eval_dataloader = kwargs["eval_dataloader"]

        # 各进程独立生成预测
        all_preds = []
        all_labels = []
        
        model.eval()
        for batch in eval_dataloader:
            inputs = self.tokenizer(
                batch["input_text"],
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="pt",
                add_special_tokens=False
            ).to(model.device)

            # 确保生成确定性
            generation_config = GenerationConfig(
                max_new_tokens=10,
                temperature=0.001,
                num_beams=3,
                early_stopping=True,
                do_sample=False,
                num_beam_groups=1
            )

            with torch.no_grad():
                outputs = model.generate(
                    inputs.input_ids,
                    attention_mask=inputs.attention_mask,
                    generation_config=generation_config,
                    pad_token_id=tokenizer.eos_token_id
                )

            preds = self.tokenizer.batch_decode(
                outputs[:, inputs.input_ids.shape[1]:],
                skip_special_tokens=True
            )

            # 清洗预测结果
            clean_preds = [p.split('\n')[0].strip() for p in preds]
            true_labels = batch["output_text"]
            
            all_preds.extend(clean_preds)
            all_labels.extend(true_labels)

        # 转换为标签ID张量
        pred_ids = [self.label2id.get(p, -1) for p in all_preds]
        label_ids = [self.label2id[l] for l in all_labels]
        
        # 转换为PyTorch张量
        pred_tensor = torch.tensor(pred_ids, dtype=torch.long, device=model.device)
        label_tensor = torch.tensor(label_ids, dtype=torch.long, device=model.device)

        # 分布式数据收集
        if self.world_size > 1:
            # 准备收集容器
            gather_preds = [torch.zeros_like(pred_tensor) for _ in range(self.world_size)]
            gather_labels = [torch.zeros_like(label_tensor) for _ in range(self.world_size)]
            
            # 执行全收集
            torch.distributed.all_gather(gather_preds, pred_tensor)
            torch.distributed.all_gather(gather_labels, label_tensor)
            
            # 仅主进程处理数据
            if self.is_main_process:
                # 展平所有结果并转换为numpy
                all_pred_ids = torch.cat([x.view(-1) for x in gather_preds]).cpu().numpy()
                all_label_ids = torch.cat([x.view(-1) for x in gather_labels]).cpu().numpy()
        else:
            all_pred_ids = np.array(pred_ids)
            all_label_ids = np.array(label_ids)

        # 主进程计算指标
        if self.is_main_process:
            # 处理标量情况（当所有预测都无效时）
            if all_pred_ids.ndim == 0:
                all_pred_ids = np.expand_dims(all_pred_ids, 0)
            if all_label_ids.ndim == 0:
                all_label_ids = np.expand_dims(all_label_ids, 0)

            # 过滤无效预测
            valid_mask = (all_pred_ids != -1)
            valid_preds = all_pred_ids[valid_mask]
            valid_labels = all_label_ids[valid_mask]
            
            # 计算F1（处理空预测情况）
            if valid_preds.size > 0:
                f1 = f1_score(valid_labels, valid_preds, average='macro')
            else:
                f1 = 0.0
                print("Warning: No valid predictions in this evaluation")

            # 更新最佳模型
            current_epoch = int(state.epoch)
            self.epoch_f1_scores[current_epoch] = f1
            
            if f1 > self.best_f1:
                self.best_f1 = f1
                self.best_epoch = current_epoch
                best_model_dir = os.path.join(self.output_dir_base, "best_model")
                # model.save_pretrained(best_model_dir)
                # tokenizer.save_pretrained(best_model_dir)
                # print(f"\nNew best model saved at epoch {current_epoch} with F1: {f1:.4f}")

            print(f"Validation F1 at Epoch {current_epoch}: {f1:.4f}")
            print(f"Best F1: {self.best_f1:.4f} (epoch {self.best_epoch})")
            
            # 保存状态
            with open(self.state_file, 'w') as f:
                json.dump({
                    'epoch_f1_scores': {str(k): v for k, v in self.epoch_f1_scores.items()},
                    'best_f1': self.best_f1,
                    'best_epoch': self.best_epoch
                }, f, indent=4)

        # 同步所有进程
        if torch.distributed.is_initialized():
            torch.distributed.barrier()


training_args = TrainingArguments(
    save_total_limit=1,  # 改为保留1个检查点
    output_dir=output_dir_ckp,
    per_device_train_batch_size=2,
    per_device_eval_batch_size=2,
    gradient_accumulation_steps=4,
    num_train_epochs=50,
    learning_rate=2e-5,
    fp16=True,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    logging_steps=10,
    optim="paged_adamw_32bit",  # 添加分页优化器防止OOM
    report_to="none",
    ddp_find_unused_parameters=False,
    remove_unused_columns=False,
    seed=42,                     # 显式设置训练器种子
    dataloader_drop_last=True,  # 确保所有节点数据对齐
)

# 7. 创建训练器（替换为F1回调）
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=CustomDataCollator(tokenizer=tokenizer, mlm=False),
    callbacks=[F1Callback(
        tokenizer=tokenizer,
        output_dir_base=output_dir_base,
        label_list=RELATION_LABELS
    )]
)

# 8. 开始训练（保持相同恢复逻辑）
last_checkpoint = None
if os.path.exists(output_dir_ckp):
    try:
        last_checkpoint = trainer_utils.get_last_checkpoint(output_dir_ckp)
    except FileNotFoundError:
        pass

trainer.train(resume_from_checkpoint=last_checkpoint)

# 9. 最终测试和保存（修改为保存F1结果）
print("\nFinal Evaluation:")
eval_results = trainer.evaluate()

# 提取F1结果（与原始代码相似）
f1_callback = next(cb for cb in trainer.callback_handler.callbacks if isinstance(cb, F1Callback))
eval_results["best_f1"] = f1_callback.best_f1
eval_results["best_epoch"] = f1_callback.best_epoch

result_file_path = os.path.join(output_dir_base, "results.json")
with open(result_file_path, 'w') as f:
    json.dump(eval_results, f, indent=4)