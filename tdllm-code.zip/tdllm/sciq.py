import torch
import os
import json
import re
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    trainer_utils
)
from peft import LoraConfig, get_peft_model
from transformers import TrainerCallback
from typing import Dict, List, Union
import argparse
from torch.distributed import all_reduce, ReduceOp
import random
import numpy as np
import torch
import hashlib  # 新增导入

# 设置随机种子（保持与原代码一致）
def set_all_seeds(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"  # 新增CUDA确定性配置
set_all_seeds(42)

# 自定义数据整理器（保持原结构）
class CustomDataCollator(DataCollatorForLanguageModeling):
    def __call__(self, features: List[Dict[str, Union[List[int], str]]]) -> Dict[str, torch.Tensor]:
        input_texts = [feature.pop("input_text") for feature in features]
        output_texts = [feature.pop("output_text") for feature in features]
        batch = super().__call__(features)
        batch["input_text"] = input_texts
        batch["output_text"] = output_texts
        return batch

# 1. 数据准备
def load_sciq():
    dataset = load_dataset("allenai/sciq")
    print("SciQ数据集结构:", dataset)
    
    def format_instruction(sample):
        question = sample["question"]
        # 组合选项：正确选项 + 3个干扰项
        options = [
            sample["correct_answer"],
            sample["distractor1"],
            sample["distractor2"],
            sample["distractor3"]
        ]
        if len(sample['support']) < 712:
            support = sample['support'] +'\n'
        else:
            support = ''
        # 打乱选项顺序以避免位置偏差
        random.shuffle(options)
        shuffled = list(enumerate(options))
        correct_idx = [i for i, opt in shuffled if opt == sample["correct_answer"]][0]
        # 构建选项文本
        option_letters = ["A", "B", "C", "D"]
        formatted_options = "\n".join([
            f"{letter}. {text}" 
            for letter, text in zip(option_letters, [opt for _, opt in shuffled])
        ])
        return {
            "input": (
                "Answer this science question. The answer must be a single uppercase letter (A-D).\n"
                f"Question: {question}\n"
                "Options:\n"
                f"{formatted_options}\n"
                "Answer:"
            ),
            "output": support + 'The answer is ' + option_letters[correct_idx] + '.'  # 返回理由打乱后的正确选项字母
        }
    
    # 移除原始列
    columns_to_remove = dataset["train"].column_names
    return dataset.map(format_instruction, remove_columns=columns_to_remove)

dataset = load_sciq()

# 数据切片逻辑（保持与原代码一致）
parser = argparse.ArgumentParser()
parser.add_argument("--num_train_samples", type=float, default=-1)
args = parser.parse_args()

num_train_samples_full = len(dataset["train"])
num_train_samples = args.num_train_samples if args.num_train_samples > 0 else num_train_samples_full
if  num_train_samples > 0 and num_train_samples <= 1:
    num_train_samples = int(num_train_samples_full * num_train_samples)
else:
    num_train_samples = int(num_train_samples)

dataset["train"] = dataset["train"].select(range(num_train_samples))
dataset["test"] = dataset["test"]
dataset["validation"] = dataset["test"]
print(dataset)

# 2. 模型加载（保持原参数）
model_name = "meta-llama/Llama-3.1-8B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side='left')
tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    # device_map="auto"
)

# 3. LoRA配置（保持原参数）
peft_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, peft_config)

# 4. 数据预处理（适配新格式）
def preprocess_function(sample):
    full_prompt = f"{sample['input']} {sample['output']}{tokenizer.eos_token}"
    tokenized = tokenizer(
        full_prompt,
        truncation=True,
        max_length=1024,
        padding="max_length",
        add_special_tokens=False
    )
    
    # 计算输入部分长度
    input_ids = tokenizer.encode(sample["input"], add_special_tokens=False)
    input_len = len(input_ids)
    
    # 标签处理（仅计算答案部分）
    labels = [-100] * input_len + tokenized["input_ids"][input_len:]
    # print('output:',sample["output"])
    return {
        "input_ids": tokenized["input_ids"],
        "attention_mask": tokenized["attention_mask"],
        "labels": labels,
        "input_text": sample["input"],
        "output_text": sample["output"]
    }

train_dataset = dataset["train"].map(
    preprocess_function, 
    remove_columns=["input", "output"]  # 移除原始的input/output，保留预处理后的字段
)
eval_dataset = dataset["validation"].map(
    preprocess_function, 
    remove_columns=["input", "output"]
)
# print(eval_dataset[0])

# 5. 评估回调（修改答案提取逻辑）
class SciQCallback(TrainerCallback):
    def __init__(self, tokenizer, output_dir_base):
        super().__init__()
        self.output_dir_base = output_dir_base
        self.option_pattern = re.compile(r'\b([A-D])\b')
        self.state_file = os.path.join(output_dir_base, "callback_state.json")
        self.epoch_accuracies = {}
        self.best_accuracy = 0.0
        self.best_epoch = 0
        
        # 加载历史状态（增加异常处理）
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as f:
                    state = json.load(f)
                    # 转换字符串key为整数
                    self.epoch_accuracies = {int(k): v for k, v in state.get('epoch_accuracies', {}).items()}
                    self.best_accuracy = state.get('best_accuracy', 0.0)
                    self.best_epoch = state.get('best_epoch', 0)
            except (json.JSONDecodeError, KeyError):
                print("Warning: State file corrupted, initializing new state")
                self.epoch_accuracies = {}
                self.best_accuracy = 0.0
                self.best_epoch = 0
        

    def extract_answer(self, text):
        # 匹配所有A-D的大写字母（带单词边界保护）
        matches = re.findall(r'\b([A-D])\b', text)
        # 返回最后一个匹配项（如果存在）
        return matches[-1] if matches else '###'
    
    def on_evaluate(self, args, state, control, **kwargs):
        # 所有进程都参与评估
        model = kwargs["model"]
        eval_dataloader = kwargs["eval_dataloader"]
        
        total = 0
        correct = 0
        
        model.eval()
        from tqdm import tqdm
        for batch in tqdm(eval_dataloader, desc="Evaluating"):
            batch = {k: v.to(model.device) if isinstance(v, torch.Tensor) else v 
                    for k, v in batch.items()}
            with torch.no_grad():
                    outputs = model.generate(
                    input_ids=batch["input_ids"],
                    attention_mask=batch["attention_mask"],
                    max_new_tokens=1024,
                    pad_token_id=tokenizer.eos_token_id
                )
            
            # 解码预测结果
            preds = tokenizer.batch_decode(
                outputs[:, batch["input_ids"].shape[1]:], 
                skip_special_tokens=True
            )
            
            # 提取真实答案（修复原代码中的位置索引错误）
            true_answers = [self.extract_answer(t) for t in batch["output_text"]]  # 使用统一提取方法
            
            for pred, true in zip(preds, true_answers):
                # print('-'*30)
                # print(true)
                # print(pred)
                
                extracted = self.extract_answer(pred)
                total += 1
                correct += int(extracted == true)
                print(correct / total)
        
        # 分布式聚合
        if torch.distributed.is_initialized():
            correct_tensor = torch.tensor(correct, device=model.device)
            total_tensor = torch.tensor(total, device=model.device)
            torch.distributed.all_reduce(correct_tensor, op=ReduceOp.SUM)
            torch.distributed.all_reduce(total_tensor, op=ReduceOp.SUM)
            correct = correct_tensor.item()
            total = total_tensor.item()
            # print(correct)
            # print(total)
            # print(correct / total)

        # 仅主进程记录结果
        if state.is_local_process_zero and state.epoch:
            accuracy = correct / total if total > 0 else 0.0
            current_epoch = int(state.epoch)
            
            # 更新epoch记录
            self.epoch_accuracies[current_epoch] = accuracy
            
            # 更新最佳模型逻辑
            if accuracy > self.best_accuracy:
                self.best_accuracy = accuracy
                self.best_epoch = current_epoch
                # model.save_pretrained(os.path.join(self.output_dir_base, "best_model"))
                # tokenizer.save_pretrained(os.path.join(self.output_dir_base, "best_model"))
            
            # 保存完整状态（包含所有epoch记录）
            state_data = {
                "epoch_accuracies": self.epoch_accuracies,
                "best_accuracy": self.best_accuracy,
                "best_epoch": self.best_epoch
            }
            with open(self.state_file, 'w') as f:
                json.dump(state_data, f)

# 6. 训练配置（保持原超参数）
output_dir_base = f"./results/sciq/result_{num_train_samples}"
output_dir_ckp = os.path.join(output_dir_base, "ckp")
output_dir_result = os.path.join(output_dir_base, "result")

os.makedirs(output_dir_ckp, exist_ok=True)  # 先确保目录存在

last_checkpoint = None
try:
    last_checkpoint = trainer_utils.get_last_checkpoint(output_dir_ckp)
except FileNotFoundError:
    last_checkpoint = None
training_args = TrainingArguments(
    output_dir=os.path.join(output_dir_base, "ckp"),
    per_device_train_batch_size=1,
    per_device_eval_batch_size=4,
    gradient_accumulation_steps=8,
    num_train_epochs=20,
    learning_rate=2e-5,
    fp16=True,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    save_total_limit=1,
    logging_steps=10,
    report_to="none",
    optim="adamw_torch",
    remove_unused_columns=False,
    ddp_find_unused_parameters=False,
    dataloader_num_workers=8,
    dataloader_pin_memory=True,       # 提升数据传输效率
    dataloader_drop_last=True,         # 避免最后批次尺寸问题
)

os.makedirs(output_dir_result, exist_ok=True)
# 7. 创建训练器
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=CustomDataCollator(tokenizer=tokenizer, mlm=False),
    callbacks=[SciQCallback(tokenizer, output_dir_base)]  # 使用新的回调类
)

# 8. 开始训练
print(f"是否存在可用检查点: {last_checkpoint is not None}")
trainer.train(resume_from_checkpoint=last_checkpoint)

# final_model_dir = os.path.join(output_dir_base, "final_model")
# trainer.save_model(final_model_dir)
# print(f"\nFinal model saved to {final_model_dir}")

# 9. 结果记录
# eval_results = trainer.evaluate(eval_dataset=dataset["validation"])
eval_results = trainer.evaluate(eval_dataset=eval_dataset)
# 从回调中提取结果
accuracy_callback = None
for callback in trainer.callback_handler.callbacks:
    if isinstance(callback, SciQCallback):
        accuracy_callback = callback
        break

if accuracy_callback:
    sorted_epochs = sorted(accuracy_callback.epoch_accuracies.keys())
    epoch_accuracies_list = [accuracy_callback.epoch_accuracies[epoch] for epoch in sorted_epochs]
    
    result_data = {
        "epoch_accuracies": epoch_accuracies_list,
        "best_accuracy": accuracy_callback.best_accuracy,
        "best_epoch": accuracy_callback.best_epoch,
        "final_loss": eval_results["eval_loss"]
    }
    
    print(f"\nBest Validation Accuracy: {accuracy_callback.best_accuracy:.4f} at Epoch {accuracy_callback.best_epoch}")
else:
    result_data = {"error": "Callback not found"}
    print("Warning: Accuracy tracking data not available")

# 合并历史结果
result_file_path = os.path.join(output_dir_result, "results.json")
existing_data = {}
if os.path.exists(result_file_path):
    try:
        with open(result_file_path, 'r') as f:
            existing_data = json.load(f)
    except json.JSONDecodeError:
        print("Warning: Results file corrupted, initializing new results")
        existing_data = {}

# 转换现有数据中的epoch记录
existing_epochs = {int(k): v for k, v in existing_data.get("all_epochs", {}).items()}

# 合并新旧结果
merged_epochs = {**existing_epochs, **accuracy_callback.epoch_accuracies}
best_accuracy = max(existing_data.get("best_accuracy", 0.0), accuracy_callback.best_accuracy)
best_epoch = accuracy_callback.best_epoch if accuracy_callback.best_accuracy >= existing_data.get("best_accuracy", 0.0) else existing_data.get("best_epoch", 0)

merged_results = {
    "all_epochs": merged_epochs,
    "best_accuracy": best_accuracy,
    "best_epoch": best_epoch,
    "final_loss": eval_results.get("eval_loss", None)
}

with open(result_file_path, 'w') as f:
    json.dump(merged_results, f, indent=4)