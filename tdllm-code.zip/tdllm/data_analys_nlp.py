import torch
import transformers
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    pipeline # Potentially useful for easier embedding later if needed
)
from datasets import load_dataset, DatasetDict, Dataset
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
from sklearn.model_selection import train_test_split as sklearn_train_test_split # Rename to avoid clash
from scipy.stats import entropy
from scipy.spatial.distance import euclidean
import pandas as pd
import os
import json
import argparse
from tqdm import tqdm
import gc # Garbage collector
import hashlib
import random
from collections import Counter, defaultdict
import ast # For CLUTRR parsing

# --- Configuration ---
# Important: Set DATA_ROOT to where your datasets are/will be downloaded
DATA_ROOT = './datasets'
# Important: Set OUTPUT_DIR for saving results
OUTPUT_DIR = './data_analys_nlp'
# Select the embedding model
EMBEDDING_MODEL_NAME = "meta-llama/Llama-3.1-8B-Instruct"
# Metric calculation parameters
PCA_VARIANCE_THRESHOLD = 0.95
K_NEIGHBORS = 15
# Subsampling limits (adjust based on your compute resources)
MAX_SAMPLES_FOR_EMBEDDING = 1000000 # Max samples to generate embeddings for (uses stratified sampling if exceeded)
SILHOUETTE_SAMPLE_SIZE = 10000   # Max samples for Silhouette score calculation
# Embedding generation parameters
EMBEDDING_BATCH_SIZE = 4        # Adjust based on GPU memory (8B model needs small batches)
MAX_TOKEN_LENGTH = 1024          # Max sequence length for tokenizer/model

# --- Device Setup ---
if torch.cuda.is_available():
    device = torch.device("cuda")
    print(f"Using CUDA device: {torch.cuda.get_device_name(0)}")
else:
    # Fallback to CPU - WARNING: Extremely slow for 8B model embeddings
    device = torch.device("cpu")
    print("Warning: CUDA not available. Using CPU. Embedding generation will be VERY slow.")

# Optional: Login to Hugging Face Hub if needed for private models/gated access
# from huggingface_hub import login
# login("YOUR_HF_TOKEN") # Replace with your token if needed


# === Dataset Loading and Preprocessing Hub ===

def load_and_preprocess_nlp_dataset(dataset_name, data_root, seed=42):
    """
    Loads, preprocesses, and formats various NLP datasets for complexity analysis.

    Returns:
        tuple: (processed_train_dataset, id_to_label_map)
               - processed_train_dataset: Dataset object with 'input_text_for_embedding' and 'label' columns.
               - id_to_label_map: Dictionary mapping integer labels back to original label names/representations.
    """
    print(f"\n--- Loading and Preprocessing: {dataset_name} ---")
    raw_dataset = None
    input_text_col = "input_text_for_embedding"
    label_col = "label"
    original_label_col = "original_label" # Temporary column for mapping

    # --- Dataset Specific Loading and Formatting ---

    if dataset_name == 'ag_news':
        raw_dataset = load_dataset("ag_news", cache_dir=data_root)
        label_names = raw_dataset["train"].features["label"].names
        id_to_label_map = {i: name for i, name in enumerate(label_names)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}

        def format_ag_news(example):
            return {
                input_text_col: example['text'],
                original_label_col: label_names[example['label']] # Use label name for consistency
            }
        processed_dataset = raw_dataset.map(format_ag_news, remove_columns=['text', 'label'])

    elif dataset_name == 'aqua_rat':
        raw_dataset = load_dataset("aqua_rat", "raw", cache_dir=data_root)
        # Correct options are A-E
        label_names = ["A", "B", "C", "D", "E"]
        id_to_label_map = {i: name for i, name in enumerate(label_names)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}

        def format_aqua(sample):
            # Format input similar to training script, but stop before rationale/answer
            input_prompt = (
                f"Answer the question. Your final answer must be a single uppercase letter (A-E) formatted as: \n"
                "#### Final Answer: your answer.\n"
                "Non-compliant responses will be invalid.\n"
                f"Question: {sample['question']}\n"
                f"Options:\n{sample['options']}\n" # Keep options in the input
                f"Let's reason step by step." # Prompt model to think
                 # STOP before revealing the answer
            )
            return {
                input_text_col: input_prompt,
                original_label_col: sample['correct'] # The correct letter 'A'-'E'
            }
        processed_dataset = raw_dataset.map(format_aqua, remove_columns=raw_dataset["train"].column_names)

    elif dataset_name == 'conll2003':
        # Assumes 'conll2003_dataprocess.py' is in the same directory or accessible
        try:
             raw_dataset = load_dataset("./conll2003_dataprocess.py", name="conll2003", cache_dir=data_root)
        except FileNotFoundError:
             print("Error: conll2003_dataprocess.py script not found. Please place it in the current directory.")
             exit(1)
        label_list = raw_dataset["train"].features["ner_tags"].feature.names # O, B-PER, I-PER etc.

        # --- Complex Label Mapping for NER ---
        print("Building label map for CoNLL-2003 (using frozenset of non-'O' tags)...")
        frozenset_to_id = {}
        current_id = 0
        unique_tag_sets = set()
        # Iterate once to find all unique sets of non-'O' tags per sentence
        for example in tqdm(raw_dataset['train'], desc="Finding unique tag sets"):
            tags = [label_list[tag_idx] for tag_idx in example['ner_tags']]
            non_o_tags = frozenset(tag for tag in tags if tag != 'O') # Use frozenset as dict key
            if non_o_tags: # Only consider sentences with at least one non-O tag
                unique_tag_sets.add(non_o_tags)

        # Add a specific category for sentences with only 'O' tags
        only_o_tag_set = frozenset(['__ONLY_O__'])
        unique_tag_sets.add(only_o_tag_set)

        # Create the mapping
        for tag_set in sorted(list(unique_tag_sets), key=lambda fs: str(fs)): # Sort for consistent IDs
            if tag_set not in frozenset_to_id:
                frozenset_to_id[tag_set] = current_id
                current_id += 1

        id_to_label_map = {v: str(k) for k, v in frozenset_to_id.items()} # Store frozenset as string for JSON
        label_to_id_map = frozenset_to_id # Use this map directly in the function
        print(f"Built map with {len(id_to_label_map)} unique NER tag combinations.")
        # --- End Complex Label Mapping ---

        def format_conll(example):
            input_text = " ".join(example['tokens'])
            tags = [label_list[tag_idx] for tag_idx in example['ner_tags']]
            non_o_tags = frozenset(tag for tag in tags if tag != 'O')
            if not non_o_tags: # If only 'O' tags are present
                 label_key = only_o_tag_set
            else:
                 label_key = non_o_tags

            # Map the frozenset to its integer ID
            label_id = label_to_id_map.get(label_key, -1) # Use -1 for safety, though all should be found
            if label_id == -1:
                 print(f"Warning: Tag set {label_key} not found in map!")

            return {
                input_text_col: input_text,
                label_col: label_id # Directly assign integer label
            }
        # Apply map, directly producing the integer label column
        processed_dataset = raw_dataset.map(format_conll, remove_columns=raw_dataset["train"].column_names)
        # Add original_label_col for consistency downstream, using the string representation
        print("Adding original label column (handling potential unseen tag sets)...")
        processed_dataset = processed_dataset.map(
            lambda ex: {original_label_col: id_to_label_map.get(ex.get(label_col, -1), "Unseen Tag Set")} )

    elif dataset_name == 'piqa':
        raw_dataset = load_dataset("piqa", cache_dir=data_root)
        # Labels are 0 or 1, representing A or B after potential swapping
        label_names = ["A", "B"] # Representing the *choice* after formatting
        id_to_label_map = {0: "A", 1: "B"}
        label_to_id_map = {"A": 0, "B": 1}

        def format_piqa(sample):
            # Use deterministic swap based on hash (like in training script)
            content_hash = hashlib.sha256(
                f"{sample['goal']}{sample['sol1']}{sample['sol2']}".encode()
            ).hexdigest()
            hash_int = int(content_hash, 16) % (2**32)
            deterministic_rng = random.Random(42 + hash_int)
            swap = deterministic_rng.random() < 0.5

            if swap:
                options = [sample["sol2"], sample["sol1"]]
                correct_label_name = ["A", "B"][(sample["label"] + 1) % 2]
            else:
                options = [sample["sol1"], sample["sol2"]]
                correct_label_name = ["A", "B"][sample["label"]]

            input_prompt = (
                 "Choose the correct physical interaction. Answer must be 'A' or 'B'.\n"
                 f"Question: {sample['goal']}\n"
                 "Options:\n"
                 f"A. {options[0]}\n"
                 f"B. {options[1]}\n"
                 "Answer:" # STOP before answer
             )
            return {
                input_text_col: input_prompt,
                original_label_col: correct_label_name # Label is 'A' or 'B'
            }
        processed_dataset = raw_dataset.map(format_piqa, remove_columns=raw_dataset["train"].column_names)

    elif dataset_name == 'sciq':
        raw_dataset = load_dataset("allenai/sciq", cache_dir=data_root)
        label_names = ["A", "B", "C", "D"] # Representing the choice A-D
        id_to_label_map = {i: name for i, name in enumerate(label_names)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}

        def format_sciq(sample):
            question = sample["question"]
            options = [sample["correct_answer"], sample["distractor1"], sample["distractor2"], sample["distractor3"]]
            # Shuffle deterministically using question hash
            content_hash = hashlib.sha256(question.encode()).hexdigest()
            hash_int = int(content_hash, 16) % (2**32)
            deterministic_rng = random.Random(seed + hash_int) # Use global seed + hash
            deterministic_rng.shuffle(options) # Shuffle in place

            correct_idx = options.index(sample["correct_answer"])
            correct_label_name = label_names[correct_idx]

            formatted_options = "\n".join([f"{label_names[i]}. {opt}" for i, opt in enumerate(options)])
            input_prompt = (
                "Answer this science question. The answer must be a single uppercase letter (A-D).\n"
                f"Question: {question}\n"
                "Options:\n"
                f"{formatted_options}\n"
                # Include support in input? Maybe not for embedding general meaning. Let's omit.
                # f"Support: {sample['support']}\n"
                "Answer:" # STOP before answer
            )
            return {
                input_text_col: input_prompt,
                original_label_col: correct_label_name # Label is 'A', 'B', 'C', or 'D'
            }
        processed_dataset = raw_dataset.map(format_sciq, remove_columns=raw_dataset["train"].column_names)

    elif dataset_name == 'sem_eval_2010_task_8':
        raw_dataset = load_dataset("sem_eval_2010_task_8", cache_dir=data_root)
        # Use the predefined RELATION_LABELS from the training script
        relation_labels = [
            "Cause-Effect(e1,e2)", "Cause-Effect(e2,e1)", "Component-Whole(e1,e2)",
            "Component-Whole(e2,e1)", "Content-Container(e1,e2)", "Content-Container(e2,e1)",
            "Entity-Destination(e1,e2)", "Entity-Destination(e2,e1)", "Entity-Origin(e1,e2)",
            "Entity-Origin(e2,e1)", "Instrument-Agency(e1,e2)", "Instrument-Agency(e2,e1)",
            "Member-Collection(e1,e2)", "Member-Collection(e2,e1)", "Message-Topic(e1,e2)",
            "Message-Topic(e2,e1)", "Product-Producer(e1,e2)", "Product-Producer(e2,e1)",
            "Other"
        ]
        id_to_label_map = {i: name for i, name in enumerate(relation_labels)}
        label_to_id_map = {name: i for i, name in id_to_label_map.items()}

        def format_semeval(sample):
            raw_sentence = sample["sentence"]
            relation_idx = sample["relation"]
            if relation_idx >= len(relation_labels):
                # Handle potential invalid index if data is corrupt
                print(f"Warning: Invalid relation index {relation_idx} found in SemEval.")
                label_name = "Other" # Default to Other
            else:
                label_name = relation_labels[relation_idx]

            # Clean sentence (remove entity markers for embedding)
            clean_sentence = raw_sentence.replace("<e1>", "").replace("</e1>", "") \
                                         .replace("<e2>", "").replace("</e2>", "").strip()
            # Maybe add entity text explicitly? Let's try just the sentence.
            # e1_start = raw_sentence.find("<e1>") + 4
            # e1_end = raw_sentence.find("</e1>")
            # e1 = raw_sentence[e1_start:e1_end]
            # e2_start = raw_sentence.find("<e2>") + 4
            # e2_end = raw_sentence.find("</e2>")
            # e2 = raw_sentence[e2_start:e2_end]
            # input_text = f"Sentence: {clean_sentence}\nEntity 1: {e1}\nEntity 2: {e2}"
            input_text = clean_sentence

            return {
                input_text_col: input_text,
                original_label_col: label_name
            }
        processed_dataset = raw_dataset.map(format_semeval, remove_columns=["sentence", "relation"])

    elif dataset_name == 'clutrr':
         # Requires the clutrr_loader.py script
         clutrr_script_path = "./clutrr_loader.py"
         if not os.path.exists(clutrr_script_path):
             print(f"Error: CLUTRR loading script not found at: {clutrr_script_path}")
             exit(1)
         # Load a specific config, e.g., 'k_1_2_3_4_5_train' or others defined in the script
         # For complexity analysis, maybe use a combined or representative config?
         # Let's assume we want to analyze across K values, so load a broad config.
         # Using 'k_1_2_3_4_5_train' as an example. Adjust as needed.
         clutrr_config_name = 'gen_train234_test2to10'
         try:
            raw_dataset = load_dataset(clutrr_script_path, name=clutrr_config_name, trust_remote_code=True, cache_dir=data_root)
            # CLUTRR often only has 'train'. We might need 'test' splits too depending on the config.
            if 'train' not in raw_dataset:
                 print(f"Error: 'train' split not found in CLUTRR config '{clutrr_config_name}'.")
                 exit(1)
         except Exception as e:
            print(f"Error loading CLUTRR dataset using script '{clutrr_script_path}' and config '{clutrr_config_name}'.")
            raise e

         # --- Complex Label Mapping for CLUTRR (using target_text) ---
         print("Building label map for CLUTRR (using target_text)...")
         target_text_to_id = {}
         current_id = 0
         unique_targets = set(raw_dataset['train']['target_text'])

         for target in sorted(list(unique_targets)): # Sort for consistent IDs
            if target not in target_text_to_id:
                target_text_to_id[target] = current_id
                current_id += 1

         id_to_label_map = {v: k for k, v in target_text_to_id.items()}
         label_to_id_map = target_text_to_id
         print(f"Built map with {len(id_to_label_map)} unique target relations.")
         # --- End Complex Label Mapping ---

         def format_clutrr(example):
             # Extract K value to potentially filter later if needed, though not used for label
             edge_types_str = example.get('edge_types')
             k = -1
             if isinstance(edge_types_str, str) and edge_types_str.strip():
                 try: edge_list = ast.literal_eval(edge_types_str); k = len(edge_list) if isinstance(edge_list, list) else -1
                 except: k = -1
             # Format input text
             input_prompt = f"Context: {example['story']}\nQuestion: {example['query']}\nAnswer:" # Stop before answer
             label_name = example['target_text']
             label_id = label_to_id_map.get(label_name, -1)
             if label_id == -1: print(f"Warning: CLUTRR target '{label_name}' not found in map!")

             return {
                 input_text_col: input_prompt,
                 label_col: label_id, # Directly assign integer label
                 'k_value': k # Keep K value if needed for filtering later
             }
         # Apply map, creating integer label and keeping k_value
         processed_dataset = raw_dataset.map(format_clutrr, remove_columns=[c for c in raw_dataset['train'].column_names if c not in ['id']]) # Keep ID maybe?
         # Add original_label_col using the map
         processed_dataset = processed_dataset.map(lambda ex: {original_label_col: id_to_label_map.get(ex[label_col], "Unknown")})

    else:
        raise ValueError(f"Unsupported dataset: {dataset_name}")

    # --- Final Common Processing Step: Apply Label Mapping (if not done already) ---
    if label_col not in processed_dataset['train'].column_names:
        if not label_to_id_map:
            raise RuntimeError(f"Label map not created for dataset {dataset_name}")
        print("Applying label mapping...")
        processed_dataset = processed_dataset.map(
            lambda ex: {label_col: label_to_id_map.get(ex[original_label_col], -1)},
            # remove_columns=[original_label_col] # Remove original label after mapping
        )
        # Check for -1 labels (mapping errors)
        if any(ex[label_col] == -1 for ex in processed_dataset['train']):
             print(f"Warning: Some examples in {dataset_name} could not be mapped to an integer label.")


    # --- Return only the training split and the label map ---
    if 'train' not in processed_dataset:
        raise KeyError(f"FATAL: 'train' split missing after processing {dataset_name}")

    # Ensure required columns exist
    required_cols = [input_text_col, label_col, original_label_col]
    if not all(col in processed_dataset['train'].column_names for col in required_cols):
        raise ValueError(f"Dataset {dataset_name} processing failed. Missing columns. Found: {processed_dataset['train'].column_names}")


    return processed_dataset['train'], id_to_label_map

# === Embedding Generation ===

# Global cache for model and tokenizer to avoid reloading for each dataset if running multiple times
loaded_model = None
loaded_tokenizer = None

def get_llama_model_and_tokenizer(model_name, device):
    global loaded_model, loaded_tokenizer
    if loaded_model is None or loaded_tokenizer is None:
        print(f"Loading Tokenizer: {model_name}")
        loaded_tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side='left')
        # Add pad token if missing
        if loaded_tokenizer.pad_token is None:
            loaded_tokenizer.pad_token = loaded_tokenizer.eos_token
            print("Set pad_token to eos_token")

        print(f"Loading Model: {model_name} (fp16, device_map='auto')")
        # Use device_map='auto' for efficient loading on available hardware (needs accelerate)
        # Set low_cpu_mem_usage=True for potentially faster loading on systems with limited CPU RAM
        loaded_model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,
            device_map="auto", # Automatically distributes layers across GPUs/CPU
            low_cpu_mem_usage=True, # Can help on systems with less RAM
            trust_remote_code=True # If model requires custom code
        )
        print("Model loaded successfully onto devices.")
        loaded_model.eval() # Set to evaluation mode
    return loaded_model, loaded_tokenizer

def get_nlp_embeddings(model, tokenizer, texts, device, batch_size, max_length):
    """Generates embeddings using mean pooling of the last hidden state."""
    all_embeddings = []
    model.eval() # Ensure model is in eval mode

    print(f"Generating embeddings for {len(texts)} texts (batch size: {batch_size}, max_length: {max_length})...")
    # Process in batches
    for i in tqdm(range(0, len(texts), batch_size), desc="Embedding Batches"):
        batch_texts = texts[i : i + batch_size]
        if not batch_texts: continue # Skip empty batches

        # Tokenize batch
        # Important: Ensure tokenizer uses padding_side='left' for causal LMs if generating
        # For embedding extraction via hidden states, either side *can* work, but left is common.
        inputs = tokenizer(
            batch_texts,
            return_tensors='pt',
            padding='max_length', # Pad to max_length
            truncation=True,
            max_length=max_length,
            add_special_tokens=True # Add BOS/EOS if model expects them
        )

        # Move inputs to the device the model expects (handled by device_map)
        # Inputs need to be on *some* CUDA device if model is distributed
        # Let's find the device of the first parameter as a heuristic
        model_device = next(model.parameters()).device
        inputs = {k: v.to(model_device) for k, v in inputs.items()}

        # Get hidden states
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
            last_hidden_state = outputs.hidden_states[-1] # Shape: (batch_size, seq_len, hidden_dim)

        # --- Mean Pooling with Attention Mask ---
        attention_mask = inputs['attention_mask'] # Shape: (batch_size, seq_len)
        # Expand mask to match hidden state dimensions for broadcasting
        mask_expanded = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
        # Zero out padding tokens' hidden states
        sum_hidden_state = torch.sum(last_hidden_state * mask_expanded, dim=1)
        # Count non-padding tokens
        seq_lengths = torch.sum(mask_expanded, dim=1)
        # Avoid division by zero for empty sequences (though unlikely with padding)
        seq_lengths = torch.clamp(seq_lengths, min=1e-9)
        # Calculate mean pooled embedding
        pooled_embeddings = sum_hidden_state / seq_lengths

        # Move embeddings to CPU and convert to numpy
        all_embeddings.append(pooled_embeddings.cpu().numpy())

        # Clean up tensors in loop to potentially save memory
        del inputs, outputs, last_hidden_state, mask_expanded, sum_hidden_state, seq_lengths, pooled_embeddings
        if device.type == 'cuda':
            torch.cuda.empty_cache()

    if not all_embeddings:
        print("Warning: No embeddings were generated.")
        return np.array([]) # Return empty array

    return np.concatenate(all_embeddings, axis=0)


# === Complexity Metrics Calculation (Adapted from previous script) ===

def calculate_metrics(X_embed, Y_labels, pca_threshold, k_neighbors, silhouette_sample_size):
    """Calculates all complexity metrics."""
    print("\nCalculating complexity metrics...")
    results = {}
    n_samples = X_embed.shape[0]
    n_features = X_embed.shape[1]

    # --- Basic Checks ---
    if X_embed is None or Y_labels is None or n_samples == 0 or n_features == 0:
        print("Error: Embedding data or labels are invalid/empty. Cannot calculate metrics.")
        return None
    if len(X_embed) != len(Y_labels):
         print(f"Error: Embeddings ({len(X_embed)}) vs Labels ({len(Y_labels)}) count mismatch.")
         return None

    # --- Metric Calculations ---
    # 1. num_classes
    print("Calculating num_classes...")
    unique_labels, counts = np.unique(Y_labels, return_counts=True)
    results['num_classes'] = len(unique_labels)
    print(f"  num_classes: {results['num_classes']}")
    if results['num_classes'] < 2:
         print("Warning: Only found 1 class. Some metrics might not be meaningful.")

    # 2. label_entropy
    print("Calculating label_entropy...")
    # Ensure counts match unique_labels length if using np.bincount results later
    # Using counts from np.unique is safer here
    if len(counts) > 0 :
        results['label_entropy'] = entropy(counts, base=2)
        print(f"  label_entropy: {results['label_entropy']:.4f}")
    else:
        results['label_entropy'] = 0.0
        print(f"  label_entropy: 0.0 (no labels found)")


    # 3. effective_dim
    print("Calculating effective_dim...")
    try:
        scaler = StandardScaler()
        # Using float32 for potentially large embeddings to save memory
        X_scaled = scaler.fit_transform(X_embed.astype(np.float32))

        # Check for sufficient samples vs features
        actual_n_features = X_scaled.shape[1]
        pca_n_components = min(n_samples, actual_n_features) # Cannot have more components than samples or features

        if pca_n_components < 2:
             print(f"  Skipping effective_dim (not enough samples/features: {pca_n_components}).")
             results['effective_dim'] = None
        else:
            pca = PCA(n_components=pca_n_components)
            pca.fit(X_scaled)
            cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
            # Find index where cumulative variance exceeds threshold
            eff_dim_indices = np.where(cumulative_variance >= pca_threshold)[0]
            if len(eff_dim_indices) > 0:
                 eff_dim_val = eff_dim_indices[0] + 1 # +1 because index is 0-based
            else:
                 # Threshold never reached, use total components as effective dim
                 print(f"  Warning: PCA threshold {pca_threshold} never reached. Max variance explained: {cumulative_variance[-1]:.4f}. Using total components: {pca.n_components_}")
                 eff_dim_val = pca.n_components_
            results['effective_dim'] = int(eff_dim_val)
            print(f"  effective_dim (at {pca_threshold*100}% variance): {results.get('effective_dim', 'N/A')}")
        del X_scaled # Free memory
        gc.collect()
    except MemoryError:
        print("  MemoryError calculating effective_dim. Skipping.")
        results['effective_dim'] = None
    except Exception as e:
        print(f"  Error calculating effective_dim: {e}")
        results['effective_dim'] = None

    # 4. intra_class_var
    print("Calculating intra_class_var...")
    try:
        avg_intra_distances = []
        if results['num_classes'] < 1: # Need at least 1 class
             print("  Skipping intra_class_var (no classes found).")
             results['intra_class_var'] = None
        else:
            for label_idx, label in enumerate(unique_labels):
                class_indices = np.where(Y_labels == label)[0]
                class_embeddings = X_embed[class_indices]
                if len(class_embeddings) > 1:
                    # Use float64 for centroid and distance calculation for precision
                    centroid = np.mean(class_embeddings.astype(np.float64), axis=0)
                    distances = [euclidean(emb.astype(np.float64), centroid) for emb in class_embeddings]
                    avg_intra_distances.append(np.mean(distances))
                elif len(class_embeddings) == 1:
                     avg_intra_distances.append(0.0) # Single point has 0 distance

            if not avg_intra_distances: # Check if any distances were calculated
                print("  Warning: Could not calculate any valid intra-class distances.")
                results['intra_class_var'] = None
            else:
                results['intra_class_var'] = np.mean(avg_intra_distances)
                print(f"  intra_class_var: {results['intra_class_var']:.4f}")
    except MemoryError:
        print("  MemoryError calculating intra_class_var. Skipping.")
        results['intra_class_var'] = None
    except Exception as e:
        print(f"  Error calculating intra_class_var: {e}")
        results['intra_class_var'] = None


    # 5. local_consistency
    print(f"Calculating local_consistency (k={k_neighbors})...")
    try:
        actual_k = min(k_neighbors, n_samples - 1) # Adjust k if dataset is small
        if actual_k < 1:
             print(f"  Skipping local_consistency (not enough samples ({n_samples}) for k={k_neighbors}).")
             results['local_consistency'] = None
        else:
            print(f"  Fitting NearestNeighbors (k={actual_k})...")
            # Use float32 for KNN fit to save memory, distance calculation is robust enough
            nn = NearestNeighbors(n_neighbors=actual_k + 1, metric='euclidean', n_jobs=-1)
            nn.fit(X_embed.astype(np.float32))
            print("  Querying neighbors...")
            # Query points themselves, exclude the first neighbor (self)
            indices = nn.kneighbors(X_embed.astype(np.float32), return_distance=False)[:, 1:]

            print("  Calculating consistency...")
            consistent_neighbor_ratios = []
            # Iterate using numpy operations for potential speedup if possible, but loop is clear
            for i in tqdm(range(n_samples), desc="Local Consistency"):
                neighbor_indices = indices[i]
                neighbor_labels = Y_labels[neighbor_indices]
                consistency = np.mean(neighbor_labels == Y_labels[i])
                consistent_neighbor_ratios.append(consistency)

            results['local_consistency'] = np.mean(consistent_neighbor_ratios)
            print(f"  local_consistency: {results['local_consistency']:.4f}")
    except MemoryError:
         print("  MemoryError during NearestNeighbors fit or query. Skipping local_consistency.")
         results['local_consistency'] = None
    except Exception as e:
        print(f"  Error calculating local_consistency: {e}")
        results['local_consistency'] = None


    # 6. separability_score (Silhouette Score)
    print("Calculating separability_score (Silhouette Score)...")
    if results['num_classes'] < 2:
         print("  Skipping separability_score (requires at least 2 classes).")
         results['separability_score'] = None
    elif n_samples < results['num_classes'] * 2 : # Heuristic check
        print(f"  Skipping separability_score (too few samples ({n_samples}) for {results['num_classes']} classes).")
        results['separability_score'] = None
    else:
        print("  WARNING: Silhouette score calculation can be VERY slow and memory-intensive!")
        X_work = X_embed
        Y_work = Y_labels
        # Subsample if dataset is too large
        if n_samples > silhouette_sample_size:
            print(f"  Subsampling to {silhouette_sample_size} samples using stratified split for silhouette.")
            try:
                # Use sklearn's train_test_split for stratified sampling
                # Calculate the fraction to keep
                frac_to_keep = silhouette_sample_size / n_samples
                indices_full = np.arange(n_samples)
                indices_subset, _ = sklearn_train_test_split(
                    indices_full,
                    train_size=frac_to_keep,
                    stratify=Y_labels,
                    random_state=42 # Use a fixed seed for reproducibility
                )
                X_work = X_embed[indices_subset]
                Y_work = Y_labels[indices_subset]
                print(f"  Using {len(X_work)} samples for silhouette after stratified sampling.")
                # Check if the subsample still has enough classes
                if len(np.unique(Y_work)) < 2:
                     print("  Subsampled data has less than 2 classes. Skipping silhouette.")
                     results['separability_score'] = None
                     X_work = None # Skip calculation
            except ValueError as ve:
                 print(f"  ValueError during stratified sampling for silhouette: {ve}. Trying random sampling.")
                 # Fallback to simple random sampling if stratification fails
                 indices_subset = np.random.choice(n_samples, silhouette_sample_size, replace=False)
                 X_work = X_embed[indices_subset]
                 Y_work = Y_labels[indices_subset]
                 if len(np.unique(Y_work)) < 2:
                     print("  Randomly subsampled data has less than 2 classes. Skipping silhouette.")
                     results['separability_score'] = None
                     X_work = None


        if X_work is not None:
            try:
                print(f"  Calculating silhouette on {X_work.shape[0]} samples...")
                # Use float32 for silhouette to save memory
                score = silhouette_score(X_work.astype(np.float32), Y_work, metric='euclidean')
                results['separability_score'] = score
                print(f"  separability_score: {results['separability_score']:.4f}")
            except MemoryError:
                print("  MemoryError calculating silhouette score even after sampling. Try reducing SILHOUETTE_SAMPLE_SIZE.")
                results['separability_score'] = None
            except ValueError as ve:
                 print(f"  ValueError calculating silhouette score: {ve}. Check labels or data.")
                 results['separability_score'] = None
            except Exception as e:
                print(f"  Error calculating silhouette score: {e}")
                results['separability_score'] = None

    return results

# === Main Execution Logic ===

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculate complexity metrics for NLP datasets using LLM embeddings.")
    parser.add_argument('-dataset', type=str, required=True,
                        choices=['ag_news', 'aqua_rat', 'conll2003', 'piqa',
                                 'sciq', 'sem_eval_2010_task_8', 'clutrr'],
                        help='Name of the NLP dataset to process.')
    args = parser.parse_args()
    dataset_name = args.dataset

    print(f"--- Starting Complexity Analysis for: {dataset_name} ---")
    print(f"Using Embedding Model: {EMBEDDING_MODEL_NAME}")

    output_path = os.path.join(OUTPUT_DIR, f"{dataset_name}_complexity_metrics.json")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Check if results already exist
    if os.path.exists(output_path):
        print(f"Results file already exists at {output_path}. Skipping calculation.")
        # Optionally load and print existing results
        try:
            with open(output_path, 'r') as f:
                existing_results = json.load(f)
            print("\n--- Existing Results ---")
            print(json.dumps(existing_results, indent=4))
        except Exception as e:
            print(f"Could not load existing results file: {e}")
        exit() # Exit if file exists

    # --- Step 1: Load and Preprocess Data ---

    train_dataset, id_to_label_map = load_and_preprocess_nlp_dataset(dataset_name, DATA_ROOT)
    print(f"Initial training samples loaded: {len(train_dataset)}")

    # --- Step 2: Subsampling (if needed) ---
    num_samples_initial = len(train_dataset)
    if num_samples_initial > MAX_SAMPLES_FOR_EMBEDDING:
        print(f"Dataset size ({num_samples_initial}) exceeds limit ({MAX_SAMPLES_FOR_EMBEDDING}). Applying stratified subsampling...")
        try:
            # Calculate fraction to keep
            frac_to_keep = MAX_SAMPLES_FOR_EMBEDDING / num_samples_initial
            # Use dataset's built-in method for stratified split
            # Split into train/test where 'test' is the part we discard
            train_dataset_split = train_dataset.train_test_split(
                train_size=frac_to_keep, # Keep this fraction
                stratify_by_column="label",
                seed=42
            )
            train_dataset = train_dataset_split['train'] # Keep the 'train' part of the split
            print(f"Subsampled to {len(train_dataset)} training samples.")
        except ValueError as ve:
             print(f"Warning: Stratified subsampling failed ({ve}). Trying random subsampling.")
             indices = list(range(num_samples_initial))
             random.seed(42)
             subsampled_indices = random.sample(indices, MAX_SAMPLES_FOR_EMBEDDING)
             train_dataset = train_dataset.select(subsampled_indices)
             print(f"Subsampled randomly to {len(train_dataset)} training samples.")
        except Exception as e:
             print(f"Error during subsampling: {e}. Proceeding with full dataset (might be slow/fail).")
             # Optionally exit here if subsampling is critical
             # exit(1)

    # --- Step 3: Prepare Data for Embedding ---
    try:
        texts_to_embed = train_dataset['input_text_for_embedding']
        Y_labels = np.array(train_dataset['label'])
        print(f"Prepared {len(texts_to_embed)} texts and {len(Y_labels)} labels for embedding.")
    except Exception as e:
        print(f"FATAL: Error extracting text/labels from processed dataset. Columns: {train_dataset.column_names}. Error: {e}")
        exit(1)


    # --- Step 4: Load Model and Tokenizer ---
    model = None # Define outside try block for finally clause
    try:
        model, tokenizer = get_llama_model_and_tokenizer(EMBEDDING_MODEL_NAME, device)
    except Exception as e:
        print(f"FATAL: Failed to load model or tokenizer. Error: {e}")
        # Potentially try releasing memory if partially loaded
        del model
        del tokenizer
        gc.collect()
        if device.type == 'cuda': torch.cuda.empty_cache()
        exit(1)


    # --- Step 5: Generate Embeddings ---
    X_embed = None # Define outside try block
    try:
        X_embed = get_nlp_embeddings(model, tokenizer, texts_to_embed, device, EMBEDDING_BATCH_SIZE, MAX_TOKEN_LENGTH)
        print(f"Generated embeddings shape: {X_embed.shape if X_embed is not None and X_embed.size > 0 else 'None or Empty'}")
    except Exception as e:
        print(f"FATAL: Failed during embedding generation. Error: {e}")
        # Cleanup before exiting
        del model
        del tokenizer
        del X_embed
        gc.collect()
        if device.type == 'cuda': torch.cuda.empty_cache()
        exit(1)

    # --- Step 6: Calculate Metrics ---
    final_results = {}
    if X_embed is not None and Y_labels is not None and X_embed.shape[0] == len(Y_labels) and X_embed.size > 0:
        metrics = calculate_metrics(X_embed, Y_labels, PCA_VARIANCE_THRESHOLD, K_NEIGHBORS, SILHOUETTE_SAMPLE_SIZE)
        if metrics:
            final_results['metrics'] = metrics
            final_results['dataset_info'] = {
                'name': dataset_name,
                'embedding_model': EMBEDDING_MODEL_NAME,
                'embedding_dimension': X_embed.shape[1],
                'samples_used_for_metrics': X_embed.shape[0],
                'original_training_samples': num_samples_initial,
                'max_samples_limit': MAX_SAMPLES_FOR_EMBEDDING,
                'id_to_label_map': id_to_label_map # Include label mapping
            }
        else:
             print("Metrics calculation failed or returned no results.")
    else:
        print("Embeddings or labels are invalid after generation. Cannot calculate metrics.")


    # --- Step 7: Save Results ---
    if final_results:
        print("\nSaving final results...")
        try:
            # Convert numpy types for JSON serialization within the metrics dict
            if 'metrics' in final_results:
                 serializable_metrics = {}
                 for k, v in final_results['metrics'].items():
                      if isinstance(v, np.generic):
                           serializable_metrics[k] = v.item()
                      elif isinstance(v, (np.ndarray)):
                           # Decide how to handle arrays - convert to list? Skip? Error?
                           # Let's convert simple arrays (like potentially from some metrics) to list
                           serializable_metrics[k] = v.tolist()
                      elif v is not None : # Keep other JSON-serializable types
                           serializable_metrics[k] = v
                 final_results['metrics'] = serializable_metrics

            # Convert id_to_label_map keys (potential ints) to strings if necessary
            if 'id_to_label_map' in final_results.get('dataset_info', {}):
                 final_results['dataset_info']['id_to_label_map'] = {
                     str(k): v for k,v in final_results['dataset_info']['id_to_label_map'].items()
                 }


            with open(output_path, 'w') as f:
                json.dump(final_results, f, indent=4)

            print(f"Results successfully saved to {output_path}")
            print("\n--- Final Results ---")
            print(json.dumps(final_results, indent=4))
        except TypeError as te:
            print(f"Error: Could not serialize results to JSON. Type Error: {te}")
            print("Problematic data structure:", final_results) # Print structure to help debug
        except Exception as e:
            print(f"Error saving results to {output_path}: {e}")
    else:
        print("No results generated to save.")


    # --- Step 8: Cleanup ---
    print("Cleaning up resources...")
    del model
    del tokenizer
    del X_embed
    del Y_labels
    del train_dataset
    # Force garbage collection
    gc.collect()
    if device.type == 'cuda':
        torch.cuda.empty_cache()
        print("CUDA cache cleared.")

    print(f"\n--- Finished processing {dataset_name} ---")