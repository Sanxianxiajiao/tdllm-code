import torch
import os
import json
import re
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    trainer_utils
)
from peft import LoraConfig, get_peft_model
from transformers import TrainerCallback
from typing import Dict, List, Union
import argparse
from torch.distributed import all_reduce, ReduceOp

# 设置随机种子（保持与原代码一致）
def set_all_seeds(seed=42):
    import random
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ["PYTHONHASHSEED"] = str(seed)
set_all_seeds(42)

# 自定义数据整理器（保持原结构）
class CustomDataCollator(DataCollatorForLanguageModeling):
    def __call__(self, features: List[Dict[str, Union[List[int], str]]]) -> Dict[str, torch.Tensor]:
        input_texts = [feature.pop("input_text") for feature in features]
        output_texts = [feature.pop("output_text") for feature in features]
        batch = super().__call__(features)
        batch["input_text"] = input_texts
        batch["output_text"] = output_texts
        return batch

# 1. 数据准备（针对CommonsenseQA调整）
def load_commonsenseqa():
    dataset = load_dataset("commonsense_qa")
    print(dataset)
    print("原始数据集列名:", dataset["train"].column_names)  # 查看原始列名
    def format_instruction(sample):
        question = sample["question"]
        choices = sample["choices"]["text"]
        labels = sample["choices"]["label"]
        answer = sample["answerKey"]
        
        options = "\n".join([f"{label}. {text}" for label, text in zip(labels, choices)])
        return {
            "input": f"You will then answer a multiple choice question, and the first capital letter (A-E) in your answer will be the answer.\nQuestion: {question}\nOptions:\n{options}\nAnswer:",
            "output": answer
        }
    
    # 移除所有原始列，仅保留新生成的input和output
    columns_to_remove = dataset["train"].column_names  # 包括可能的id、question等
    return dataset.map(format_instruction, remove_columns=columns_to_remove)

dataset = load_commonsenseqa()

# 数据切片逻辑（保持与原代码一致）
parser = argparse.ArgumentParser()
parser.add_argument("--num_train_samples", type=int, default=-1)
args = parser.parse_args()

num_train_samples_full = len(dataset["train"])
num_train_samples = args.num_train_samples if args.num_train_samples != -1 else num_train_samples_full
if num_train_samples < num_train_samples_full:
    dataset["train"] = dataset["train"].select(range(num_train_samples))
dataset["test"] = dataset["validation"].select(range(num_train_samples))
dataset["validation"] = dataset["test"]
print(dataset)

# 2. 模型加载（保持原参数）
model_name = "meta-llama/Llama-3.1-8B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side='left')
tokenizer.pad_token = tokenizer.eos_token

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    # device_map="auto"
)

# 3. LoRA配置（保持原参数）
peft_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, peft_config)

# 4. 数据预处理（适配新格式）
def preprocess_function(sample):
    input_text = sample["input"]
    output_text = sample["output"]
    
    # 分别编码输入和输出部分
    input_ids = tokenizer.encode(input_text, add_special_tokens=False)
    output_ids = tokenizer.encode(output_text, add_special_tokens=False) + [tokenizer.eos_token_id]
    
    # 合并并处理截断与填充
    combined = input_ids + output_ids
    combined = combined[:512]
    combined_len = len(combined)
    padded = combined + [tokenizer.pad_token_id] * (512 - combined_len)
    attention_mask = [1] * combined_len + [0] * (512 - combined_len)
    
    # 标签处理（仅输出部分参与损失计算）
    labels = [-100] * len(input_ids) + output_ids[:512 - len(input_ids)]
    labels += [-100] * (512 - len(labels))
    
    return {
        "input_ids": padded,
        "attention_mask": attention_mask,
        "labels": labels,
        "input_text": input_text,
        "output_text": output_text,
        "input_len": len(input_ids),  # 保存输入部分长度
    }

train_dataset = dataset["train"].map(
    preprocess_function, 
    remove_columns=["input", "output"]  # 移除原始的input/output，保留预处理后的字段
)
eval_dataset = dataset["validation"].map(
    preprocess_function, 
    remove_columns=["input", "output"]
)
# print(eval_dataset[0])

# 5. 评估回调（修改答案提取逻辑）
class CommonsenseQACallback(TrainerCallback):
    def __init__(self, tokenizer, output_dir_base):
        self.tokenizer = tokenizer
        self.output_dir_base = output_dir_base
        self.option_pattern = re.compile(r'([A-E])')  # 更健壮的正则表达式
        self.state_file = os.path.join(output_dir_base, "callback_state.json")
        self.epoch_accuracies = {}
        self.best_accuracy = 0.0
        self.best_epoch = 0
        
        # 加载之前的状态
        if os.path.exists(self.state_file):
            with open(self.state_file, 'r') as f:
                state = json.load(f)
                self.epoch_accuracies = {int(k): v for k, v in state.get('epoch_accuracies', {}).items()}
                self.best_accuracy = state.get('best_accuracy', 0.0)
                self.best_epoch = state.get('best_epoch', 0)

    def extract_answer(self, text):
        match = self.option_pattern.search(text)
        return match.group(1) if match else None
    
    def on_evaluate(self, args, state, control, **kwargs):
        # 确保只在主进程执行
        if not state.is_local_process_zero:
            return

        trainer = kwargs.get("trainer")
        if trainer is None:
            return

        model = trainer.model
        eval_dataloader = trainer.get_eval_dataloader()
        
        total = 0
        correct = 0
        
        model.eval()
        for batch in eval_dataloader:
            # 将数据移至设备
            input_ids = batch["input_ids"].to(model.device)
            attention_mask = batch["attention_mask"].to(model.device)
            input_lens = batch["input_len"].to(model.device)
            output_texts = batch["output_text"]
            
            generated_texts = []
            for i in range(input_ids.size(0)):
                current_input_len = input_lens[i].item()
                # 仅使用输入部分生成
                outputs = model.generate(
                    input_ids=input_ids[i][:current_input_len].unsqueeze(0),
                    attention_mask=attention_mask[i][:current_input_len].unsqueeze(0),
                    max_new_tokens=10,
                    pad_token_id=tokenizer.eos_token_id
                )
                # 提取生成部分（排除输入）
                gen_part = outputs[:, current_input_len:]
                generated_texts.append(tokenizer.decode(gen_part[0], skip_special_tokens=True))
            
            # 统计正确数
            for pred, true in zip(generated_texts, output_texts):
                extracted = self.extract_answer(pred)
                total += 1
                correct += 1 if extracted == true else 0

        # 分布式汇总
        total_tensor = torch.tensor(total, device=model.device)
        correct_tensor = torch.tensor(correct, device=model.device)
        all_reduce(total_tensor, op=ReduceOp.SUM)
        all_reduce(correct_tensor, op=ReduceOp.SUM)
        
        accuracy = correct_tensor.item() / total_tensor.item() if total_tensor.item() > 0 else 0
        print(f"Epoch {int(state.epoch)} Accuracy: {accuracy:.2%}")
        current_epoch = int(state.epoch) 
        # 更新最佳模型逻辑
        if accuracy > self.best_accuracy:
            self.best_accuracy = accuracy
            self.best_epoch = current_epoch
            model.save_pretrained(os.path.join(self.output_dir_base, "best_model"))
            tokenizer.save_pretrained(os.path.join(self.output_dir_base, "best_model"))
        
        # 打印并保存结果
        print(f"\nEpoch {current_epoch} - Accuracy: {accuracy:.2%}")
        with open(self.state_file, 'w') as f:
            json.dump({
                "best_accuracy": self.best_accuracy,
                "best_epoch": self.best_epoch,
                f"epoch_{current_epoch}": accuracy
            }, f)

# 6. 训练配置（保持原超参数）
output_dir_base = f"./results/commonsenseqa/result_{num_train_samples}"
output_dir_ckp = os.path.join(output_dir_base, "ckp")
output_dir_result = os.path.join(output_dir_base, "result")
last_checkpoint = None
if os.path.exists(output_dir_ckp): # 检查 ckp 路径
    try:
        last_checkpoint = trainer_utils.get_last_checkpoint(output_dir_ckp)
    except FileNotFoundError:
        last_checkpoint = None
else:
    # 确保输出目录存在（首次运行时会自动创建）
    os.makedirs(output_dir_ckp, exist_ok=True) # 创建 ckp 路径
training_args = TrainingArguments(
    output_dir=os.path.join(output_dir_base, "ckp"),
    per_device_train_batch_size=1,
    per_device_eval_batch_size=1,
    gradient_accumulation_steps=8,
    num_train_epochs=5,
    learning_rate=2e-5,
    fp16=True,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=False,  # 禁用自动加载最佳模型
    metric_for_best_model=None,      # 避免自动选择模型
    save_total_limit=1,
    logging_steps=10,
    report_to="none",
    optim="adamw_torch",
    remove_unused_columns=False,
    ddp_find_unused_parameters=False,
    dataloader_num_workers=8,
)

os.makedirs(output_dir_result, exist_ok=True)
# 7. 创建训练器
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=CustomDataCollator(tokenizer=tokenizer, mlm=False),
    callbacks=[CommonsenseQACallback(tokenizer, output_dir_base)]
)

# 8. 开始训练
print(f"是否存在可用检查点: {last_checkpoint is not None}")
trainer.train(resume_from_checkpoint=last_checkpoint)

# final_model_dir = os.path.join(output_dir_base, "final_model")
# trainer.save_model(final_model_dir)
# print(f"\nFinal model saved to {final_model_dir}")

# 9. 结果记录
# eval_results = trainer.evaluate(eval_dataset=dataset["validation"])
eval_results = trainer.evaluate(eval_dataset=eval_dataset)
# 从回调中提取结果
accuracy_callback = None
for callback in trainer.callback_handler.callbacks:
    if isinstance(callback, CommonsenseQACallback):
        accuracy_callback = callback
        break

if accuracy_callback:
    sorted_epochs = sorted(accuracy_callback.epoch_accuracies.keys())
    epoch_accuracies_list = [accuracy_callback.epoch_accuracies[epoch] for epoch in sorted_epochs]
    
    result_data = {
        "epoch_accuracies": epoch_accuracies_list,
        "best_accuracy": accuracy_callback.best_accuracy,
        "best_epoch": accuracy_callback.best_epoch,
        "final_loss": eval_results["eval_loss"]
    }
    
    print(f"\nBest Validation Accuracy: {accuracy_callback.best_accuracy:.4f} at Epoch {accuracy_callback.best_epoch}")
else:
    result_data = {"error": "Callback not found"}
    print("Warning: Accuracy tracking data not available")

# 合并历史结果
result_file_path = os.path.join(output_dir_result, "results.json")
existing_data = {}
if os.path.exists(result_file_path):
    with open(result_file_path, 'r') as f:
        existing_data = json.load(f)

merged_results = {
    "all_epochs": existing_data.get("all_epochs", []) + result_data.get("epoch_accuracies", []),
    "best_accuracy": max(existing_data.get("best_accuracy", 0.0), result_data.get("best_accuracy", 0.0)),
    "best_epoch": result_data["best_epoch"] if result_data["best_accuracy"] > existing_data.get("best_accuracy", 0.0) 
                  else existing_data.get("best_epoch", 0),
    "final_loss": result_data.get("final_loss", None)
}

with open(result_file_path, 'w') as f:
    json.dump(merged_results, f, indent=4)

print("\nTraining results saved to:", result_file_path)